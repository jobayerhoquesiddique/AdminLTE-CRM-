"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { useCrm } from "@/lib/context/CrmContext"

export function Sidebar() {
  const pathname = usePathname()
  const { state } = useCrm()
  const [menuOpen, setMenuOpen] = useState({
    reports: false,
    settings: false,
    products: false,
    marketing: false,
  })

  // Automatically open menu sections based on current path
  useEffect(() => {
    if (pathname.startsWith("/reports")) {
      setMenuOpen((prev) => ({ ...prev, reports: true }))
    } else if (pathname.startsWith("/settings")) {
      setMenuOpen((prev) => ({ ...prev, settings: true }))
    } else if (pathname.startsWith("/products")) {
      setMenuOpen((prev) => ({ ...prev, products: true }))
    } else if (pathname.startsWith("/marketing")) {
      setMenuOpen((prev) => ({ ...prev, marketing: true }))
    }
  }, [pathname])

  const toggleMenu = (menu: string) => {
    setMenuOpen((prev) => ({
      ...prev,
      [menu]: !prev[menu],
    }))
  }

  const isActive = (path: string) => pathname === path
  const isMenuActive = (paths: string[]) => paths.some((path) => pathname.startsWith(path))

  // Count badges
  const leadCount = state.leads.length
  const taskCount = state.tasks.filter((task) => task.status === "Pending").length
  const dealCount = state.deals.filter((deal) => ["Proposal", "Negotiation"].includes(deal.stage)).length

  return (
    <aside className="app-sidebar bg-body-secondary shadow" data-bs-theme="dark">
      <div className="sidebar-brand">
        <Link href="/" className="brand-link">
          <img
            src="/placeholder.svg?height=34&width=34"
            alt="AdminLTE Logo"
            className="brand-image opacity-75 shadow"
          />
          <span className="brand-text fw-light">AdminLTE CRM</span>
        </Link>
      </div>
      <div className="sidebar-wrapper">
        <nav className="mt-2">
          <ul className="nav sidebar-menu flex-column" data-lte-toggle="treeview" role="menu" data-accordion="false">
            <li className="nav-item">
              <Link href="/" className={`nav-link ${isActive("/") ? "active" : ""}`}>
                <i className="nav-icon bi bi-speedometer2"></i>
                <p>Dashboard</p>
              </Link>
            </li>
            <li className="nav-item">
              <Link
                href="/customers"
                className={`nav-link ${isActive("/customers") || pathname.startsWith("/customers/") ? "active" : ""}`}
              >
                <i className="nav-icon bi bi-people-fill"></i>
                <p>Customers</p>
              </Link>
            </li>
            <li className="nav-item">
              <Link
                href="/leads"
                className={`nav-link ${isActive("/leads") || pathname.startsWith("/leads/") ? "active" : ""}`}
              >
                <i className="nav-icon bi bi-funnel-fill"></i>
                <p>
                  Leads
                  {leadCount > 0 && <span className="badge badge-info right">{leadCount}</span>}
                </p>
              </Link>
            </li>
            <li className="nav-item">
              <Link
                href="/deals"
                className={`nav-link ${isActive("/deals") || pathname.startsWith("/deals/") ? "active" : ""}`}
              >
                <i className="nav-icon bi bi-currency-dollar"></i>
                <p>
                  Deals
                  {dealCount > 0 && <span className="badge badge-success right">{dealCount}</span>}
                </p>
              </Link>
            </li>
            <li className="nav-item">
              <Link
                href="/tasks"
                className={`nav-link ${isActive("/tasks") || pathname.startsWith("/tasks/") ? "active" : ""}`}
              >
                <i className="nav-icon bi bi-check2-square"></i>
                <p>
                  Tasks
                  {taskCount > 0 && <span className="badge badge-warning right">{taskCount}</span>}
                </p>
              </Link>
            </li>
            <li className="nav-item">
              <Link href="/calendar" className={`nav-link ${isActive("/calendar") ? "active" : ""}`}>
                <i className="nav-icon bi bi-calendar-week"></i>
                <p>Calendar</p>
              </Link>
            </li>

            {/* Products Menu */}
            <li className={`nav-item ${menuOpen.products ? "menu-open" : ""}`}>
              <a
                href="#"
                className={`nav-link ${isMenuActive(["/products"]) ? "active" : ""}`}
                onClick={() => toggleMenu("products")}
              >
                <i className="nav-icon bi bi-box-fill"></i>
                <p>
                  Products
                  <i className="nav-arrow bi bi-chevron-right"></i>
                </p>
              </a>
              <ul className="nav nav-treeview">
                <li className="nav-item">
                  <Link href="/products" className={`nav-link ${isActive("/products") ? "active" : ""}`}>
                    <i className="nav-icon bi bi-circle"></i>
                    <p>All Products</p>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link
                    href="/products/categories"
                    className={`nav-link ${isActive("/products/categories") ? "active" : ""}`}
                  >
                    <i className="nav-icon bi bi-circle"></i>
                    <p>Categories</p>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link
                    href="/products/inventory"
                    className={`nav-link ${isActive("/products/inventory") ? "active" : ""}`}
                  >
                    <i className="nav-icon bi bi-circle"></i>
                    <p>Inventory</p>
                  </Link>
                </li>
              </ul>
            </li>

            {/* Marketing Menu */}
            <li className={`nav-item ${menuOpen.marketing ? "menu-open" : ""}`}>
              <a
                href="#"
                className={`nav-link ${isMenuActive(["/marketing"]) ? "active" : ""}`}
                onClick={() => toggleMenu("marketing")}
              >
                <i className="nav-icon bi bi-megaphone-fill"></i>
                <p>
                  Marketing
                  <i className="nav-arrow bi bi-chevron-right"></i>
                </p>
              </a>
              <ul className="nav nav-treeview">
                <li className="nav-item">
                  <Link
                    href="/marketing/campaigns"
                    className={`nav-link ${isActive("/marketing/campaigns") ? "active" : ""}`}
                  >
                    <i className="nav-icon bi bi-circle"></i>
                    <p>Campaigns</p>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link href="/marketing/email" className={`nav-link ${isActive("/marketing/email") ? "active" : ""}`}>
                    <i className="nav-icon bi bi-circle"></i>
                    <p>Email Marketing</p>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link
                    href="/marketing/social"
                    className={`nav-link ${isActive("/marketing/social") ? "active" : ""}`}
                  >
                    <i className="nav-icon bi bi-circle"></i>
                    <p>Social Media</p>
                  </Link>
                </li>
              </ul>
            </li>

            {/* Reports Menu */}
            <li className={`nav-item ${menuOpen.reports ? "menu-open" : ""}`}>
              <a
                href="#"
                className={`nav-link ${isMenuActive(["/reports"]) ? "active" : ""}`}
                onClick={() => toggleMenu("reports")}
              >
                <i className="nav-icon bi bi-bar-chart-fill"></i>
                <p>
                  Reports
                  <i className="nav-arrow bi bi-chevron-right"></i>
                </p>
              </a>
              <ul className="nav nav-treeview">
                <li className="nav-item">
                  <Link href="/reports/sales" className={`nav-link ${isActive("/reports/sales") ? "active" : ""}`}>
                    <i className="nav-icon bi bi-circle"></i>
                    <p>Sales Report</p>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link
                    href="/reports/activity"
                    className={`nav-link ${isActive("/reports/activity") ? "active" : ""}`}
                  >
                    <i className="nav-icon bi bi-circle"></i>
                    <p>Activity Report</p>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link
                    href="/reports/performance"
                    className={`nav-link ${isActive("/reports/performance") ? "active" : ""}`}
                  >
                    <i className="nav-icon bi bi-circle"></i>
                    <p>Performance Report</p>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link href="/reports/leads" className={`nav-link ${isActive("/reports/leads") ? "active" : ""}`}>
                    <i className="nav-icon bi bi-circle"></i>
                    <p>Lead Report</p>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link
                    href="/reports/forecast"
                    className={`nav-link ${isActive("/reports/forecast") ? "active" : ""}`}
                  >
                    <i className="nav-icon bi bi-circle"></i>
                    <p>Sales Forecast</p>
                  </Link>
                </li>
              </ul>
            </li>

            {/* Settings Menu */}
            <li className={`nav-item ${menuOpen.settings ? "menu-open" : ""}`}>
              <a
                href="#"
                className={`nav-link ${isMenuActive(["/settings"]) ? "active" : ""}`}
                onClick={() => toggleMenu("settings")}
              >
                <i className="nav-icon bi bi-gear-fill"></i>
                <p>
                  Settings
                  <i className="nav-arrow bi bi-chevron-right"></i>
                </p>
              </a>
              <ul className="nav nav-treeview">
                <li className="nav-item">
                  <Link
                    href="/settings/profile"
                    className={`nav-link ${isActive("/settings/profile") ? "active" : ""}`}
                  >
                    <i className="nav-icon bi bi-circle"></i>
                    <p>Profile</p>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link href="/settings/users" className={`nav-link ${isActive("/settings/users") ? "active" : ""}`}>
                    <i className="nav-icon bi bi-circle"></i>
                    <p>Users</p>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link
                    href="/settings/company"
                    className={`nav-link ${isActive("/settings/company") ? "active" : ""}`}
                  >
                    <i className="nav-icon bi bi-circle"></i>
                    <p>Company</p>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link
                    href="/settings/workflow"
                    className={`nav-link ${isActive("/settings/workflow") ? "active" : ""}`}
                  >
                    <i className="nav-icon bi bi-circle"></i>
                    <p>Workflow</p>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link
                    href="/settings/integrations"
                    className={`nav-link ${isActive("/settings/integrations") ? "active" : ""}`}
                  >
                    <i className="nav-icon bi bi-circle"></i>
                    <p>Integrations</p>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link
                    href="/settings/customfields"
                    className={`nav-link ${isActive("/settings/customfields") ? "active" : ""}`}
                  >
                    <i className="nav-icon bi bi-circle"></i>
                    <p>Custom Fields</p>
                  </Link>
                </li>
              </ul>
            </li>

            <li className="nav-header">HELP</li>
            <li className="nav-item">
              <Link href="/documentation" className="nav-link">
                <i className="nav-icon bi bi-book"></i>
                <p>Documentation</p>
              </Link>
            </li>
            <li className="nav-item">
              <Link href="/support" className="nav-link">
                <i className="nav-icon bi bi-question-circle"></i>
                <p>Support</p>
              </Link>
            </li>
          </ul>
        </nav>
      </div>
    </aside>
  )
}

