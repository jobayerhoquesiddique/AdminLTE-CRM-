import type React from "react"
import Link from "next/link"

interface TimelineActivity {
  id: string
  type: string
  title: string
  date: string
  time: string
  user: string
}

interface ActivityTimelineProps {
  activities: TimelineActivity[]
  title?: string
  maxItems?: number
}

export const ActivityTimeline: React.FC<ActivityTimelineProps> = ({
  activities,
  title = "Activity Timeline",
  maxItems = 10,
}) => {
  const displayActivities = activities.slice(0, maxItems)

  // Get icon based on activity type
  const getActivityIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case "call":
        return "bi-telephone"
      case "email":
        return "bi-envelope"
      case "meeting":
        return "bi-calendar-event"
      case "task":
        return "bi-check2-square"
      case "note":
        return "bi-sticky"
      case "deal":
        return "bi-currency-dollar"
      case "lead":
        return "bi-funnel"
      default:
        return "bi-activity"
    }
  }

  // Get color based on activity type
  const getActivityColor = (type: string) => {
    switch (type.toLowerCase()) {
      case "call":
        return "bg-info"
      case "email":
        return "bg-primary"
      case "meeting":
        return "bg-warning"
      case "task":
        return "bg-success"
      case "note":
        return "bg-secondary"
      case "deal":
        return "bg-danger"
      case "lead":
        return "bg-purple"
      default:
        return "bg-gray"
    }
  }

  return (
    <div className="card">
      <div className="card-header">
        <h3 className="card-title">{title}</h3>
        <div className="card-tools">
          <button type="button" className="btn btn-tool" data-lte-toggle="card-collapse">
            <i className="bi bi-minus"></i>
          </button>
        </div>
      </div>
      <div className="card-body">
        <div className="timeline">
          {displayActivities.map((activity, index) => (
            <div key={activity.id} className="timeline-item">
              <div className="timeline-time text-muted">
                <i className="bi bi-clock me-1"></i> {activity.time}
              </div>
              <h3 className="timeline-header">
                <span className={`badge ${getActivityColor(activity.type)} me-2`}>
                  <i className={`bi ${getActivityIcon(activity.type)}`}></i> {activity.type}
                </span>
                <span className="text-muted">{activity.date}</span>
              </h3>
              <div className="timeline-body">
                <p>{activity.title}</p>
                <p className="text-muted mb-0">
                  <small>
                    <i className="bi bi-person me-1"></i> {activity.user}
                  </small>
                </p>
              </div>
            </div>
          ))}
          {activities.length > maxItems && (
            <div className="text-center mt-3">
              <Link href="/reports/activity" className="btn btn-sm btn-primary">
                View All Activities
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

