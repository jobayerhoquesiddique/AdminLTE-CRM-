import type React from "react"
import type { Deal, Lead, Task, Activity } from "@/lib/context/CrmContext"
import { formatCurrency } from "@/lib/utils/dataProcessing"

interface PerformanceMetricsProps {
  deals: Deal[]
  leads: Lead[]
  tasks: Task[]
  activities: Activity[]
  previousPeriod?: {
    deals: Deal[]
    leads: Lead[]
    activities: Activity[]
  }
}

export const PerformanceMetrics: React.FC<PerformanceMetricsProps> = ({
  deals,
  leads,
  tasks,
  activities,
  previousPeriod,
}) => {
  // Calculate current period metrics
  const currentRevenue = deals.filter((deal) => deal.stage === "Closed Won").reduce((sum, deal) => sum + deal.value, 0)

  const currentDealsWon = deals.filter((deal) => deal.stage === "Closed Won").length
  const currentDealsLost = deals.filter((deal) => deal.stage === "Closed Lost").length
  const currentWinRate =
    currentDealsWon + currentDealsLost > 0
      ? Math.round((currentDealsWon / (currentDealsWon + currentDealsLost)) * 100)
      : 0

  const currentLeadConversionRate = leads.length > 0 ? Math.round((currentDealsWon / leads.length) * 100) : 0

  const currentAvgDealSize = currentDealsWon > 0 ? currentRevenue / currentDealsWon : 0

  // Calculate previous period metrics if available
  let revenueChange = 0
  let winRateChange = 0
  let leadConversionChange = 0
  let avgDealSizeChange = 0

  if (previousPeriod) {
    const prevRevenue = previousPeriod.deals
      .filter((deal) => deal.stage === "Closed Won")
      .reduce((sum, deal) => sum + deal.value, 0)

    const prevDealsWon = previousPeriod.deals.filter((deal) => deal.stage === "Closed Won").length
    const prevDealsLost = previousPeriod.deals.filter((deal) => deal.stage === "Closed Lost").length
    const prevWinRate =
      prevDealsWon + prevDealsLost > 0 ? Math.round((prevDealsWon / (prevDealsWon + prevDealsLost)) * 100) : 0

    const prevLeadConversionRate =
      previousPeriod.leads.length > 0 ? Math.round((prevDealsWon / previousPeriod.leads.length) * 100) : 0

    const prevAvgDealSize = prevDealsWon > 0 ? prevRevenue / prevDealsWon : 0

    // Calculate percentage changes
    revenueChange = prevRevenue > 0 ? Math.round(((currentRevenue - prevRevenue) / prevRevenue) * 100) : 100

    winRateChange = prevWinRate > 0 ? currentWinRate - prevWinRate : currentWinRate

    leadConversionChange =
      prevLeadConversionRate > 0 ? currentLeadConversionRate - prevLeadConversionRate : currentLeadConversionRate

    avgDealSizeChange =
      prevAvgDealSize > 0 ? Math.round(((currentAvgDealSize - prevAvgDealSize) / prevAvgDealSize) * 100) : 100
  }

  return (
    <div className="card">
      <div className="card-header">
        <h3 className="card-title">Performance Metrics</h3>
        <div className="card-tools">
          <button type="button" className="btn btn-tool" data-lte-toggle="card-collapse">
            <i className="bi bi-minus"></i>
          </button>
        </div>
      </div>
      <div className="card-body p-0">
        <div className="row">
          <div className="col-md-3 col-sm-6">
            <div className="info-box">
              <span className="info-box-icon bg-info">
                <i className="bi bi-cash-stack"></i>
              </span>
              <div className="info-box-content">
                <span className="info-box-text">Revenue</span>
                <span className="info-box-number">{formatCurrency(currentRevenue)}</span>
                <div className={`text-${revenueChange >= 0 ? "success" : "danger"}`}>
                  <i className={`bi bi-arrow-${revenueChange >= 0 ? "up" : "down"}`}></i> {Math.abs(revenueChange)}%
                </div>
              </div>
            </div>
          </div>
          <div className="col-md-3 col-sm-6">
            <div className="info-box">
              <span className="info-box-icon bg-success">
                <i className="bi bi-trophy"></i>
              </span>
              <div className="info-box-content">
                <span className="info-box-text">Win Rate</span>
                <span className="info-box-number">{currentWinRate}%</span>
                <div className={`text-${winRateChange >= 0 ? "success" : "danger"}`}>
                  <i className={`bi bi-arrow-${winRateChange >= 0 ? "up" : "down"}`}></i> {Math.abs(winRateChange)}%
                </div>
              </div>
            </div>
          </div>
          <div className="col-md-3 col-sm-6">
            <div className="info-box">
              <span className="info-box-icon bg-warning">
                <i className="bi bi-funnel"></i>
              </span>
              <div className="info-box-content">
                <span className="info-box-text">Lead Conversion</span>
                <span className="info-box-number">{currentLeadConversionRate}%</span>
                <div className={`text-${leadConversionChange >= 0 ? "success" : "danger"}`}>
                  <i className={`bi bi-arrow-${leadConversionChange >= 0 ? "up" : "down"}`}></i>{" "}
                  {Math.abs(leadConversionChange)}%
                </div>
              </div>
            </div>
          </div>
          <div className="col-md-3 col-sm-6">
            <div className="info-box">
              <span className="info-box-icon bg-danger">
                <i className="bi bi-graph-up"></i>
              </span>
              <div className="info-box-content">
                <span className="info-box-text">Avg. Deal Size</span>
                <span className="info-box-number">{formatCurrency(currentAvgDealSize)}</span>
                <div className={`text-${avgDealSizeChange >= 0 ? "success" : "danger"}`}>
                  <i className={`bi bi-arrow-${avgDealSizeChange >= 0 ? "up" : "down"}`}></i>{" "}
                  {Math.abs(avgDealSizeChange)}%
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

