"use client"

import type React from "react"

import { useEffect, useRef } from "react"
import type { Deal } from "@/lib/context/CrmContext"

interface DealPipelineChartProps {
  deals: Deal[]
}

const DealPipelineChart: React.FC<DealPipelineChartProps> = ({ deals }) => {
  const chartRef = useRef<HTMLCanvasElement>(null)
  const chartInstanceRef = useRef<any>(null)

  useEffect(() => {
    const loadChart = async () => {
      try {
        if (!chartRef.current) return

        // Group deals by stage
        const stageGroups = deals.reduce((acc: Record<string, number>, deal) => {
          if (!acc[deal.stage]) {
            acc[deal.stage] = 0
          }
          acc[deal.stage] += deal.value
          return acc
        }, {})

        // Sort stages in pipeline order
        const pipelineOrder = ["Prospect", "Qualification", "Proposal", "Negotiation", "Closed Won", "Closed Lost"]

        const sortedStages = Object.keys(stageGroups).sort(
          (a, b) => pipelineOrder.indexOf(a) - pipelineOrder.indexOf(b),
        )

        const labels = sortedStages
        const data = sortedStages.map((stage) => stageGroups[stage])

        // Define colors for each stage
        const colors = {
          Prospect: "#6c757d",
          Qualification: "#17a2b8",
          Proposal: "#ffc107",
          Negotiation: "#fd7e14",
          "Closed Won": "#28a745",
          "Closed Lost": "#dc3545",
        }

        const backgroundColors = sortedStages.map((stage) => colors[stage as keyof typeof colors] || "#6c757d")

        // Load Chart.js dynamically
        const Chart = (await import("chart.js/auto")).default

        // Destroy previous chart if it exists
        if (chartInstanceRef.current) {
          chartInstanceRef.current.destroy()
        }

        // Create new chart
        chartInstanceRef.current = new Chart(chartRef.current, {
          type: "bar",
          data: {
            labels,
            datasets: [
              {
                label: "Deal Value",
                data,
                backgroundColor: backgroundColors,
                borderColor: backgroundColors,
                borderWidth: 1,
              },
            ],
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
              y: {
                beginAtZero: true,
                title: {
                  display: true,
                  text: "Value ($)",
                },
              },
            },
            plugins: {
              tooltip: {
                callbacks: {
                  label: (context) => `$${context.parsed.y.toLocaleString()}`,
                },
              },
            },
          },
        })
      } catch (error) {
        console.error("Error loading deal pipeline chart:", error)
      }
    }

    loadChart()

    // Cleanup function
    return () => {
      if (chartInstanceRef.current) {
        chartInstanceRef.current.destroy()
      }
    }
  }, [deals])

  return <canvas ref={chartRef} height="300"></canvas>
}

export default DealPipelineChart

