"use client"

import type React from "react"
import { useState, useEffect, useRef } from "react"
import { useVirtualizedList } from "@/lib/hooks/useVirtualizedList"

interface Column<T> {
  key: string
  header: React.ReactNode
  width?: number | string
  render?: (item: T, index: number) => React.ReactNode
  sortable?: boolean
}

interface VirtualizedTableProps<T> {
  data: T[]
  columns: Column<T>[]
  rowHeight?: number
  headerHeight?: number
  height?: number | string
  width?: number | string
  onRowClick?: (item: T, index: number) => void
  onSort?: (key: string, direction: "asc" | "desc") => void
  sortKey?: string
  sortDirection?: "asc" | "desc"
  rowClassName?: (item: T, index: number) => string
  emptyMessage?: React.ReactNode
}

export function VirtualizedTable<T>({
  data,
  columns,
  rowHeight = 48,
  headerHeight = 48,
  height = 400,
  width = "100%",
  onRowClick,
  onSort,
  sortKey,
  sortDirection = "asc",
  rowClassName,
  emptyMessage = "No data available",
}: VirtualizedTableProps<T>) {
  const [containerWidth, setContainerWidth] = useState(0)
  const containerRef = useRef<HTMLDivElement>(null)

  // Calculate column widths
  const columnWidths = columns.map((column) => {
    if (typeof column.width === "number") {
      return column.width
    }
    if (typeof column.width === "string" && column.width.endsWith("%")) {
      const percentage = Number.parseFloat(column.width) / 100
      return containerWidth * percentage
    }
    return containerWidth / columns.length
  })

  // Set up virtualized list
  const { virtualItems, totalHeight, containerProps } = useVirtualizedList(data, {
    itemHeight: rowHeight,
    overscan: 5,
  })

  // Handle sort
  const handleHeaderClick = (column: Column<T>) => {
    if (column.sortable && onSort) {
      const newDirection = sortKey === column.key && sortDirection === "asc" ? "desc" : "asc"
      onSort(column.key, newDirection)
    }
  }

  // Measure container width on mount and resize
  useEffect(() => {
    const updateWidth = () => {
      if (containerRef.current) {
        setContainerWidth(containerRef.current.clientWidth)
      }
    }

    updateWidth()
    window.addEventListener("resize", updateWidth)

    return () => {
      window.removeEventListener("resize", updateWidth)
    }
  }, [])

  // Render empty state if no data
  if (data.length === 0) {
    return (
      <div className="text-center p-4" style={{ height, width }}>
        {emptyMessage}
      </div>
    )
  }

  return (
    <div
      ref={containerRef}
      className="virtualized-table"
      style={{ height, width, overflow: "hidden", position: "relative" }}
    >
      {/* Table Header */}
      <div
        className="virtualized-table-header"
        style={{
          height: headerHeight,
          width: "100%",
          position: "sticky",
          top: 0,
          zIndex: 1,
          display: "flex",
          backgroundColor: "var(--bs-body-bg)",
          borderBottom: "1px solid var(--bs-border-color)",
        }}
      >
        {columns.map((column, columnIndex) => (
          <div
            key={column.key}
            className={`virtualized-table-header-cell ${column.sortable ? "sortable" : ""}`}
            style={{
              width: columnWidths[columnIndex],
              padding: "0.5rem",
              fontWeight: "bold",
              cursor: column.sortable ? "pointer" : "default",
              display: "flex",
              alignItems: "center",
            }}
            onClick={() => handleHeaderClick(column)}
          >
            {column.header}
            {column.sortable && sortKey === column.key && (
              <span className="ms-1">
                <i className={`bi bi-arrow-${sortDirection === "asc" ? "up" : "down"}`}></i>
              </span>
            )}
          </div>
        ))}
      </div>

      {/* Table Body */}
      <div
        {...containerProps}
        style={{
          ...containerProps.style,
          height: `calc(${typeof height === "number" ? `${height}px` : height} - ${headerHeight}px)`,
          width: "100%",
          position: "relative",
        }}
      >
        <div style={{ height: totalHeight, position: "relative" }}>
          {virtualItems.map(({ index, offsetTop, item }) => (
            <div
              key={index}
              className={`virtualized-table-row ${rowClassName ? rowClassName(item, index) : ""}`}
              style={{
                position: "absolute",
                top: offsetTop,
                left: 0,
                width: "100%",
                height: rowHeight,
                display: "flex",
                alignItems: "center",
                borderBottom: "1px solid var(--bs-border-color)",
                cursor: onRowClick ? "pointer" : "default",
              }}
              onClick={() => onRowClick && onRowClick(item, index)}
            >
              {columns.map((column, columnIndex) => (
                <div
                  key={`${index}-${column.key}`}
                  className="virtualized-table-cell"
                  style={{
                    width: columnWidths[columnIndex],
                    padding: "0.5rem",
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    whiteSpace: "nowrap",
                  }}
                >
                  {column.render ? column.render(item, index) : (item as any)[column.key]}
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

