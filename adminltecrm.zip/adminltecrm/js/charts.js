import { Chart } from "@/components/ui/chart"
// Initialize charts for the dashboard
function initDashboardCharts() {
  const data = loadDataFromLocalStorage()

  // Sales Performance Chart
  const salesCtx = document.getElementById("salesPerformanceChart")
  if (salesCtx) {
    // Group deals by month and user
    const monthlyData = {}
    const users = new Set()

    data.deals.forEach((deal) => {
      // Only include closed won deals
      if (deal.stage !== "Closed Won") return

      const date = new Date(deal.created)
      const month = date.toLocaleString("default", { month: "short" })
      const year = date.getFullYear()
      const monthYear = `${month} ${year}`

      if (!monthlyData[monthYear]) {
        monthlyData[monthYear] = {}
      }

      if (!monthlyData[monthYear][deal.assignedTo]) {
        monthlyData[monthYear][deal.assignedTo] = 0
      }

      monthlyData[monthYear][deal.assignedTo] += deal.value
      users.add(deal.assignedTo)
    })

    // Sort months chronologically
    const sortedMonths = Object.keys(monthlyData).sort((a, b) => {
      const dateA = new Date(a)
      const dateB = new Date(b)
      return dateA.getTime() - dateB.getTime()
    })

    // Prepare datasets for each user
    const datasets = Array.from(users).map((user, index) => {
      // Map user IDs to names
      const userNames = {
        user1: "John Doe",
        user2: "Sarah Johnson",
        user3: "Michael Brown",
      }

      const colors = ["#0d6efd", "#20c997", "#ffc107", "#dc3545", "#6c757d"]

      return {
        label: userNames[user] || user,
        data: sortedMonths.map((month) => monthlyData[month][user] || 0),
        backgroundColor: colors[index % colors.length],
        borderColor: colors[index % colors.length],
        borderWidth: 1,
      }
    })

    new Chart(salesCtx, {
      type: "bar",
      data: {
        labels: sortedMonths,
        datasets,
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: "Revenue ($)",
            },
          },
        },
        plugins: {
          tooltip: {
            callbacks: {
              label: (context) => `${context.dataset.label}: $${context.parsed.y.toLocaleString()}`,
            },
          },
        },
      },
    })
  }

  // Deal Pipeline Chart
  const pipelineCtx = document.getElementById("dealPipelineChart")
  if (pipelineCtx) {
    // Group deals by stage
    const stageGroups = data.deals.reduce((acc, deal) => {
      if (!acc[deal.stage]) {
        acc[deal.stage] = 0
      }
      acc[deal.stage] += deal.value
      return acc
    }, {})

    // Sort stages in pipeline order
    const pipelineOrder = ["Prospect", "Qualification", "Proposal", "Negotiation", "Closed Won", "Closed Lost"]

    const sortedStages = Object.keys(stageGroups).sort((a, b) => pipelineOrder.indexOf(a) - pipelineOrder.indexOf(b))

    const labels = sortedStages
    const chartData = sortedStages.map((stage) => stageGroups[stage])

    // Define colors for each stage
    const colors = {
      Prospect: "#6c757d",
      Qualification: "#17a2b8",
      Proposal: "#ffc107",
      Negotiation: "#fd7e14",
      "Closed Won": "#28a745",
      "Closed Lost": "#dc3545",
    }

    const backgroundColors = sortedStages.map((stage) => colors[stage] || "#6c757d")

    new Chart(pipelineCtx, {
      type: "bar",
      data: {
        labels,
        datasets: [
          {
            label: "Deal Value",
            data: chartData,
            backgroundColor: backgroundColors,
            borderColor: backgroundColors,
            borderWidth: 1,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: "Value ($)",
            },
          },
        },
        plugins: {
          tooltip: {
            callbacks: {
              label: (context) => `$${context.parsed.y.toLocaleString()}`,
            },
          },
        },
      },
    })
  }

  // Lead Source Chart
  const leadSourceCtx = document.getElementById("leadSourceChart")
  if (leadSourceCtx) {
    // Group leads by source
    const sourceGroups = data.leads.reduce((acc, lead) => {
      if (!acc[lead.source]) {
        acc[lead.source] = 0
      }
      acc[lead.source]++
      return acc
    }, {})

    const labels = Object.keys(sourceGroups)
    const chartData = Object.values(sourceGroups)

    // Define colors for the chart
    const backgroundColors = [
      "#0d6efd",
      "#20c997",
      "#ffc107",
      "#dc3545",
      "#6c757d",
      "#6610f2",
      "#fd7e14",
      "#198754",
      "#0dcaf0",
    ]

    new Chart(leadSourceCtx, {
      type: "doughnut",
      data: {
        labels,
        datasets: [
          {
            data: chartData,
            backgroundColor: backgroundColors.slice(0, labels.length),
            borderWidth: 1,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: "right",
          },
          tooltip: {
            callbacks: {
              label: (context) => {
                const label = context.label || ""
                const value = context.parsed || 0
                const total = context.dataset.data.reduce((a, b) => a + b, 0)
                const percentage = Math.round((value * 100) / total)
                return `${label}: ${value} (${percentage}%)`
              },
            },
          },
        },
      },
    })
  }
}

// Initialize charts for the sales report
function initSalesReportCharts() {
  const data = loadDataFromLocalStorage()

  // Monthly Revenue Chart
  const revenueCtx = document.getElementById("revenueChart")
  if (revenueCtx) {
    // Group deals by month
    const monthlyRevenue = {}

    data.deals.forEach((deal) => {
      if (deal.stage !== "Closed Won") return

      const date = new Date(deal.created)
      const month = date.toLocaleString("default", { month: "short" })

      if (!monthlyRevenue[month]) {
        monthlyRevenue[month] = 0
      }

      monthlyRevenue[month] += deal.value
    })

    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    const chartData = months.map((month) => monthlyRevenue[month] || 0)

    new Chart(revenueCtx, {
      type: "line",
      data: {
        labels: months,
        datasets: [
          {
            label: "Monthly Revenue",
            data: chartData,
            fill: false,
            borderColor: "#0d6efd",
            tension: 0.1,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: "Revenue ($)",
            },
          },
        },
      },
    })
  }

  // Deal Status Chart
  const dealStatusCtx = document.getElementById("dealStatusChart")
  if (dealStatusCtx) {
    // Count deals by status
    const dealStatus = {
      "Closed Won": 0,
      "Closed Lost": 0,
      "In Progress": 0,
    }

    data.deals.forEach((deal) => {
      if (deal.stage === "Closed Won") {
        dealStatus["Closed Won"]++
      } else if (deal.stage === "Closed Lost") {
        dealStatus["Closed Lost"]++
      } else {
        dealStatus["In Progress"]++
      }
    })

    new Chart(dealStatusCtx, {
      type: "pie",
      data: {
        labels: Object.keys(dealStatus),
        datasets: [
          {
            data: Object.values(dealStatus),
            backgroundColor: ["#28a745", "#dc3545", "#ffc107"],
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
      },
    })
  }
}

// Mock function to simulate loading data from local storage
function loadDataFromLocalStorage() {
  // Replace this with your actual data loading logic
  return {
    deals: [
      { assignedTo: "user1", stage: "Closed Won", value: 1000, created: "2024-01-15" },
      { assignedTo: "user2", stage: "Prospect", value: 500, created: "2024-02-20" },
      { assignedTo: "user1", stage: "Closed Won", value: 1500, created: "2024-02-28" },
      { assignedTo: "user3", stage: "Negotiation", value: 800, created: "2024-03-05" },
      { assignedTo: "user2", stage: "Closed Lost", value: 300, created: "2024-03-10" },
      { assignedTo: "user1", stage: "Closed Won", value: 1200, created: "2024-03-22" },
      { assignedTo: "user3", stage: "Closed Won", value: 900, created: "2024-04-01" },
      { assignedTo: "user2", stage: "Proposal", value: 700, created: "2024-04-12" },
      { assignedTo: "user1", stage: "Closed Won", value: 1100, created: "2024-04-25" },
      { assignedTo: "user3", stage: "Closed Won", value: 1300, created: "2024-05-03" },
      { assignedTo: "user2", stage: "Closed Won", value: 600, created: "2024-05-18" },
      { assignedTo: "user1", stage: "Closed Won", value: 1400, created: "2024-05-29" },
      { assignedTo: "user3", stage: "Closed Won", value: 1000, created: "2024-06-07" },
      { assignedTo: "user2", stage: "Closed Won", value: 800, created: "2024-06-14" },
      { assignedTo: "user1", stage: "Closed Won", value: 1600, created: "2024-06-21" },
      { assignedTo: "user1", stage: "Closed Won", value: 1000, created: "2024-07-15" },
      { assignedTo: "user2", stage: "Prospect", value: 500, created: "2024-08-20" },
      { assignedTo: "user1", stage: "Closed Won", value: 1500, created: "2024-08-28" },
      { assignedTo: "user3", stage: "Negotiation", value: 800, created: "2024-09-05" },
      { assignedTo: "user2", stage: "Closed Lost", value: 300, created: "2024-09-10" },
      { assignedTo: "user1", stage: "Closed Won", value: 1200, created: "2024-10-22" },
      { assignedTo: "user3", stage: "Closed Won", value: 900, created: "2024-10-01" },
      { assignedTo: "user2", stage: "Proposal", value: 700, created: "2024-11-12" },
      { assignedTo: "user1", stage: "Closed Won", value: 1100, created: "2024-11-25" },
      { assignedTo: "user3", stage: "Closed Won", value: 1300, created: "2024-12-03" },
      { assignedTo: "user2", stage: "Closed Won", value: 600, created: "2024-12-18" },
      { assignedTo: "user1", stage: "Closed Won", value: 1400, created: "2024-12-29" },
    ],
    leads: [
      { source: "Website" },
      { source: "Referral" },
      { source: "Email" },
      { source: "Website" },
      { source: "Social Media" },
      { source: "Referral" },
      { source: "Email" },
      { source: "Website" },
      { source: "Social Media" },
      { source: "Website" },
      { source: "Referral" },
      { source: "Email" },
      { source: "Website" },
      { source: "Social Media" },
      { source: "Referral" },
      { source: "Email" },
      { source: "Website" },
      { source: "Social Media" },
      { source: "Website" },
      { source: "Referral" },
      { source: "Email" },
      { source: "Website" },
      { source: "Social Media" },
      { source: "Referral" },
      { source: "Email" },
      { source: "Website" },
      { source: "Social Media" },
    ],
  }
}

