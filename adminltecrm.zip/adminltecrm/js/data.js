// Sample data for the CRM application
const crmData = {
  // Customers data
  customers: [
    {
      id: "cust1",
      name: "Acme Inc.",
      email: "contact@acmeinc.com",
      phone: "(123) 456-7890",
      company: "Acme Inc.",
      status: "Active",
      industry: "Technology",
      created: "2023-01-15",
      lastContact: "2023-03-10",
      address: "123 Main St, Anytown, CA 12345",
      notes: "Key enterprise client with multiple ongoing projects.",
      assignedTo: "user1",
    },
    {
      id: "cust2",
      name: "TechGiant Corp",
      email: "info@techgiant.com",
      phone: "(234) 567-8901",
      company: "TechGiant Corp",
      status: "Active",
      industry: "Software",
      created: "2023-02-20",
      lastContact: "2023-03-15",
      address: "456 Tech Blvd, Innovation City, CA 67890",
      notes: "Interested in our enterprise software package.",
      assignedTo: "user2",
    },
    {
      id: "cust3",
      name: "Startup Solutions",
      email: "hello@startupsolutions.com",
      phone: "(345) 678-9012",
      company: "Startup Solutions",
      status: "Active",
      industry: "Consulting",
      created: "2023-01-05",
      lastContact: "2023-03-01",
      address: "789 Venture Ave, Startup City, CA 54321",
      notes: "New client with high growth potential.",
      assignedTo: "user3",
    },
    {
      id: "cust4",
      name: "Global Enterprises",
      email: "contact@globalenterprises.com",
      phone: "(456) 789-0123",
      company: "Global Enterprises",
      status: "Inactive",
      industry: "Manufacturing",
      created: "2022-11-10",
      lastContact: "2023-02-15",
      address: "101 Industry Pkwy, Manufacturing Town, CA 13579",
      notes: "International client with multiple locations.",
      assignedTo: "user1",
    },
    {
      id: "cust5",
      name: "Local Business LLC",
      email: "info@localbusiness.com",
      phone: "(567) 890-1234",
      company: "Local Business LLC",
      status: "Active",
      industry: "Retail",
      created: "2023-03-01",
      lastContact: "2023-03-20",
      address: "202 Main St, Hometown, CA 24680",
      notes: "Small local business with consistent orders.",
      assignedTo: "user2",
    },
  ],

  // Leads data
  leads: [
    {
      id: "lead1",
      name: "John Smith",
      email: "john.smith@example.com",
      phone: "(123) 456-7890",
      company: "Future Tech",
      status: "New",
      source: "Website",
      created: "2023-03-15",
      lastContact: "2023-03-15",
      notes: "Interested in our enterprise software package.",
      assignedTo: "user1",
      estimatedValue: 15000,
      score: 65,
    },
    {
      id: "lead2",
      name: "Sarah Johnson",
      email: "sarah.johnson@example.com",
      phone: "(234) 567-8901",
      company: "Innovative Solutions",
      status: "Contacted",
      source: "Referral",
      created: "2023-03-10",
      lastContact: "2023-03-12",
      notes: "Referred by TechGiant Corp. Looking for IT consulting services.",
      assignedTo: "user2",
      estimatedValue: 10000,
      score: 45,
    },
    {
      id: "lead3",
      name: "Michael Brown",
      email: "michael.brown@example.com",
      phone: "(345) 678-9012",
      company: "Growth Startup",
      status: "Qualified",
      source: "Trade Show",
      created: "2023-03-05",
      lastContact: "2023-03-08",
      notes: "Met at the Tech Expo. Needs help with cloud migration.",
      assignedTo: "user3",
      estimatedValue: 20000,
      score: 78,
    },
    {
      id: "lead4",
      name: "Emily Davis",
      email: "emily.davis@example.com",
      phone: "(456) 789-0123",
      company: "Davis Enterprises",
      status: "Negotiation",
      source: "Email Campaign",
      created: "2023-02-28",
      lastContact: "2023-03-14",
      notes: "Responded to our Q1 email campaign. Interested in our premium support package.",
      assignedTo: "user1",
      estimatedValue: 8000,
      score: 92,
    },
    {
      id: "lead5",
      name: "Robert Wilson",
      email: "robert.wilson@example.com",
      phone: "(567) 890-1234",
      company: "Wilson & Co",
      status: "New",
      source: "Social Media",
      created: "2023-03-18",
      lastContact: "2023-03-18",
      notes: "Found us through LinkedIn. Looking for a CRM solution.",
      assignedTo: "user2",
      estimatedValue: 12000,
      score: 35,
    },
  ],

  // Deals data
  deals: [
    {
      id: "deal1",
      name: "Enterprise Software Package",
      customer: "cust1",
      value: 15000,
      stage: "Closed Won",
      probability: 100,
      expectedCloseDate: "2023-03-15",
      created: "2023-01-20",
      lastUpdated: "2023-03-15",
      assignedTo: "user1",
      products: ["prod1", "prod2"],
      notes: "Successfully closed deal for enterprise software package.",
    },
    {
      id: "deal2",
      name: "Consulting Services",
      customer: "cust2",
      value: 8500,
      stage: "Negotiation",
      probability: 75,
      expectedCloseDate: "2023-04-10",
      created: "2023-02-15",
      lastUpdated: "2023-03-20",
      assignedTo: "user2",
      products: ["prod3"],
      notes: "Client is considering our proposal for consulting services.",
    },
    {
      id: "deal3",
      name: "Cloud Migration",
      customer: "cust3",
      value: 12000,
      stage: "Proposal",
      probability: 50,
      expectedCloseDate: "2023-05-01",
      created: "2023-03-01",
      lastUpdated: "2023-03-18",
      assignedTo: "user3",
      products: ["prod4", "prod5"],
      notes: "Sent proposal for cloud migration project.",
    },
    {
      id: "deal4",
      name: "Support Contract",
      customer: "cust4",
      value: 5000,
      stage: "Closed Lost",
      probability: 0,
      expectedCloseDate: "2023-03-01",
      created: "2023-01-10",
      lastUpdated: "2023-03-01",
      assignedTo: "user1",
      products: ["prod6"],
      notes: "Client decided to go with a competitor.",
    },
    {
      id: "deal5",
      name: "Hardware Upgrade",
      customer: "cust5",
      value: 7200,
      stage: "Closed Won",
      probability: 100,
      expectedCloseDate: "2023-03-10",
      created: "2023-02-01",
      lastUpdated: "2023-03-10",
      assignedTo: "user2",
      products: ["prod7", "prod8"],
      notes: "Successfully closed deal for hardware upgrade.",
    },
  ],

  // Tasks data
  tasks: [
    {
      id: "task1",
      title: "Call John about proposal",
      description: "Follow up with John Smith about the enterprise software proposal.",
      status: "Pending",
      priority: "High",
      dueDate: "2023-03-25",
      created: "2023-03-15",
      assignedTo: "user1",
      relatedTo: {
        type: "lead",
        id: "lead1",
      },
    },
    {
      id: "task2",
      title: "Prepare presentation for client",
      description: "Create a presentation for the upcoming meeting with TechGiant Corp.",
      status: "In Progress",
      priority: "Medium",
      dueDate: "2023-03-26",
      created: "2023-03-18",
      assignedTo: "user2",
      relatedTo: {
        type: "customer",
        id: "cust2",
      },
    },
    {
      id: "task3",
      title: "Send follow-up email to leads",
      description: "Send follow-up emails to all leads from the trade show.",
      status: "Pending",
      priority: "Medium",
      dueDate: "2023-03-27",
      created: "2023-03-17",
      assignedTo: "user3",
      relatedTo: {
        type: "lead",
        id: "lead3",
      },
    },
    {
      id: "task4",
      title: "Update sales forecast",
      description: "Update the Q2 sales forecast with the latest deal information.",
      status: "Pending",
      priority: "Low",
      dueDate: "2023-03-28",
      created: "2023-03-19",
      assignedTo: "user1",
      relatedTo: {
        type: "deal",
        id: "deal2",
      },
    },
    {
      id: "task5",
      title: "Schedule team meeting",
      description: "Schedule a team meeting to discuss the upcoming product launch.",
      status: "Completed",
      priority: "Medium",
      dueDate: "2023-03-29",
      created: "2023-03-10",
      assignedTo: "user2",
      relatedTo: {
        type: "other",
        id: "internal",
      },
    },
  ],

  // Activities data
  activities: [
    {
      id: "act1",
      type: "Call",
      description: "Called Acme Inc. about the enterprise software package proposal.",
      date: "2023-03-22",
      time: "10:00 am",
      user: "user1",
      relatedTo: {
        type: "customer",
        id: "cust1",
      },
    },
    {
      id: "act2",
      type: "Email",
      description: "Sent follow-up email to TechGiant Corp.",
      date: "2023-03-22",
      time: "9:30 am",
      user: "user2",
      relatedTo: {
        type: "customer",
        id: "cust2",
      },
    },
    {
      id: "act3",
      type: "Meeting",
      description: "Initial consultation about their needs.",
      date: "2023-03-21",
      time: "2:15 pm",
      user: "user3",
      relatedTo: {
        type: "customer",
        id: "cust3",
      },
    },
    {
      id: "act4",
      type: "Task",
      description: "Updated customer information and contact details.",
      date: "2023-03-21",
      time: "1:10 pm",
      user: "user1",
      relatedTo: {
        type: "customer",
        id: "cust4",
      },
    },
    {
      id: "act5",
      type: "Call",
      description: "Follow-up call about hardware upgrade.",
      date: "2023-03-20",
      time: "9:30 am",
      user: "user2",
      relatedTo: {
        type: "customer",
        id: "cust5",
      },
    },
  ],

  // Users data
  users: [
    {
      id: "user1",
      name: "Jobayer Hoque Siddique",
      email: "jobayerhoquesiddique@gmail.com",
      role: "Administrator",
      department: "Sales",
      status: "Active",
      lastLogin: "Today, 10:30 AM",
    },
    {
      id: "user2",
      name: "Sarah Johnson",
      email: "sarah.johnson@example.com",
      role: "Sales Manager",
      department: "Sales",
      status: "Active",
      lastLogin: "Yesterday, 3:15 PM",
    },
    {
      id: "user3",
      name: "Michael Brown",
      email: "michael.brown@example.com",
      role: "Sales Representative",
      department: "Sales",
      status: "Active",
      lastLogin: "Mar 15, 2023, 9:20 AM",
    },
  ],

  // Events data
  events: [
    {
      id: "event1",
      title: "Meeting with Acme Inc.",
      start: "2023-03-25T09:00:00",
      end: "2023-03-25T10:00:00",
      allDay: false,
      type: "Meeting",
      description: "Discuss renewal of enterprise software package",
      relatedTo: {
        type: "customer",
        id: "cust1",
      },
      assignedTo: "user1",
    },
    {
      id: "event2",
      title: "Call with TechGiant",
      start: "2023-03-26T11:00:00",
      end: "2023-03-26T11:30:00",
      allDay: false,
      type: "Call",
      description: "Follow up on proposal",
      relatedTo: {
        type: "customer",
        id: "cust2",
      },
      assignedTo: "user2",
    },
    {
      id: "event3",
      title: "Follow up with leads",
      start: "2023-03-27T14:00:00",
      end: "2023-03-27T16:00:00",
      allDay: false,
      type: "Task",
      description: "Send email to all leads from the trade show",
      relatedTo: {
        type: "lead",
        id: "lead3",
      },
      assignedTo: "user3",
    },
    {
      id: "event4",
      title: "Sales Forecast Deadline",
      start: "2023-03-28",
      end: "2023-03-28",
      allDay: true,
      type: "Reminder",
      description: "Complete and submit Q2 sales forecast",
      relatedTo: {
        type: "other",
        id: "internal",
      },
      assignedTo: "user1",
    },
    {
      id: "event5",
      title: "Product Demo for Startup Solutions",
      start: "2023-03-29T13:00:00",
      end: "2023-03-29T14:30:00",
      allDay: false,
      type: "Meeting",
      description: "Demo our new cloud solution",
      relatedTo: {
        type: "customer",
        id: "cust3",
      },
      assignedTo: "user2",
    },
  ],
}

// Save data to localStorage
function saveDataToLocalStorage() {
  localStorage.setItem("crmData", JSON.stringify(crmData))
}

// Load data from localStorage
function loadDataFromLocalStorage() {
  const storedData = localStorage.getItem("crmData")
  if (storedData) {
    return JSON.parse(storedData)
  }
  return crmData
}

// Initialize data
function initializeData() {
  if (!localStorage.getItem("crmData")) {
    saveDataToLocalStorage()
  }
  return loadDataFromLocalStorage()
}

// Format currency
function formatCurrency(value) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value)
}

// Format date
function formatDate(dateString) {
  const date = new Date(dateString)
  return date.toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  })
}

// Calculate percentage change
function calculatePercentageChange(current, previous) {
  if (previous === 0) return current > 0 ? 100 : 0
  return Math.round(((current - previous) / previous) * 100)
}

