"use client"

import type React from "react"
import { createContext, useContext, useReducer, useEffect } from "react"
import { useLocalStorage } from "@/lib/hooks/useLocalStorage"

// Define types for our state
export type Customer = {
  id: string
  name: string
  email: string
  phone: string
  company: string
  status: string
  industry: string
  created: string
  lastContact: string
  address: string
  notes: string
  assignedTo: string
  avatar?: string
}

export type Lead = {
  id: string
  name: string
  email: string
  phone: string
  company: string
  status: string
  source: string
  created: string
  lastContact: string
  notes: string
  assignedTo: string
  estimatedValue: number
  avatar?: string
}

export type Deal = {
  id: string
  name: string
  customer: string
  value: number
  stage: string
  probability: number
  expectedCloseDate: string
  created: string
  lastUpdated: string
  assignedTo: string
  products: string[]
  notes: string
}

export type Task = {
  id: string
  title: string
  description: string
  status: string
  priority: string
  dueDate: string
  created: string
  assignedTo: string
  relatedTo: {
    type: string
    id: string
  }
}

export type Activity = {
  id: string
  type: string
  description: string
  date: string
  time: string
  user: string
  relatedTo: {
    type: string
    id: string
  }
}

export type Product = {
  id: string
  name: string
  sku: string
  category: string
  price: number
  cost: number
  description: string
  inStock: number
  status: string
  created: string
  lastUpdated: string
  image?: string
}

export type Campaign = {
  id: string
  name: string
  type: string
  status: string
  startDate: string
  endDate: string
  budget: number
  spent: number
  leads: number
  conversions: number
  roi: number
  description: string
  assignedTo: string
}

export type User = {
  id: string
  name: string
  email: string
  role: string
  department: string
  status: string
  lastLogin: string
  avatar?: string
}

export type Event = {
  id: string
  title: string
  start: string
  end: string
  allDay: boolean
  type: string
  description: string
  relatedTo: {
    type: string
    id: string
  }
  assignedTo: string
}

export type CrmState = {
  customers: Customer[]
  leads: Lead[]
  deals: Deal[]
  tasks: Task[]
  activities: Activity[]
  products: Product[]
  campaigns: Campaign[]
  users: User[]
  events: Event[]
  isLoading: boolean
  error: string | null
}

// Define action types
type ActionType =
  | { type: "SET_LOADING"; payload: boolean }
  | { type: "SET_ERROR"; payload: string | null }
  | { type: "SET_CUSTOMERS"; payload: Customer[] }
  | { type: "ADD_CUSTOMER"; payload: Customer }
  | { type: "UPDATE_CUSTOMER"; payload: Customer }
  | { type: "DELETE_CUSTOMER"; payload: string }
  | { type: "SET_LEADS"; payload: Lead[] }
  | { type: "ADD_LEAD"; payload: Lead }
  | { type: "UPDATE_LEAD"; payload: Lead }
  | { type: "DELETE_LEAD"; payload: string }
  | { type: "SET_DEALS"; payload: Deal[] }
  | { type: "ADD_DEAL"; payload: Deal }
  | { type: "UPDATE_DEAL"; payload: Deal }
  | { type: "DELETE_DEAL"; payload: string }
  | { type: "SET_TASKS"; payload: Task[] }
  | { type: "ADD_TASK"; payload: Task }
  | { type: "UPDATE_TASK"; payload: Task }
  | { type: "DELETE_TASK"; payload: string }
  | { type: "SET_ACTIVITIES"; payload: Activity[] }
  | { type: "ADD_ACTIVITY"; payload: Activity }
  | { type: "SET_PRODUCTS"; payload: Product[] }
  | { type: "ADD_PRODUCT"; payload: Product }
  | { type: "UPDATE_PRODUCT"; payload: Product }
  | { type: "DELETE_PRODUCT"; payload: string }
  | { type: "SET_CAMPAIGNS"; payload: Campaign[] }
  | { type: "ADD_CAMPAIGN"; payload: Campaign }
  | { type: "UPDATE_CAMPAIGN"; payload: Campaign }
  | { type: "DELETE_CAMPAIGN"; payload: string }
  | { type: "SET_USERS"; payload: User[] }
  | { type: "SET_EVENTS"; payload: Event[] }
  | { type: "ADD_EVENT"; payload: Event }
  | { type: "UPDATE_EVENT"; payload: Event }
  | { type: "DELETE_EVENT"; payload: string }
  | { type: "INITIALIZE_DATA" }

// Define initial state
const initialState: CrmState = {
  customers: [],
  leads: [],
  deals: [],
  tasks: [],
  activities: [],
  products: [],
  campaigns: [],
  users: [],
  events: [],
  isLoading: true,
  error: null,
}

// Create reducer function
const crmReducer = (state: CrmState, action: ActionType): CrmState => {
  switch (action.type) {
    case "SET_LOADING":
      return { ...state, isLoading: action.payload }
    case "SET_ERROR":
      return { ...state, error: action.payload }
    case "SET_CUSTOMERS":
      return { ...state, customers: action.payload }
    case "ADD_CUSTOMER":
      return { ...state, customers: [...state.customers, action.payload] }
    case "UPDATE_CUSTOMER":
      return {
        ...state,
        customers: state.customers.map((customer) => (customer.id === action.payload.id ? action.payload : customer)),
      }
    case "DELETE_CUSTOMER":
      return {
        ...state,
        customers: state.customers.filter((customer) => customer.id !== action.payload),
      }
    case "SET_LEADS":
      return { ...state, leads: action.payload }
    case "ADD_LEAD":
      return { ...state, leads: [...state.leads, action.payload] }
    case "UPDATE_LEAD":
      return {
        ...state,
        leads: state.leads.map((lead) => (lead.id === action.payload.id ? action.payload : lead)),
      }
    case "DELETE_LEAD":
      return {
        ...state,
        leads: state.leads.filter((lead) => lead.id !== action.payload),
      }
    case "SET_DEALS":
      return { ...state, deals: action.payload }
    case "ADD_DEAL":
      return { ...state, deals: [...state.deals, action.payload] }
    case "UPDATE_DEAL":
      return {
        ...state,
        deals: state.deals.map((deal) => (deal.id === action.payload.id ? action.payload : deal)),
      }
    case "DELETE_DEAL":
      return {
        ...state,
        deals: state.deals.filter((deal) => deal.id !== action.payload),
      }
    case "SET_TASKS":
      return { ...state, tasks: action.payload }
    case "ADD_TASK":
      return { ...state, tasks: [...state.tasks, action.payload] }
    case "UPDATE_TASK":
      return {
        ...state,
        tasks: state.tasks.map((task) => (task.id === action.payload.id ? action.payload : task)),
      }
    case "DELETE_TASK":
      return {
        ...state,
        tasks: state.tasks.filter((task) => task.id !== action.payload),
      }
    case "SET_ACTIVITIES":
      return { ...state, activities: action.payload }
    case "ADD_ACTIVITY":
      return { ...state, activities: [action.payload, ...state.activities] }
    case "SET_PRODUCTS":
      return { ...state, products: action.payload }
    case "ADD_PRODUCT":
      return { ...state, products: [...state.products, action.payload] }
    case "UPDATE_PRODUCT":
      return {
        ...state,
        products: state.products.map((product) => (product.id === action.payload.id ? action.payload : product)),
      }
    case "DELETE_PRODUCT":
      return {
        ...state,
        products: state.products.filter((product) => product.id !== action.payload),
      }
    case "SET_CAMPAIGNS":
      return { ...state, campaigns: action.payload }
    case "ADD_CAMPAIGN":
      return { ...state, campaigns: [...state.campaigns, action.payload] }
    case "UPDATE_CAMPAIGN":
      return {
        ...state,
        campaigns: state.campaigns.map((campaign) => (campaign.id === action.payload.id ? action.payload : campaign)),
      }
    case "DELETE_CAMPAIGN":
      return {
        ...state,
        campaigns: state.campaigns.filter((campaign) => campaign.id !== action.payload),
      }
    case "SET_USERS":
      return { ...state, users: action.payload }
    case "SET_EVENTS":
      return { ...state, events: action.payload }
    case "ADD_EVENT":
      return { ...state, events: [...state.events, action.payload] }
    case "UPDATE_EVENT":
      return {
        ...state,
        events: state.events.map((event) => (event.id === action.payload.id ? action.payload : event)),
      }
    case "DELETE_EVENT":
      return {
        ...state,
        events: state.events.filter((event) => event.id !== action.payload),
      }
    case "INITIALIZE_DATA":
      return { ...state, isLoading: false }
    default:
      return state
  }
}

// Create context
type CrmContextType = {
  state: CrmState
  dispatch: React.Dispatch<ActionType>
  addActivity: (activity: Omit<Activity, "id">) => void
  generateId: () => string
  getLeadById: (id: string) => Lead | undefined
  getActivitiesByRelation: (type: string, id: string) => Activity[]
  getTasksByRelation: (type: string, id: string) => Task[]
  getDocumentsByRelation: (type: string, id: string) => any[]
  addTask: (task: Omit<Task, "id">) => void
  addDocument: (document: any) => void
  convertLead: (leadId: string, customer: Omit<Customer, "id">, deal?: Omit<Deal, "id" | "customer">) => void
  deleteLead: (id: string) => void
}

const CrmContext = createContext<CrmContextType | undefined>(undefined)

// Create provider component
export const CrmProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [storedCustomers, setStoredCustomers] = useLocalStorage<Customer[]>("crm-customers", [])
  const [storedLeads, setStoredLeads] = useLocalStorage<Lead[]>("crm-leads", [])
  const [storedDeals, setStoredDeals] = useLocalStorage<Deal[]>("crm-deals", [])
  const [storedTasks, setStoredTasks] = useLocalStorage<Task[]>("crm-tasks", [])
  const [storedActivities, setStoredActivities] = useLocalStorage<Activity[]>("crm-activities", [])
  const [storedProducts, setStoredProducts] = useLocalStorage<Product[]>("crm-products", [])
  const [storedCampaigns, setStoredCampaigns] = useLocalStorage<Campaign[]>("crm-campaigns", [])
  const [storedUsers, setStoredUsers] = useLocalStorage<User[]>("crm-users", [])
  const [storedEvents, setStoredEvents] = useLocalStorage<Event[]>("crm-events", [])
  const [storedDocuments, setStoredDocuments] = useLocalStorage<any[]>("crm-documents", [])

  const [state, dispatch] = useReducer(crmReducer, initialState)

  // Generate a unique ID
  const generateId = () => {
    return Date.now().toString(36) + Math.random().toString(36).substr(2, 5)
  }

  // Add activity helper function
  const addActivity = (activity: Omit<Activity, "id">) => {
    const newActivity = {
      ...activity,
      id: generateId(),
    }
    dispatch({ type: "ADD_ACTIVITY", payload: newActivity })
  }

  // Get lead by ID
  const getLeadById = (id: string) => {
    return state.leads.find((lead) => lead.id === id)
  }

  // Get activities by relation
  const getActivitiesByRelation = (type: string, id: string) => {
    return state.activities.filter((activity) => activity.relatedTo.type === type && activity.relatedTo.id === id)
  }

  // Get tasks by relation
  const getTasksByRelation = (type: string, id: string) => {
    return state.tasks.filter((task) => task.relatedTo.type === type && task.relatedTo.id === id)
  }

  // Get documents by relation
  const getDocumentsByRelation = (type: string, id: string) => {
    return storedDocuments.filter((doc) => doc.relatedTo.type === type && doc.relatedTo.id === id)
  }

  // Add task helper function
  const addTask = (task: Omit<Task, "id">) => {
    const newTask = {
      ...task,
      id: generateId(),
    }
    dispatch({ type: "ADD_TASK", payload: newTask })
  }

  // Add document helper function
  const addDocument = (document: any) => {
    const newDocument = {
      ...document,
      id: generateId(),
    }
    setStoredDocuments([...storedDocuments, newDocument])
  }

  // Convert lead to customer
  const convertLead = (
    leadId: string,
    customerData: Omit<Customer, "id">,
    dealData?: Omit<Deal, "id" | "customer">,
  ) => {
    // Create customer
    const newCustomer: Customer = {
      ...customerData,
      id: generateId(),
    }

    dispatch({ type: "ADD_CUSTOMER", payload: newCustomer })

    // Create deal if provided
    if (dealData) {
      const newDeal: Deal = {
        ...dealData,
        id: generateId(),
        customer: newCustomer.id,
      }

      dispatch({ type: "ADD_DEAL", payload: newDeal })
    }

    // Delete lead
    dispatch({ type: "DELETE_LEAD", payload: leadId })
  }

  // Delete lead
  const deleteLead = (id: string) => {
    dispatch({ type: "DELETE_LEAD", payload: id })
  }

  // Initialize data
  useEffect(() => {
    const initializeData = async () => {
      dispatch({ type: "SET_LOADING", payload: true })

      try {
        // If we have stored data, use it
        if (storedCustomers.length > 0) {
          dispatch({ type: "SET_CUSTOMERS", payload: storedCustomers })
        } else {
          // Otherwise, initialize with sample data
          const sampleCustomers: Customer[] = [
            {
              id: "cust1",
              name: "Acme Inc.",
              email: "contact@acmeinc.com",
              phone: "(123) 456-7890",
              company: "Acme Inc.",
              status: "Active",
              industry: "Technology",
              created: "2023-01-15",
              lastContact: "2023-03-10",
              address: "123 Main St, Anytown, CA 12345",
              notes: "Key enterprise client with multiple ongoing projects.",
              assignedTo: "user1",
            },
            {
              id: "cust2",
              name: "TechGiant Corp",
              email: "info@techgiant.com",
              phone: "(234) 567-8901",
              company: "TechGiant Corp",
              status: "Active",
              industry: "Software",
              created: "2023-02-20",
              lastContact: "2023-03-15",
              address: "456 Tech Blvd, Innovation City, CA 67890",
              notes: "Interested in our enterprise software package.",
              assignedTo: "user2",
            },
            {
              id: "cust3",
              name: "Startup Solutions",
              email: "hello@startupsolutions.com",
              phone: "(345) 678-9012",
              company: "Startup Solutions",
              status: "Active",
              industry: "Consulting",
              created: "2023-01-05",
              lastContact: "2023-03-01",
              address: "789 Venture Ave, Startup City, CA 54321",
              notes: "New client with high growth potential.",
              assignedTo: "user3",
            },
            {
              id: "cust4",
              name: "Global Enterprises",
              email: "contact@globalenterprises.com",
              phone: "(456) 789-0123",
              company: "Global Enterprises",
              status: "Inactive",
              industry: "Manufacturing",
              created: "2022-11-10",
              lastContact: "2023-02-15",
              address: "101 Industry Pkwy, Manufacturing Town, CA 13579",
              notes: "International client with multiple locations.",
              assignedTo: "user1",
            },
            {
              id: "cust5",
              name: "Local Business LLC",
              email: "info@localbusiness.com",
              phone: "(567) 890-1234",
              company: "Local Business LLC",
              status: "Active",
              industry: "Retail",
              created: "2023-03-01",
              lastContact: "2023-03-20",
              address: "202 Main St, Hometown, CA 24680",
              notes: "Small local business with consistent orders.",
              assignedTo: "user2",
            },
          ]
          dispatch({ type: "SET_CUSTOMERS", payload: sampleCustomers })
          setStoredCustomers(sampleCustomers)
        }

        if (storedLeads.length > 0) {
          dispatch({ type: "SET_LEADS", payload: storedLeads })
        } else {
          const sampleLeads: Lead[] = [
            {
              id: "lead1",
              name: "John Smith",
              email: "john.smith@example.com",
              phone: "(123) 456-7890",
              company: "Future Tech",
              status: "New",
              source: "Website",
              created: "2023-03-15",
              lastContact: "2023-03-15",
              notes: "Interested in our enterprise software package.",
              assignedTo: "user1",
              estimatedValue: 15000,
            },
            {
              id: "lead2",
              name: "Sarah Johnson",
              email: "sarah.johnson@example.com",
              phone: "(234) 567-8901",
              company: "Innovative Solutions",
              status: "Contacted",
              source: "Referral",
              created: "2023-03-10",
              lastContact: "2023-03-12",
              notes: "Referred by TechGiant Corp. Looking for IT consulting services.",
              assignedTo: "user2",
              estimatedValue: 10000,
            },
            {
              id: "lead3",
              name: "Michael Brown",
              email: "michael.brown@example.com",
              phone: "(345) 678-9012",
              company: "Growth Startup",
              status: "Qualified",
              source: "Trade Show",
              created: "2023-03-05",
              lastContact: "2023-03-08",
              notes: "Met at the Tech Expo. Needs help with cloud migration.",
              assignedTo: "user3",
              estimatedValue: 20000,
            },
            {
              id: "lead4",
              name: "Emily Davis",
              email: "emily.davis@example.com",
              phone: "(456) 789-0123",
              company: "Davis Enterprises",
              status: "Negotiation",
              source: "Email Campaign",
              created: "2023-02-28",
              lastContact: "2023-03-14",
              notes: "Responded to our Q1 email campaign. Interested in our premium support package.",
              assignedTo: "user1",
              estimatedValue: 8000,
            },
            {
              id: "lead5",
              name: "Robert Wilson",
              email: "robert.wilson@example.com",
              phone: "(567) 890-1234",
              company: "Wilson & Co",
              status: "New",
              source: "Social Media",
              created: "2023-03-18",
              lastContact: "2023-03-18",
              notes: "Found us through LinkedIn. Looking for a CRM solution.",
              assignedTo: "user2",
              estimatedValue: 12000,
            },
          ]
          dispatch({ type: "SET_LEADS", payload: sampleLeads })
          setStoredLeads(sampleLeads)
        }

        if (storedDeals.length > 0) {
          dispatch({ type: "SET_DEALS", payload: storedDeals })
        } else {
          const sampleDeals: Deal[] = [
            {
              id: "deal1",
              name: "Enterprise Software Package",
              customer: "cust1",
              value: 15000,
              stage: "Closed Won",
              probability: 100,
              expectedCloseDate: "2023-03-15",
              created: "2023-01-20",
              lastUpdated: "2023-03-15",
              assignedTo: "user1",
              products: ["prod1", "prod2"],
              notes: "Successfully closed deal for enterprise software package.",
            },
            {
              id: "deal2",
              name: "Consulting Services",
              customer: "cust2",
              value: 8500,
              stage: "Negotiation",
              probability: 75,
              expectedCloseDate: "2023-04-10",
              created: "2023-02-15",
              lastUpdated: "2023-03-20",
              assignedTo: "user2",
              products: ["prod3"],
              notes: "Client is considering our proposal for consulting services.",
            },
            {
              id: "deal3",
              name: "Cloud Migration",
              customer: "cust3",
              value: 12000,
              stage: "Proposal",
              probability: 50,
              expectedCloseDate: "2023-05-01",
              created: "2023-03-01",
              lastUpdated: "2023-03-18",
              assignedTo: "user3",
              products: ["prod4", "prod5"],
              notes: "Sent proposal for cloud migration project.",
            },
            {
              id: "deal4",
              name: "Support Contract",
              customer: "cust4",
              value: 5000,
              stage: "Closed Lost",
              probability: 0,
              expectedCloseDate: "2023-03-01",
              created: "2023-01-10",
              lastUpdated: "2023-03-01",
              assignedTo: "user1",
              products: ["prod6"],
              notes: "Client decided to go with a competitor.",
            },
            {
              id: "deal5",
              name: "Hardware Upgrade",
              customer: "cust5",
              value: 7200,
              stage: "Closed Won",
              probability: 100,
              expectedCloseDate: "2023-03-10",
              created: "2023-02-01",
              lastUpdated: "2023-03-10",
              assignedTo: "user2",
              products: ["prod7", "prod8"],
              notes: "Successfully closed deal for hardware upgrade.",
            },
          ]
          dispatch({ type: "SET_DEALS", payload: sampleDeals })
          setStoredDeals(sampleDeals)
        }

        if (storedTasks.length > 0) {
          dispatch({ type: "SET_TASKS", payload: storedTasks })
        } else {
          const sampleTasks: Task[] = [
            {
              id: "task1",
              title: "Call John about proposal",
              description: "Follow up with John Smith about the enterprise software proposal.",
              status: "Pending",
              priority: "High",
              dueDate: "Today",
              created: "2023-03-15",
              assignedTo: "user1",
              relatedTo: {
                type: "lead",
                id: "lead1",
              },
            },
            {
              id: "task2",
              title: "Prepare presentation for client",
              description: "Create a presentation for the upcoming meeting with TechGiant Corp.",
              status: "In Progress",
              priority: "Medium",
              dueDate: "Tomorrow",
              created: "2023-03-18",
              assignedTo: "user2",
              relatedTo: {
                type: "customer",
                id: "cust2",
              },
            },
            {
              id: "task3",
              title: "Send follow-up email to leads",
              description: "Send follow-up emails to all leads from the trade show.",
              status: "Pending",
              priority: "Medium",
              dueDate: "2 days",
              created: "2023-03-17",
              assignedTo: "user3",
              relatedTo: {
                type: "lead",
                id: "lead3",
              },
            },
            {
              id: "task4",
              title: "Update sales forecast",
              description: "Update the Q2 sales forecast with the latest deal information.",
              status: "Pending",
              priority: "Low",
              dueDate: "3 days",
              created: "2023-03-19",
              assignedTo: "user1",
              relatedTo: {
                type: "deal",
                id: "deal2",
              },
            },
            {
              id: "task5",
              title: "Schedule team meeting",
              description: "Schedule a team meeting to discuss the upcoming product launch.",
              status: "Completed",
              priority: "Medium",
              dueDate: "1 week",
              created: "2023-03-10",
              assignedTo: "user2",
              relatedTo: {
                type: "other",
                id: "internal",
              },
            },
          ]
          dispatch({ type: "SET_TASKS", payload: sampleTasks })
          setStoredTasks(sampleTasks)
        }

        if (storedActivities.length > 0) {
          dispatch({ type: "SET_ACTIVITIES", payload: storedActivities })
        } else {
          const sampleActivities: Activity[] = [
            {
              id: "act1",
              type: "Call",
              description: "Called Acme Inc. about the enterprise software package proposal.",
              date: "Today",
              time: "10:00 am",
              user: "user1",
              relatedTo: {
                type: "customer",
                id: "cust1",
              },
            },
            {
              id: "act2",
              type: "Email",
              description: "Sent follow-up email to TechGiant Corp.",
              date: "Today",
              time: "9:30 am",
              user: "user2",
              relatedTo: {
                type: "customer",
                id: "cust2",
              },
            },
            {
              id: "act3",
              type: "Meeting",
              description: "Initial consultation about their needs.",
              date: "Yesterday",
              time: "2:15 pm",
              user: "user3",
              relatedTo: {
                type: "customer",
                id: "cust3",
              },
            },
            {
              id: "act4",
              type: "Task",
              description: "Updated customer information and contact details.",
              date: "Yesterday",
              time: "1:10 pm",
              user: "user1",
              relatedTo: {
                type: "customer",
                id: "cust4",
              },
            },
            {
              id: "act5",
              type: "Call",
              description: "Follow-up call about hardware upgrade.",
              date: "2 days ago",
              time: "9:30 am",
              user: "user2",
              relatedTo: {
                type: "customer",
                id: "cust5",
              },
            },
          ]
          dispatch({ type: "SET_ACTIVITIES", payload: sampleActivities })
          setStoredActivities(sampleActivities)
        }

        if (storedProducts.length > 0) {
          dispatch({ type: "SET_PRODUCTS", payload: storedProducts })
        } else {
          const sampleProducts: Product[] = [
            {
              id: "prod1",
              name: "Enterprise CRM",
              sku: "CRM-ENT-001",
              category: "Software",
              price: 9999.99,
              cost: 2000,
              description: "Complete enterprise CRM solution with all modules.",
              inStock: 999,
              status: "Active",
              created: "2023-01-01",
              lastUpdated: "2023-03-15",
            },
            {
              id: "prod2",
              name: "CRM Professional",
              sku: "CRM-PRO-001",
              category: "Software",
              price: 4999.99,
              cost: 1000,
              description: "Professional CRM solution for small to medium businesses.",
              inStock: 999,
              status: "Active",
              created: "2023-01-01",
              lastUpdated: "2023-03-15",
            },
            {
              id: "prod3",
              name: "IT Consulting (hourly)",
              sku: "SVC-CONS-001",
              category: "Services",
              price: 150,
              cost: 75,
              description: "IT consulting services billed hourly.",
              inStock: 999,
              status: "Active",
              created: "2023-01-15",
              lastUpdated: "2023-03-10",
            },
            {
              id: "prod4",
              name: "Cloud Migration Package",
              sku: "SVC-CLOUD-001",
              category: "Services",
              price: 7500,
              cost: 3500,
              description: "Complete cloud migration service package.",
              inStock: 999,
              status: "Active",
              created: "2023-02-01",
              lastUpdated: "2023-03-01",
            },
            {
              id: "prod5",
              name: "Server Hardware Bundle",
              sku: "HW-SRV-001",
              category: "Hardware",
              price: 12500,
              cost: 9000,
              description: "Complete server hardware bundle with installation.",
              inStock: 15,
              status: "Active",
              created: "2023-01-10",
              lastUpdated: "2023-03-05",
            },
          ]
          dispatch({ type: "SET_PRODUCTS", payload: sampleProducts })
          setStoredProducts(sampleProducts)
        }

        if (storedCampaigns.length > 0) {
          dispatch({ type: "SET_CAMPAIGNS", payload: storedCampaigns })
        } else {
          const sampleCampaigns: Campaign[] = [
            {
              id: "camp1",
              name: "Q1 Email Newsletter",
              type: "Email",
              status: "Completed",
              startDate: "2023-01-15",
              endDate: "2023-01-30",
              budget: 1000,
              spent: 950,
              leads: 45,
              conversions: 12,
              roi: 15.8,
              description: "Q1 email newsletter campaign targeting existing customers.",
              assignedTo: "user2",
            },
            {
              id: "camp2",
              name: "Spring Trade Show",
              type: "Event",
              status: "Completed",
              startDate: "2023-03-10",
              endDate: "2023-03-12",
              budget: 5000,
              spent: 4800,
              leads: 120,
              conversions: 18,
              roi: 8.2,
              description: "Annual spring technology trade show booth and presentations.",
              assignedTo: "user1",
            },
            {
              id: "camp3",
              name: "Google Ads - Q2",
              type: "PPC",
              status: "Active",
              startDate: "2023-04-01",
              endDate: "2023-06-30",
              budget: 10000,
              spent: 3500,
              leads: 85,
              conversions: 15,
              roi: 9.5,
              description: "Google Ads campaign for Q2 targeting new customer acquisition.",
              assignedTo: "user3",
            },
            {
              id: "camp4",
              name: "Social Media Campaign",
              type: "Social",
              status: "Planned",
              startDate: "2023-05-01",
              endDate: "2023-05-31",
              budget: 3000,
              spent: 0,
              leads: 0,
              conversions: 0,
              roi: 0,
              description: "LinkedIn and Twitter campaign targeting IT decision makers.",
              assignedTo: "user2",
            },
            {
              id: "camp5",
              name: "Product Launch Webinar",
              type: "Webinar",
              status: "Planned",
              startDate: "2023-06-15",
              endDate: "2023-06-15",
              budget: 2000,
              spent: 0,
              leads: 0,
              conversions: 0,
              roi: 0,
              description: "Webinar for launching our new enterprise software solution.",
              assignedTo: "user1",
            },
          ]
          dispatch({ type: "SET_CAMPAIGNS", payload: sampleCampaigns })
          setStoredCampaigns(sampleCampaigns)
        }

        if (storedUsers.length > 0) {
          dispatch({ type: "SET_USERS", payload: storedUsers })
        } else {
          const sampleUsers: User[] = [
            {
              id: "user1",
              name: "Jobayer Hoque Siddique",
              email: "jobayerhoquesiddique@gmail.com",
              role: "Administrator",
              department: "Sales",
              status: "Active",
              lastLogin: "Today, 10:30 AM",
              avatar: "/images/profile.jpg",
            },
            {
              id: "user2",
              name: "Sarah Johnson",
              email: "sarah.johnson@example.com",
              role: "Sales Manager",
              department: "Sales",
              status: "Active",
              lastLogin: "Yesterday, 3:15 PM",
            },
            {
              id: "user3",
              name: "Michael Brown",
              email: "michael.brown@example.com",
              role: "Sales Representative",
              department: "Sales",
              status: "Active",
              lastLogin: "Mar 15, 2023, 9:20 AM",
            },
            {
              id: "user4",
              name: "Emily Davis",
              email: "emily.davis@example.com",
              role: "Marketing Specialist",
              department: "Marketing",
              status: "Active",
              lastLogin: "Mar 14, 2023, 2:45 PM",
            },
            {
              id: "user5",
              name: "Robert Wilson",
              email: "robert.wilson@example.com",
              role: "Support Specialist",
              department: "Customer Support",
              status: "Inactive",
              lastLogin: "Feb 28, 2023, 11:10 AM",
            },
          ]
          dispatch({ type: "SET_USERS", payload: sampleUsers })
          setStoredUsers(sampleUsers)
        }

        if (storedEvents.length > 0) {
          dispatch({ type: "SET_EVENTS", payload: storedEvents })
        } else {
          const sampleEvents: Event[] = [
            {
              id: "event1",
              title: "Meeting with Acme Inc.",
              start: "2023-03-15T09:00:00",
              end: "2023-03-15T10:00:00",
              allDay: false,
              type: "Meeting",
              description: "Discuss renewal of enterprise software package",
              relatedTo: {
                type: "customer",
                id: "cust1",
              },
              assignedTo: "user1",
            },
            {
              id: "event2",
              title: "Call with TechGiant",
              start: "2023-03-20T11:00:00",
              end: "2023-03-20T11:30:00",
              allDay: false,
              type: "Call",
              description: "Follow up on proposal",
              relatedTo: {
                type: "customer",
                id: "cust2",
              },
              assignedTo: "user2",
            },
            {
              id: "event3",
              title: "Follow up with leads",
              start: "2023-03-20T14:00:00",
              end: "2023-03-20T16:00:00",
              allDay: false,
              type: "Task",
              description: "Send email to all leads from the trade show",
              relatedTo: {
                type: "lead",
                id: "lead3",
              },
              assignedTo: "user3",
            },
            {
              id: "event4",
              title: "Sales Forecast Deadline",
              start: "2023-03-22",
              end: "2023-03-22",
              allDay: true,
              type: "Reminder",
              description: "Complete and submit Q2 sales forecast",
              relatedTo: {
                type: "other",
                id: "internal",
              },
              assignedTo: "user1",
            },
            {
              id: "event5",
              title: "Product Demo for Startup Solutions",
              start: "2023-03-25T13:00:00",
              end: "2023-03-25T14:30:00",
              allDay: false,
              type: "Meeting",
              description: "Demo our new cloud solution",
              relatedTo: {
                type: "customer",
                id: "cust3",
              },
              assignedTo: "user2",
            },
          ]
          dispatch({ type: "SET_EVENTS", payload: sampleEvents })
          setStoredEvents(sampleEvents)
        }

        // Set loading to false
        dispatch({ type: "INITIALIZE_DATA" })
      } catch (error) {
        console.log("Data initialization delayed. Will retry.")
        dispatch({ type: "SET_LOADING", payload: false })
      }
    }

    initializeData()
  }, [])

  // Update localStorage when state changes
  useEffect(() => {
    if (!state.isLoading) {
      setStoredCustomers(state.customers)
      setStoredLeads(state.leads)
      setStoredDeals(state.deals)
      setStoredTasks(state.tasks)
      setStoredActivities(state.activities)
      setStoredProducts(state.products)
      setStoredCampaigns(state.campaigns)
      setStoredUsers(state.users)
      setStoredEvents(state.events)
    }
  }, [
    state.customers,
    state.leads,
    state.deals,
    state.tasks,
    state.activities,
    state.products,
    state.campaigns,
    state.users,
    state.events,
    state.isLoading,
  ])

  return (
    <CrmContext.Provider
      value={{
        state,
        dispatch,
        addActivity,
        generateId,
        getLeadById,
        getActivitiesByRelation,
        getTasksByRelation,
        getDocumentsByRelation,
        addTask,
        addDocument,
        convertLead,
        deleteLead,
      }}
    >
      {children}
    </CrmContext.Provider>
  )
}

// Create hook for using the context
export const useCrm = () => {
  const context = useContext(CrmContext)
  if (context === undefined) {
    throw new Error("useCrm must be used within a CrmProvider")
  }
  return context
}

