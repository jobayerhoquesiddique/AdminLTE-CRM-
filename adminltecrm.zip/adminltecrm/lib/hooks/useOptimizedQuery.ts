"use client"

import { useState, useEffect, useRef, useCallback } from "react"

interface QueryOptions<T> {
  enabled?: boolean
  refetchInterval?: number | false
  onSuccess?: (data: T) => void
  onError?: (error: Error) => void
  initialData?: T
  staleTime?: number
  cacheTime?: number
}

interface QueryResult<T> {
  data: T | undefined
  isLoading: boolean
  isError: boolean
  error: Error | null
  refetch: () => Promise<T>
}

/**
 * A hook for data fetching with caching, refetching, and error handling
 *
 * @param queryFn The function that fetches data
 * @param options Configuration options for the query
 * @returns Object containing query state and refetch function
 */
export function useOptimizedQuery<T>(queryFn: () => Promise<T>, options: QueryOptions<T> = {}): QueryResult<T> {
  const {
    enabled = true,
    refetchInterval = false,
    onSuccess,
    onError,
    initialData,
    staleTime = 0,
    cacheTime = 5 * 60 * 1000, // 5 minutes
  } = options

  const [data, setData] = useState<T | undefined>(initialData)
  const [isLoading, setIsLoading] = useState<boolean>(enabled)
  const [isError, setIsError] = useState<boolean>(false)
  const [error, setError] = useState<Error | null>(null)

  const lastFetchedAt = useRef<number | null>(null)
  const isMounted = useRef<boolean>(true)
  const refetchIntervalId = useRef<NodeJS.Timeout | null>(null)
  const cacheTimeoutId = useRef<NodeJS.Timeout | null>(null)

  const fetchData = useCallback(async (): Promise<T> => {
    setIsLoading(true)
    setIsError(false)
    setError(null)

    try {
      const result = await queryFn()

      if (isMounted.current) {
        setData(result)
        setIsLoading(false)
        lastFetchedAt.current = Date.now()

        if (onSuccess) {
          onSuccess(result)
        }
      }

      return result
    } catch (err) {
      if (isMounted.current) {
        setIsError(true)
        setIsLoading(false)

        const errorObj = err instanceof Error ? err : new Error(String(err))
        setError(errorObj)

        if (onError) {
          onError(errorObj)
        }
      }

      throw err
    }
  }, [queryFn, onSuccess, onError])

  const refetch = useCallback(async (): Promise<T> => {
    return fetchData()
  }, [fetchData])

  // Set up data fetching
  useEffect(() => {
    if (!enabled) {
      setIsLoading(false)
      return
    }

    const shouldFetch = lastFetchedAt.current === null || Date.now() - lastFetchedAt.current > staleTime

    if (shouldFetch) {
      fetchData().catch(console.error)
    }

    // Set up refetch interval if specified
    if (refetchInterval) {
      refetchIntervalId.current = setInterval(() => {
        fetchData().catch(console.error)
      }, refetchInterval)
    }

    return () => {
      if (refetchIntervalId.current) {
        clearInterval(refetchIntervalId.current)
      }
    }
  }, [enabled, fetchData, refetchInterval, staleTime])

  // Clean up on unmount
  useEffect(() => {
    return () => {
      isMounted.current = false

      if (refetchIntervalId.current) {
        clearInterval(refetchIntervalId.current)
      }

      if (cacheTimeoutId.current) {
        clearTimeout(cacheTimeoutId.current)
      }
    }
  }, [])

  return {
    data,
    isLoading,
    isError,
    error,
    refetch,
  }
}

