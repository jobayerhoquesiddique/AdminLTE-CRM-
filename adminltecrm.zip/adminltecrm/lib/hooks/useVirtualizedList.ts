"use client"

import type React from "react"

import { useState, useEffect, useRef, useCallback } from "react"

interface VirtualizedListOptions {
  itemHeight: number
  overscan?: number
  initialScrollIndex?: number
}

interface VirtualizedListResult<T> {
  virtualItems: Array<{ index: number; item: T; offsetTop: number }>
  totalHeight: number
  scrollToIndex: (index: number) => void
  containerProps: {
    ref: React.RefObject<HTMLDivElement>
    onScroll: (event: React.UIEvent) => void
    style: React.CSSProperties
  }
}

/**
 * A hook for efficiently rendering large lists by only rendering items that are visible
 *
 * @param items The array of items to render
 * @param options Configuration options for the virtualized list
 * @returns Object containing virtualized items and helper methods
 */
export function useVirtualizedList<T>(items: T[], options: VirtualizedListOptions): VirtualizedListResult<T> {
  const { itemHeight, overscan = 3, initialScrollIndex = 0 } = options

  const containerRef = useRef<HTMLDivElement>(null)
  const [scrollTop, setScrollTop] = useState(0)
  const [containerHeight, setContainerHeight] = useState(0)

  // Calculate the total height of all items
  const totalHeight = items.length * itemHeight

  // Calculate the range of visible items
  const startIndex = Math.max(0, Math.floor(scrollTop / itemHeight) - overscan)
  const endIndex = Math.min(items.length - 1, Math.floor((scrollTop + containerHeight) / itemHeight) + overscan)

  // Create the array of virtual items
  const virtualItems = []
  for (let i = startIndex; i <= endIndex; i++) {
    virtualItems.push({
      index: i,
      item: items[i],
      offsetTop: i * itemHeight,
    })
  }

  // Handle scroll events
  const handleScroll = useCallback((event: React.UIEvent) => {
    const { scrollTop } = event.currentTarget
    setScrollTop(scrollTop)
  }, [])

  // Scroll to a specific index
  const scrollToIndex = useCallback(
    (index: number) => {
      if (containerRef.current) {
        containerRef.current.scrollTop = index * itemHeight
      }
    },
    [itemHeight],
  )

  // Measure the container height on mount and window resize
  useEffect(() => {
    const updateContainerHeight = () => {
      if (containerRef.current) {
        setContainerHeight(containerRef.current.clientHeight)
      }
    }

    updateContainerHeight()
    window.addEventListener("resize", updateContainerHeight)

    return () => {
      window.removeEventListener("resize", updateContainerHeight)
    }
  }, [])

  // Scroll to initial index on mount
  useEffect(() => {
    if (initialScrollIndex > 0) {
      scrollToIndex(initialScrollIndex)
    }
  }, [initialScrollIndex, scrollToIndex])

  return {
    virtualItems,
    totalHeight,
    scrollToIndex,
    containerProps: {
      ref: containerRef,
      onScroll: handleScroll,
      style: { overflowY: "auto", height: "100%" },
    },
  }
}

