/**
 * Format a number as currency
 * @param value Number to format
 * @param currency Currency symbol
 * @param locale Locale for formatting
 * @returns Formatted currency string
 */
export const formatCurrency = (value: number, currency = "$", locale = "en-US"): string => {
  if (isNaN(value)) return `${currency}0.00`

  return new Intl.NumberFormat(locale, {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value)
}

/**
 * Format a date string
 * @param dateString Date string to format
 * @param format Format style
 * @returns Formatted date string
 */
export const formatDate = (dateString: string, format: "short" | "medium" | "long" = "medium"): string => {
  try {
    const date = new Date(dateString)
    if (isNaN(date.getTime())) return dateString

    const options: Intl.DateTimeFormatOptions = {
      year: "numeric",
      month: format === "short" ? "short" : "long",
      day: "numeric",
    }

    return new Intl.DateTimeFormat("en-US", options).format(date)
  } catch (error) {
    console.error("Error formatting date:", error)
    return dateString
  }
}

/**
 * Calculate percentage change between two values
 * @param current Current value
 * @param previous Previous value
 * @returns Percentage change
 */
export const calculatePercentageChange = (current: number, previous: number): number => {
  if (previous === 0) return current > 0 ? 100 : 0
  return Math.round(((current - previous) / previous) * 100)
}

/**
 * Group array items by a specific property
 * @param array Array to group
 * @param key Property to group by
 * @returns Object with grouped items
 */ \
export const groupBy = <T>(array: T[], key: keyof T): Record<string, T[]> => {
 return array.reduce((result: Record<string, T[]>, item: T) => {
   const groupKey = String(item[key]);
   if (!result[groupKey]) {
     result[groupKey] = [];
   }
   result[groupKey].push(item);
   return result;
 }, {});
}

/**
* Sort array by a specific property
* @param array Array to sort
* @param key Property to sort by
* @param direction Sort direction
* @returns Sorted array
*/
export const sortBy = <T>(
 array: T[],
 key: keyof T,
 direction: "asc" | "desc" = "asc"
): T[] => {
 return [...array].sort((a, b) => {
   const valueA = a[key]
   const valueB = b[key]

   if (typeof valueA === "string" && typeof valueB === "string") {
     return direction === "asc"
       ? valueA.localeCompare(valueB)
       : valueB.localeCompare(valueA)
   }

   if (typeof valueA === "number" && typeof valueB === "number") {
     return direction === "asc" ? valueA - valueB : valueB - valueA
   }

   if (valueA instanceof Date && valueB instanceof Date) {
     return direction === "asc"
       ? valueA.getTime() - valueB.getTime()
       : valueB.getTime() - valueA.getTime()
   }

   return 0
 })
}

/**
* Filter array by search term across multiple properties
* @param array Array to filter
* @param searchTerm Search term
* @param properties Properties to search in
* @returns Filtered array
*/
export const searchByTerm = <T>(
 array: T[],
 searchTerm: string,
 properties: (keyof T)[]
): T[] => {
 if (!searchTerm) return array

 const term = searchTerm.toLowerCase()
 return array.filter((item) =>
   properties.some((prop) => {
     const value = item[prop]
     if (typeof value === "string") {
       return value.toLowerCase().includes(term)
     }
     if (typeof value === "number") {
       return value.toString().includes(term)
     }
     return false
   })
 )
}

