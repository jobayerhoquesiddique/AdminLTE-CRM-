/**
 * Debounce function to limit how often a function can be called
 * @param func Function to debounce
 * @param wait Wait time in milliseconds
 * @returns Debounced function
 */
export function debounce<T extends (...args: any[]) => any>(func: T, wait: number): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout | null = null

  return (...args: Parameters<T>): void => {
    const later = () => {
      timeout = null
      func(...args)
    }

    if (timeout !== null) {
      clearTimeout(timeout)
    }
    timeout = setTimeout(later, wait)
  }
}

/**
 * Throttle function to limit how often a function can be called
 * @param func Function to throttle
 * @param limit Limit time in milliseconds
 * @returns Throttled function
 */
export function throttle<T extends (...args: any[]) => any>(
  func: T,
  limit: number,
): (...args: Parameters<T>) => ReturnType<T> | undefined {
  let lastFunc: NodeJS.Timeout
  let lastRan = 0

  return function (...args: Parameters<T>): ReturnType<T> | undefined {
    
    const now = Date.now()

    if (now - lastRan >= limit) {
      lastRan = now
      return func.apply(this, args)
    }

    clearTimeout(lastFunc)
    lastFunc = setTimeout(
      () => {
        lastRan = now
        func.apply(this, args)
      },
      limit - (now - lastRan),
    )

    return undefined
  }
}

/**
 * Memoize function to cache results of expensive function calls
 * @param func Function to memoize
 * @returns Memoized function
 */
export function memoize<T extends (...args: any[]) => any>(func: T): (...args: Parameters<T>) => ReturnType<T> {
  const cache = new Map<string, ReturnType<T>>()

  return (...args: Parameters<T>): ReturnType<T> => {
    const key = JSON.stringify(args)
    if (cache.has(key)) {
      return cache.get(key) as ReturnType<T>
    }

    const result = func(...args)
    cache.set(key, result)
    return result
  }
}

/**
 * Measure execution time of a function
 * @param func Function to measure
 * @param label Label for console output
 * @returns Function with timing
 */
export function measureExecutionTime<T extends (...args: any[]) => any>(
  func: T,
  label = "Execution time",
): (...args: Parameters<T>) => ReturnType<T> {
  return (...args: Parameters<T>): ReturnType<T> => {
    const start = performance.now()
    const result = func(...args)
    const end = performance.now()
    console.log(`${label}: ${end - start}ms`)
    return result
  }
}

