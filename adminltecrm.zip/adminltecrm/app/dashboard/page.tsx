"use client"

import React, { useMemo, Suspense } from "react"
import Link from "next/link"
import { useCrm } from "@/lib/context/CrmContext"
import { PerformanceMetrics } from "@/components/dashboard/performance-metrics"
import { ActivityTimeline } from "@/components/dashboard/activity-timeline"
import { useOptimizedQuery } from "@/lib/hooks/useOptimizedQuery"
import { formatCurrency } from "@/lib/utils/dataProcessing"

// Lazy load chart components
const DealPipelineChart = React.lazy(() => import("@/components/dashboard/deal-pipeline-chart"))
const SalesPerformanceChart = React.lazy(() => import("@/components/dashboard/sales-performance-chart"))
const LeadSourceChart = React.lazy(() => import("@/components/dashboard/lead-source-chart"))

// Loading fallback
const ChartSkeleton = () => (
  <div className="animate-pulse flex flex-col">
    <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
    <div className="h-64 bg-gray-200 rounded w-full"></div>
  </div>
)

export default function Dashboard() {
  const { state } = useCrm()
  const { customers, leads, deals, tasks, activities, isLoading } = state

  // Fetch previous period data for comparison
  const { data: previousPeriodData } = useOptimizedQuery(
    async () => {
      // In a real app, this would fetch from an API
      // For now, we'll simulate previous period data
      return {
        deals: deals.map((deal) => ({
          ...deal,
          value: deal.value * 0.9, // 10% less in previous period
        })),
        leads: leads.slice(0, Math.floor(leads.length * 0.8)), // 20% fewer leads
        activities: activities.slice(0, Math.floor(activities.length * 0.7)), // 30% fewer activities
      }
    },
    {
      enabled: !isLoading,
      refetchInterval: false,
    },
  )

  // Calculate summary metrics
  const summaryMetrics = useMemo(() => {
    const activeCustomers = customers.filter((c) => c.status === "Active").length
    const activeDeals = deals.filter((d) => ["Proposal", "Negotiation"].includes(d.stage)).length
    const newLeads = leads.filter((l) => l.status === "New").length
    const pendingTasks = tasks.filter((t) => t.status === "Pending").length
    const totalRevenue = deals.filter((d) => d.stage === "Closed Won").reduce((sum, deal) => sum + deal.value, 0)

    return {
      activeCustomers,
      activeDeals,
      newLeads,
      pendingTasks,
      totalRevenue,
    }
  }, [customers, deals, leads, tasks])

  // Get recent deals
  const recentDeals = useMemo(() => {
    return [...deals].sort((a, b) => new Date(b.created).getTime() - new Date(a.created).getTime()).slice(0, 5)
  }, [deals])

  // Format activities for timeline
  const timelineActivities = useMemo(() => {
    return activities.slice(0, 10).map((activity) => ({
      id: activity.id,
      type: activity.type,
      title: activity.description,
      date: activity.date,
      time: activity.time,
      user: activity.user,
    }))
  }, [activities])

  return (
    <div className="row">
      {/* Summary Cards */}
      <div className="col-lg-3 col-6">
        <div className="small-box bg-info">
          <div className="inner">
            <h3>{summaryMetrics.activeCustomers}</h3>
            <p>Active Customers</p>
          </div>
          <div className="icon">
            <i className="bi bi-people"></i>
          </div>
          <Link href="/customers" className="small-box-footer">
            More info <i className="bi bi-arrow-right-circle"></i>
          </Link>
        </div>
      </div>
      <div className="col-lg-3 col-6">
        <div className="small-box bg-success">
          <div className="inner">
            <h3>{summaryMetrics.activeDeals}</h3>
            <p>Active Deals</p>
          </div>
          <div className="icon">
            <i className="bi bi-currency-dollar"></i>
          </div>
          <Link href="/deals" className="small-box-footer">
            More info <i className="bi bi-arrow-right-circle"></i>
          </Link>
        </div>
      </div>
      <div className="col-lg-3 col-6">
        <div className="small-box bg-warning">
          <div className="inner">
            <h3>{summaryMetrics.newLeads}</h3>
            <p>New Leads</p>
          </div>
          <div className="icon">
            <i className="bi bi-funnel"></i>
          </div>
          <Link href="/leads" className="small-box-footer">
            More info <i className="bi bi-arrow-right-circle"></i>
          </Link>
        </div>
      </div>
      <div className="col-lg-3 col-6">
        <div className="small-box bg-danger">
          <div className="inner">
            <h3>{summaryMetrics.pendingTasks}</h3>
            <p>Pending Tasks</p>
          </div>
          <div className="icon">
            <i className="bi bi-check2-square"></i>
          </div>
          <Link href="/tasks" className="small-box-footer">
            More info <i className="bi bi-arrow-right-circle"></i>
          </Link>
        </div>
      </div>

      {/* Performance Metrics */}
      <div className="col-md-12 mb-4">
        <PerformanceMetrics
          deals={deals}
          leads={leads}
          tasks={tasks}
          activities={activities}
          previousPeriod={previousPeriodData}
        />
      </div>

      {/* Main Content */}
      <div className="col-md-8">
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Sales Performance</h3>
            <div className="card-tools">
              <button type="button" className="btn btn-tool" data-lte-toggle="card-collapse">
                <i className="bi bi-minus"></i>
              </button>
              <div className="btn-group">
                <button type="button" className="btn btn-tool dropdown-toggle" data-bs-toggle="dropdown">
                  <i className="bi bi-wrench"></i>
                </button>
                <div className="dropdown-menu dropdown-menu-end" role="menu">
                  <a href="#" className="dropdown-item">
                    This Month
                  </a>
                  <a href="#" className="dropdown-item">
                    This Quarter
                  </a>
                  <a href="#" className="dropdown-item">
                    This Year
                  </a>
                  <div className="dropdown-divider"></div>
                  <a href="#" className="dropdown-item">
                    Custom Range
                  </a>
                </div>
              </div>
            </div>
          </div>
          <div className="card-body">
            <Suspense fallback={<ChartSkeleton />}>
              <SalesPerformanceChart deals={deals} />
            </Suspense>
          </div>
          <div className="card-footer">
            <div className="row">
              <div className="col-md-3 col-6">
                <div className="text-center border-end">
                  <span className="text-success">
                    <i className="bi bi-caret-up-fill"></i> 17%
                  </span>
                  <h5 className="fw-bold mb-0">{formatCurrency(summaryMetrics.totalRevenue)}</h5>
                  <span className="text-uppercase">TOTAL REVENUE</span>
                </div>
              </div>
              <div className="col-md-3 col-6">
                <div className="text-center border-end">
                  <span className="text-info">
                    <i className="bi bi-caret-left-fill"></i> 0%
                  </span>
                  <h5 className="fw-bold mb-0">$10,390.90</h5>
                  <span className="text-uppercase">TOTAL COST</span>
                </div>
              </div>
              <div className="col-md-3 col-6">
                <div className="text-center border-end">
                  <span className="text-success">
                    <i className="bi bi-caret-up-fill"></i> 20%
                  </span>
                  <h5 className="fw-bold mb-0">$24,813.53</h5>
                  <span className="text-uppercase">TOTAL PROFIT</span>
                </div>
              </div>
              <div className="col-md-3 col-6">
                <div className="text-center">
                  <span className="text-danger">
                    <i className="bi bi-caret-down-fill"></i> 18%
                  </span>
                  <h5 className="fw-bold mb-0">1200</h5>
                  <span className="text-uppercase">GOAL COMPLETIONS</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Deal Pipeline</h3>
            <div className="card-tools">
              <button type="button" className="btn btn-tool" data-lte-toggle="card-collapse">
                <i className="bi bi-minus"></i>
              </button>
            </div>
          </div>
          <div className="card-body">
            <Suspense fallback={<ChartSkeleton />}>
              <DealPipelineChart deals={deals} />
            </Suspense>
          </div>
        </div>

        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Recent Deals</h3>
            <div className="card-tools">
              <button type="button" className="btn btn-tool" data-lte-toggle="card-collapse">
                <i className="bi bi-minus"></i>
              </button>
            </div>
          </div>
          <div className="card-body p-0">
            <div className="table-responsive">
              <table className="table table-striped">
                <thead>
                  <tr>
                    <th>Deal</th>
                    <th>Customer</th>
                    <th>Status</th>
                    <th>Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {recentDeals.map((deal) => {
                    const customer = customers.find((c) => c.id === deal.customer)
                    return (
                      <tr key={deal.id}>
                        <td>
                          <Link href={`/deals/${deal.id}`}>{deal.name}</Link>
                        </td>
                        <td>{customer?.name || "Unknown"}</td>
                        <td>
                          <span
                            className={`badge ${
                              deal.stage === "Closed Won"
                                ? "bg-success"
                                : deal.stage === "Closed Lost"
                                  ? "bg-danger"
                                  : deal.stage === "Negotiation"
                                    ? "bg-warning"
                                    : deal.stage === "Proposal"
                                      ? "bg-info"
                                      : "bg-primary"
                            }`}
                          >
                            {deal.stage}
                          </span>
                        </td>
                        <td>{formatCurrency(deal.value)}</td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </div>
          <div className="card-footer clearfix">
            <Link href="/deals/new" className="btn btn-sm btn-primary float-start">
              Place New Deal
            </Link>
            <Link href="/deals" className="btn btn-sm btn-secondary float-end">
              View All Deals
            </Link>
          </div>
        </div>
      </div>

      <div className="col-md-4">
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Lead Sources</h3>
            <div className="card-tools">
              <button type="button" className="btn btn-tool" data-lte-toggle="card-collapse">
                <i className="bi bi-minus"></i>
              </button>
            </div>
          </div>
          <div className="card-body">
            <Suspense fallback={<ChartSkeleton />}>
              <LeadSourceChart leads={leads} />
            </Suspense>
          </div>
        </div>

        <ActivityTimeline activities={timelineActivities} title="Recent Activity" maxItems={5} />

        <div className="card direct-chat direct-chat-primary">
          <div className="card-header">
            <h3 className="card-title">Upcoming Tasks</h3>
            <div className="card-tools">
              <span title="3 New Tasks" className="badge bg-primary">
                3
              </span>
              <button type="button" className="btn btn-tool" data-lte-toggle="card-collapse">
                <i className="bi bi-minus"></i>
              </button>
            </div>
          </div>
          <div className="card-body p-0">
            <ul className="todo-list">
              {tasks.slice(0, 5).map((task) => (
                <li key={task.id} className="p-2">
                  <div className="d-flex align-items-center">
                    <input type="checkbox" className="me-2" />
                    <span className="text">{task.title}</span>
                    <small
                      className={`badge ${
                        task.priority === "High" ? "bg-danger" : task.priority === "Medium" ? "bg-warning" : "bg-info"
                      } ms-auto`}
                    >
                      <i className="bi bi-clock"></i> {task.dueDate}
                    </small>
                  </div>
                </li>
              ))}
            </ul>
          </div>
          <div className="card-footer text-center">
            <Link href="/tasks" className="btn btn-primary btn-sm">
              View All Tasks
            </Link>
          </div>
        </div>
      </div>
    </div>
    // Removed ErrorFallback wrapper
    // </ErrorFallback>
  )
}

