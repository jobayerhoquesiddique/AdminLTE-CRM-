"use client"

import type React from "react"
import { useEffect } from "react"
import { Sidebar } from "@/components/sidebar"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { CrmProvider } from "@/lib/context/CrmContext"

interface ClientLayoutProps {
  children: React.ReactNode
}

export default function ClientLayout({ children }: ClientLayoutProps) {
  useEffect(() => {
    const handleSidebarToggle = () => {
      document.body.classList.toggle("sidebar-collapse")
    }

    const sidebarTogglers = document.querySelectorAll("[data-lte-toggle='sidebar']")
    sidebarTogglers.forEach((toggler) => {
      toggler.addEventListener("click", handleSidebarToggle)
    })

    const cardTogglers = document.querySelectorAll("[data-lte-toggle='card-collapse']")
    cardTogglers.forEach((toggler) => {
      toggler.addEventListener("click", (e) => {
        const card = (e.currentTarget as HTMLElement).closest(".card")
        if (card) {
          card.querySelector(".card-body")?.classList.toggle("collapse")
        }
      })
    })

    return () => {
      sidebarTogglers.forEach((toggler) => {
        toggler.removeEventListener("click", handleSidebarToggle)
      })
    }
  }, [])

  return (
    <CrmProvider>
      <div className="wrapper">
        <Header />
        <Sidebar />
        <div className="content-wrapper">
          <div className="content">
            <div className="container-fluid p-3">{children}</div>
          </div>
        </div>
        <Footer />
      </div>
    </CrmProvider>
  )
}

