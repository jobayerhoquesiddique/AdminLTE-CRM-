export default function SalesReport() {
  return (
    <div className="row">
      <div className="col-md-12">
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Sales Report</h3>
            <div className="card-tools">
              <div className="btn-group">
                <button type="button" className="btn btn-sm btn-primary">
                  This Month
                </button>
                <button type="button" className="btn btn-sm btn-default">
                  This Quarter
                </button>
                <button type="button" className="btn btn-sm btn-default">
                  This Year
                </button>
                <button type="button" className="btn btn-sm btn-default">
                  Custom
                </button>
              </div>
            </div>
          </div>
          <div className="card-body">
            <div className="row">
              <div className="col-md-3 col-sm-6 col-12">
                <div className="info-box">
                  <span className="info-box-icon bg-info">
                    <i className="bi bi-cash-stack"></i>
                  </span>
                  <div className="info-box-content">
                    <span className="info-box-text">Total Revenue</span>
                    <span className="info-box-number">$45,200</span>
                  </div>
                </div>
              </div>
              <div className="col-md-3 col-sm-6 col-12">
                <div className="info-box">
                  <span className="info-box-icon bg-success">
                    <i className="bi bi-check-circle"></i>
                  </span>
                  <div className="info-box-content">
                    <span className="info-box-text">Deals Won</span>
                    <span className="info-box-number">12</span>
                  </div>
                </div>
              </div>
              <div className="col-md-3 col-sm-6 col-12">
                <div className="info-box">
                  <span className="info-box-icon bg-warning">
                    <i className="bi bi-hourglass-split"></i>
                  </span>
                  <div className="info-box-content">
                    <span className="info-box-text">Deals in Pipeline</span>
                    <span className="info-box-number">24</span>
                  </div>
                </div>
              </div>
              <div className="col-md-3 col-sm-6 col-12">
                <div className="info-box">
                  <span className="info-box-icon bg-danger">
                    <i className="bi bi-x-circle"></i>
                  </span>
                  <div className="info-box-content">
                    <span className="info-box-text">Deals Lost</span>
                    <span className="info-box-number">5</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="row mt-4">
              <div className="col-md-8">
                <div className="card">
                  <div className="card-header">
                    <h3 className="card-title">Monthly Revenue</h3>
                  </div>
                  <div className="card-body">
                    <canvas
                      id="revenueChart"
                      style={{ minHeight: "300px", height: "300px", maxHeight: "300px", maxWidth: "100%" }}
                    ></canvas>
                  </div>
                </div>
              </div>
              <div className="col-md-4">
                <div className="card">
                  <div className="card-header">
                    <h3 className="card-title">Deal Status</h3>
                  </div>
                  <div className="card-body">
                    <canvas
                      id="dealStatusChart"
                      style={{ minHeight: "300px", height: "300px", maxHeight: "300px", maxWidth: "100%" }}
                    ></canvas>
                  </div>
                </div>
              </div>
            </div>

            <div className="row mt-4">
              <div className="col-md-6">
                <div className="card">
                  <div className="card-header">
                    <h3 className="card-title">Top Performing Products</h3>
                  </div>
                  <div className="card-body table-responsive p-0">
                    <table className="table table-hover text-nowrap">
                      <thead>
                        <tr>
                          <th>Product</th>
                          <th>Revenue</th>
                          <th>Deals</th>
                          <th>Avg. Deal Size</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>Enterprise Software Package</td>
                          <td>$15,000</td>
                          <td>3</td>
                          <td>$5,000</td>
                        </tr>
                        <tr>
                          <td>Cloud Migration</td>
                          <td>$12,000</td>
                          <td>2</td>
                          <td>$6,000</td>
                        </tr>
                        <tr>
                          <td>Support Contract</td>
                          <td>$8,200</td>
                          <td>4</td>
                          <td>$2,050</td>
                        </tr>
                        <tr>
                          <td>Hardware Upgrade</td>
                          <td>$7,200</td>
                          <td>2</td>
                          <td>$3,600</td>
                        </tr>
                        <tr>
                          <td>IT Consulting</td>
                          <td>$2,800</td>
                          <td>1</td>
                          <td>$2,800</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              <div className="col-md-6">
                <div className="card">
                  <div className="card-header">
                    <h3 className="card-title">Top Performing Sales Reps</h3>
                  </div>
                  <div className="card-body table-responsive p-0">
                    <table className="table table-hover text-nowrap">
                      <thead>
                        <tr>
                          <th>Sales Rep</th>
                          <th>Revenue</th>
                          <th>Deals Won</th>
                          <th>Conversion Rate</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>John Doe</td>
                          <td>$18,500</td>
                          <td>5</td>
                          <td>62%</td>
                        </tr>
                        <tr>
                          <td>Sarah Johnson</td>
                          <td>$12,700</td>
                          <td>3</td>
                          <td>58%</td>
                        </tr>
                        <tr>
                          <td>Michael Brown</td>
                          <td>$8,000</td>
                          <td>2</td>
                          <td>45%</td>
                        </tr>
                        <tr>
                          <td>Emily Davis</td>
                          <td>$4,000</td>
                          <td>1</td>
                          <td>40%</td>
                        </tr>
                        <tr>
                          <td>Robert Wilson</td>
                          <td>$2,000</td>
                          <td>1</td>
                          <td>33%</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="card-footer">
            <button type="button" className="btn btn-primary">
              <i className="bi bi-download"></i> Export Report
            </button>
            <button type="button" className="btn btn-default ms-2">
              <i className="bi bi-printer"></i> Print
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

