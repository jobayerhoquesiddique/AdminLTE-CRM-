"use client"

import { useEffect } from "react"

export default function PerformanceReport() {
  useEffect(() => {
    // Load ApexCharts dynamically on the client side
    const loadApexCharts = async () => {
      try {
        const ApexCharts = (await import("apexcharts")).default

        // Sales Performance Chart
        const salesPerformanceChartOptions = {
          series: [
            {
              name: "John Doe",
              data: [44, 55, 57, 56, 61, 58, 63],
            },
            {
              name: "Sarah Johnson",
              data: [76, 85, 101, 98, 87, 105, 91],
            },
            {
              name: "Michael Brown",
              data: [35, 41, 36, 26, 45, 48, 52],
            },
          ],
          chart: {
            type: "bar",
            height: 350,
            toolbar: {
              show: false,
            },
          },
          plotOptions: {
            bar: {
              horizontal: false,
              columnWidth: "55%",
              endingShape: "rounded",
            },
          },
          dataLabels: {
            enabled: false,
          },
          stroke: {
            show: true,
            width: 2,
            colors: ["transparent"],
          },
          xaxis: {
            categories: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul"],
          },
          yaxis: {
            title: {
              text: "$ (thousands)",
            },
          },
          fill: {
            opacity: 1,
          },
          tooltip: {
            y: {
              formatter: (val) => "$ " + val + " thousands",
            },
          },
          colors: ["#0d6efd", "#20c997", "#ffc107"],
        }

        // Conversion Rate Chart
        const conversionRateChartOptions = {
          series: [
            {
              name: "Conversion Rate",
              data: [65, 59, 80, 81, 56, 55, 40],
            },
          ],
          chart: {
            height: 350,
            type: "line",
            toolbar: {
              show: false,
            },
          },
          colors: ["#0d6efd"],
          dataLabels: {
            enabled: false,
          },
          stroke: {
            curve: "smooth",
            width: 3,
          },
          xaxis: {
            categories: [
              "John Doe",
              "Sarah Johnson",
              "Michael Brown",
              "Emily Davis",
              "Robert Wilson",
              "Team Average",
              "Industry Average",
            ],
          },
          yaxis: {
            title: {
              text: "Conversion Rate (%)",
            },
            min: 0,
            max: 100,
          },
          markers: {
            size: 5,
          },
        }

        // Deal Size Chart
        const dealSizeChartOptions = {
          series: [
            {
              name: "Average Deal Size",
              data: [8500, 12700, 7800, 9200, 6500, 8900, 10000],
            },
          ],
          chart: {
            height: 350,
            type: "bar",
            toolbar: {
              show: false,
            },
          },
          colors: ["#20c997"],
          plotOptions: {
            bar: {
              borderRadius: 4,
              horizontal: true,
            },
          },
          dataLabels: {
            enabled: true,
            formatter: (val) => "$" + val,
            offsetX: 10,
          },
          xaxis: {
            categories: [
              "John Doe",
              "Sarah Johnson",
              "Michael Brown",
              "Emily Davis",
              "Robert Wilson",
              "Team Average",
              "Industry Average",
            ],
          },
        }

        // Initialize charts if elements exist
        const salesPerformanceChartElement = document.getElementById("salesPerformanceChart")
        const conversionRateChartElement = document.getElementById("conversionRateChart")
        const dealSizeChartElement = document.getElementById("dealSizeChart")

        if (salesPerformanceChartElement) {
          new ApexCharts(salesPerformanceChartElement, salesPerformanceChartOptions).render()
        }

        if (conversionRateChartElement) {
          new ApexCharts(conversionRateChartElement, conversionRateChartOptions).render()
        }

        if (dealSizeChartElement) {
          new ApexCharts(dealSizeChartElement, dealSizeChartOptions).render()
        }
      } catch (error) {
        console.error("Error loading ApexCharts:", error)
      }
    }

    loadApexCharts()
  }, [])

  return (
    <div className="row">
      <div className="col-md-12">
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Performance Report</h3>
            <div className="card-tools">
              <div className="btn-group">
                <button type="button" className="btn btn-sm btn-primary">
                  This Quarter
                </button>
                <button type="button" className="btn btn-sm btn-default">
                  This Year
                </button>
                <button type="button" className="btn btn-sm btn-default">
                  Last Year
                </button>
                <button type="button" className="btn btn-sm btn-default">
                  Custom
                </button>
              </div>
            </div>
          </div>
          <div className="card-body">
            <div className="row">
              <div className="col-md-3 col-sm-6 col-12">
                <div className="info-box">
                  <span className="info-box-icon bg-info">
                    <i className="bi bi-graph-up"></i>
                  </span>
                  <div className="info-box-content">
                    <span className="info-box-text">Total Revenue</span>
                    <span className="info-box-number">$145,000</span>
                    <span className="text-success">
                      <i className="bi bi-arrow-up"></i> 15% from last period
                    </span>
                  </div>
                </div>
              </div>
              <div className="col-md-3 col-sm-6 col-12">
                <div className="info-box">
                  <span className="info-box-icon bg-success">
                    <i className="bi bi-check-circle"></i>
                  </span>
                  <div className="info-box-content">
                    <span className="info-box-text">Deals Closed</span>
                    <span className="info-box-number">32</span>
                    <span className="text-success">
                      <i className="bi bi-arrow-up"></i> 8% from last period
                    </span>
                  </div>
                </div>
              </div>
              <div className="col-md-3 col-sm-6 col-12">
                <div className="info-box">
                  <span className="info-box-icon bg-warning">
                    <i className="bi bi-currency-dollar"></i>
                  </span>
                  <div className="info-box-content">
                    <span className="info-box-text">Avg. Deal Size</span>
                    <span className="info-box-number">$4,531</span>
                    <span className="text-success">
                      <i className="bi bi-arrow-up"></i> 5% from last period
                    </span>
                  </div>
                </div>
              </div>
              <div className="col-md-3 col-sm-6 col-12">
                <div className="info-box">
                  <span className="info-box-icon bg-danger">
                    <i className="bi bi-percent"></i>
                  </span>
                  <div className="info-box-content">
                    <span className="info-box-text">Conversion Rate</span>
                    <span className="info-box-number">24%</span>
                    <span className="text-danger">
                      <i className="bi bi-arrow-down"></i> 3% from last period
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div className="row mt-4">
              <div className="col-md-12">
                <div className="card">
                  <div className="card-header">
                    <h3 className="card-title">Sales Performance by Month</h3>
                  </div>
                  <div className="card-body">
                    <div
                      id="salesPerformanceChart"
                      style={{ minHeight: "350px", height: "350px", maxHeight: "350px", maxWidth: "100%" }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>

            <div className="row mt-4">
              <div className="col-md-6">
                <div className="card">
                  <div className="card-header">
                    <h3 className="card-title">Conversion Rate by Sales Rep</h3>
                  </div>
                  <div className="card-body">
                    <div
                      id="conversionRateChart"
                      style={{ minHeight: "350px", height: "350px", maxHeight: "350px", maxWidth: "100%" }}
                    ></div>
                  </div>
                </div>
              </div>
              <div className="col-md-6">
                <div className="card">
                  <div className="card-header">
                    <h3 className="card-title">Average Deal Size by Sales Rep</h3>
                  </div>
                  <div className="card-body">
                    <div
                      id="dealSizeChart"
                      style={{ minHeight: "350px", height: "350px", maxHeight: "350px", maxWidth: "100%" }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>

            <div className="row mt-4">
              <div className="col-md-12">
                <div className="card">
                  <div className="card-header">
                    <h3 className="card-title">Sales Rep Performance</h3>
                  </div>
                  <div className="card-body table-responsive p-0">
                    <table className="table table-hover text-nowrap">
                      <thead>
                        <tr>
                          <th>Sales Rep</th>
                          <th>Revenue</th>
                          <th>Deals Closed</th>
                          <th>Avg. Deal Size</th>
                          <th>Conversion Rate</th>
                          <th>Deals in Pipeline</th>
                          <th>Performance</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>John Doe</td>
                          <td>$45,200</td>
                          <td>12</td>
                          <td>$3,767</td>
                          <td>28%</td>
                          <td>15</td>
                          <td>
                            <div className="progress progress-sm">
                              <div
                                className="progress-bar bg-success"
                                role="progressbar"
                                style={{ width: "85%" }}
                                aria-valuenow={85}
                                aria-valuemin={0}
                                aria-valuemax={100}
                              ></div>
                            </div>
                            <small>85% of target</small>
                          </td>
                        </tr>
                        <tr>
                          <td>Sarah Johnson</td>
                          <td>$52,700</td>
                          <td>10</td>
                          <td>$5,270</td>
                          <td>32%</td>
                          <td>12</td>
                          <td>
                            <div className="progress progress-sm">
                              <div
                                className="progress-bar bg-success"
                                role="progressbar"
                                style={{ width: "95%" }}
                                aria-valuenow={95}
                                aria-valuemin={0}
                                aria-valuemax={100}
                              ></div>
                            </div>
                            <small>95% of target</small>
                          </td>
                        </tr>
                        <tr>
                          <td>Michael Brown</td>
                          <td>$28,500</td>
                          <td>7</td>
                          <td>$4,071</td>
                          <td>18%</td>
                          <td>9</td>
                          <td>
                            <div className="progress progress-sm">
                              <div
                                className="progress-bar bg-warning"
                                role="progressbar"
                                style={{ width: "65%" }}
                                aria-valuenow={65}
                                aria-valuemin={0}
                                aria-valuemax={100}
                              ></div>
                            </div>
                            <small>65% of target</small>
                          </td>
                        </tr>
                        <tr>
                          <td>Emily Davis</td>
                          <td>$18,600</td>
                          <td>3</td>
                          <td>$6,200</td>
                          <td>15%</td>
                          <td>7</td>
                          <td>
                            <div className="progress progress-sm">
                              <div
                                className="progress-bar bg-danger"
                                role="progressbar"
                                style={{ width: "45%" }}
                                aria-valuenow={45}
                                aria-valuemin={0}
                                aria-valuemax={100}
                              ></div>
                            </div>
                            <small>45% of target</small>
                          </td>
                        </tr>
                        <tr>
                          <td>Robert Wilson</td>
                          <td>$0</td>
                          <td>0</td>
                          <td>$0</td>
                          <td>0%</td>
                          <td>5</td>
                          <td>
                            <div className="progress progress-sm">
                              <div
                                className="progress-bar bg-danger"
                                role="progressbar"
                                style={{ width: "0%" }}
                                aria-valuenow={0}
                                aria-valuemin={0}
                                aria-valuemax={100}
                              ></div>
                            </div>
                            <small>0% of target</small>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="card-footer">
            <button type="button" className="btn btn-primary">
              <i className="bi bi-download"></i> Export Report
            </button>
            <button type="button" className="btn btn-default ms-2">
              <i className="bi bi-printer"></i> Print
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

