"use client"

import { useState } from "react"

export default function Support() {
  const [activeTab, setActiveTab] = useState("contact")
  const [ticketCategory, setTicketCategory] = useState("technical")
  const [ticketPriority, setTicketPriority] = useState("medium")

  return (
    <div className="row">
      <div className="col-md-3">
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Support</h3>
          </div>
          <div className="card-body p-0">
            <ul className="nav nav-pills flex-column">
              <li className="nav-item">
                <a
                  className={`nav-link ${activeTab === "contact" ? "active" : ""}`}
                  href="#"
                  onClick={(e) => {
                    e.preventDefault()
                    setActiveTab("contact")
                  }}
                >
                  <i className="bi bi-envelope me-2"></i> Contact Support
                </a>
              </li>
              <li className="nav-item">
                <a
                  className={`nav-link ${activeTab === "tickets" ? "active" : ""}`}
                  href="#"
                  onClick={(e) => {
                    e.preventDefault()
                    setActiveTab("tickets")
                  }}
                >
                  <i className="bi bi-ticket-detailed me-2"></i> My Tickets
                </a>
              </li>
              <li className="nav-item">
                <a
                  className={`nav-link ${activeTab === "knowledge" ? "active" : ""}`}
                  href="#"
                  onClick={(e) => {
                    e.preventDefault()
                    setActiveTab("knowledge")
                  }}
                >
                  <i className="bi bi-book me-2"></i> Knowledge Base
                </a>
              </li>
              <li className="nav-item">
                <a
                  className={`nav-link ${activeTab === "faq" ? "active" : ""}`}
                  href="#"
                  onClick={(e) => {
                    e.preventDefault()
                    setActiveTab("faq")
                  }}
                >
                  <i className="bi bi-question-circle me-2"></i> FAQ
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div className="col-md-9">
        {/* Contact Support Tab */}
        {activeTab === "contact" && (
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">Contact Support</h3>
            </div>
            <div className="card-body">
              <div className="alert alert-info">
                <i className="bi bi-info-circle me-2"></i> Our support team is available Monday to Friday, 9:00 AM to
                5:00 PM EST.
              </div>
              <form>
                <div className="row mb-3">
                  <div className="col-md-6">
                    <div className="form-group">
                      <label htmlFor="name">Name</label>
                      <input
                        type="text"
                        className="form-control"
                        id="name"
                        placeholder="Enter your name"
                        defaultValue="John Doe"
                      />
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="form-group">
                      <label htmlFor="email">Email</label>
                      <input
                        type="email"
                        className="form-control"
                        id="email"
                        placeholder="Enter your email"
                        defaultValue="john.doe@example.com"
                      />
                    </div>
                  </div>
                </div>
                <div className="row mb-3">
                  <div className="col-md-6">
                    <div className="form-group">
                      <label htmlFor="category">Category</label>
                      <select
                        className="form-control"
                        id="category"
                        value={ticketCategory}
                        onChange={(e) => setTicketCategory(e.target.value)}
                      >
                        <option value="technical">Technical Issue</option>
                        <option value="billing">Billing Question</option>
                        <option value="feature">Feature Request</option>
                        <option value="account">Account Management</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="form-group">
                      <label htmlFor="priority">Priority</label>
                      <select
                        className="form-control"
                        id="priority"
                        value={ticketPriority}
                        onChange={(e) => setTicketPriority(e.target.value)}
                      >
                        <option value="low">Low</option>
                        <option value="medium">Medium</option>
                        <option value="high">High</option>
                        <option value="urgent">Urgent</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div className="form-group mb-3">
                  <label htmlFor="subject">Subject</label>
                  <input type="text" className="form-control" id="subject" placeholder="Enter subject" />
                </div>
                <div className="form-group mb-3">
                  <label htmlFor="message">Message</label>
                  <textarea className="form-control" id="message" rows={5} placeholder="Enter your message"></textarea>
                </div>
                <div className="form-group mb-3">
                  <label htmlFor="attachment">Attachments</label>
                  <input type="file" className="form-control" id="attachment" multiple />
                  <small className="form-text text-muted">
                    You can attach screenshots or documents to help us understand your issue better. Maximum file size:
                    10MB.
                  </small>
                </div>
                <button type="submit" className="btn btn-primary">
                  Submit Ticket
                </button>
              </form>
            </div>
          </div>
        )}

        {/* My Tickets Tab */}
        {activeTab === "tickets" && (
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">My Support Tickets</h3>
            </div>
            <div className="card-body">
              <div className="d-flex justify-content-between mb-3">
                <div>
                  <button className="btn btn-primary me-2">
                    <i className="bi bi-plus"></i> New Ticket
                  </button>
                  <div className="btn-group">
                    <button type="button" className="btn btn-default">
                      All Tickets
                    </button>
                    <button type="button" className="btn btn-default">
                      Open
                    </button>
                    <button type="button" className="btn btn-default">
                      Closed
                    </button>
                  </div>
                </div>
                <div className="input-group" style={{ width: "250px" }}>
                  <input type="text" className="form-control" placeholder="Search tickets..." />
                  <button className="btn btn-outline-secondary" type="button">
                    <i className="bi bi-search"></i>
                  </button>
                </div>
              </div>
              <div className="table-responsive">
                <table className="table table-striped">
                  <thead>
                    <tr>
                      <th>Ticket ID</th>
                      <th>Subject</th>
                      <th>Category</th>
                      <th>Status</th>
                      <th>Priority</th>
                      <th>Created</th>
                      <th>Last Updated</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>#1234</td>
                      <td>Cannot access customer records</td>
                      <td>Technical Issue</td>
                      <td>
                        <span className="badge bg-warning">In Progress</span>
                      </td>
                      <td>
                        <span className="badge bg-danger">High</span>
                      </td>
                      <td>Mar 15, 2023</td>
                      <td>Mar 16, 2023</td>
                      <td>
                        <button className="btn btn-info btn-sm me-1">
                          <i className="bi bi-eye"></i>
                        </button>
                        <button className="btn btn-primary btn-sm">
                          <i className="bi bi-pencil"></i>
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>#1233</td>
                      <td>Billing question about subscription</td>
                      <td>Billing Question</td>
                      <td>
                        <span className="badge bg-success">Resolved</span>
                      </td>
                      <td>
                        <span className="badge bg-warning">Medium</span>
                      </td>
                      <td>Mar 10, 2023</td>
                      <td>Mar 12, 2023</td>
                      <td>
                        <button className="btn btn-info btn-sm me-1">
                          <i className="bi bi-eye"></i>
                        </button>
                        <button className="btn btn-primary btn-sm">
                          <i className="bi bi-pencil"></i>
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>#1232</td>
                      <td>Feature request: Export to PDF</td>
                      <td>Feature Request</td>
                      <td>
                        <span className="badge bg-info">Under Review</span>
                      </td>
                      <td>
                        <span className="badge bg-secondary">Low</span>
                      </td>
                      <td>Mar 5, 2023</td>
                      <td>Mar 7, 2023</td>
                      <td>
                        <button className="btn btn-info btn-sm me-1">
                          <i className="bi bi-eye"></i>
                        </button>
                        <button className="btn btn-primary btn-sm">
                          <i className="bi bi-pencil"></i>
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>#1231</td>
                      <td>Need to reset password</td>
                      <td>Account Management</td>
                      <td>
                        <span className="badge bg-success">Resolved</span>
                      </td>
                      <td>
                        <span className="badge bg-danger">High</span>
                      </td>
                      <td>Feb 28, 2023</td>
                      <td>Feb 28, 2023</td>
                      <td>
                        <button className="btn btn-info btn-sm me-1">
                          <i className="bi bi-eye"></i>
                        </button>
                        <button className="btn btn-primary btn-sm">
                          <i className="bi bi-pencil"></i>
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>#1230</td>
                      <td>Dashboard not loading correctly</td>
                      <td>Technical Issue</td>
                      <td>
                        <span className="badge bg-success">Resolved</span>
                      </td>
                      <td>
                        <span className="badge bg-warning">Medium</span>
                      </td>
                      <td>Feb 25, 2023</td>
                      <td>Feb 26, 2023</td>
                      <td>
                        <button className="btn btn-info btn-sm me-1">
                          <i className="bi bi-eye"></i>
                        </button>
                        <button className="btn btn-primary btn-sm">
                          <i className="bi bi-pencil"></i>
                        </button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div className="d-flex justify-content-between align-items-center mt-3">
                <div>Showing 1 to 5 of 12 entries</div>
                <ul className="pagination pagination-sm m-0">
                  <li className="page-item">
                    <a className="page-link" href="#">
                      «
                    </a>
                  </li>
                  <li className="page-item active">
                    <a className="page-link" href="#">
                      1
                    </a>
                  </li>
                  <li className="page-item">
                    <a className="page-link" href="#">
                      2
                    </a>
                  </li>
                  <li className="page-item">
                    <a className="page-link" href="#">
                      3
                    </a>
                  </li>
                  <li className="page-item">
                    <a className="page-link" href="#">
                      »
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        )}

        {/* Knowledge Base Tab */}
        {activeTab === "knowledge" && (
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">Knowledge Base</h3>
            </div>
            <div className="card-body">
              <div className="input-group mb-4">
                <input type="text" className="form-control" placeholder="Search knowledge base..." />
                <button className="btn btn-primary" type="button">
                  <i className="bi bi-search me-1"></i> Search
                </button>
              </div>

              <div className="row">
                <div className="col-md-4 mb-4">
                  <div className="card h-100">
                    <div className="card-body">
                      <h5 className="card-title">
                        <i className="bi bi-book text-primary me-2"></i> Getting Started
                      </h5>
                      <p className="card-text">Learn the basics of using the CRM system.</p>
                      <ul className="list-unstyled">
                        <li>
                          <a href="#">Introduction to the Dashboard</a>
                        </li>
                        <li>
                          <a href="#">Setting Up Your Profile</a>
                        </li>
                        <li>
                          <a href="#">Managing Customers</a>
                        </li>
                        <li>
                          <a href="#">Working with Leads</a>
                        </li>
                        <li>
                          <a href="#">View all articles...</a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div className="col-md-4 mb-4">
                  <div className="card h-100">
                    <div className="card-body">
                      <h5 className="card-title">
                        <i className="bi bi-gear text-primary me-2"></i> Configuration
                      </h5>
                      <p className="card-text">Configure your CRM to match your business needs.</p>
                      <ul className="list-unstyled">
                        <li>
                          <a href="#">User Management</a>
                        </li>
                        <li>
                          <a href="#">Email Settings</a>
                        </li>
                        <li>
                          <a href="#">Customizing Fields</a>
                        </li>
                        <li>
                          <a href="#">Workflow Automation</a>
                        </li>
                        <li>
                          <a href="#">View all articles...</a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div className="col-md-4 mb-4">
                  <div className="card h-100">
                    <div className="card-body">
                      <h5 className="card-title">
                        <i className="bi bi-graph-up text-primary me-2"></i> Reports
                      </h5>
                      <p className="card-text">Learn how to create and analyze reports.</p>
                      <ul className="list-unstyled">
                        <li>
                          <a href="#">Creating Custom Reports</a>
                        </li>
                        <li>
                          <a href="#">Sales Performance Analysis</a>
                        </li>
                        <li>
                          <a href="#">Activity Reports</a>
                        </li>
                        <li>
                          <a href="#">Exporting Data</a>
                        </li>
                        <li>
                          <a href="#">View all articles...</a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div className="col-md-4 mb-4">
                  <div className="card h-100">
                    <div className="card-body">
                      <h5 className="card-title">
                        <i className="bi bi-people text-primary me-2"></i> Customer Management
                      </h5>
                      <p className="card-text">Effectively manage your customer relationships.</p>
                      <ul className="list-unstyled">
                        <li>
                          <a href="#">Adding New Customers</a>
                        </li>
                        <li>
                          <a href="#">Customer Segmentation</a>
                        </li>
                        <li>
                          <a href="#">Communication History</a>
                        </li>
                        <li>
                          <a href="#">Customer Insights</a>
                        </li>
                        <li>
                          <a href="#">View all articles...</a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div className="col-md-4 mb-4">
                  <div className="card h-100">
                    <div className="card-body">
                      <h5 className="card-title">
                        <i className="bi bi-currency-dollar text-primary me-2"></i> Sales Pipeline
                      </h5>
                      <p className="card-text">Optimize your sales process and close more deals.</p>
                      <ul className="list-unstyled">
                        <li>
                          <a href="#">Pipeline Management</a>
                        </li>
                        <li>
                          <a href="#">Deal Tracking</a>
                        </li>
                        <li>
                          <a href="#">Sales Forecasting</a>
                        </li>
                        <li>
                          <a href="#">Closing Techniques</a>
                        </li>
                        <li>
                          <a href="#">View all articles...</a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div className="col-md-4 mb-4">
                  <div className="card h-100">
                    <div className="card-body">
                      <h5 className="card-title">
                        <i className="bi bi-tools text-primary me-2"></i> Troubleshooting
                      </h5>
                      <p className="card-text">Resolve common issues and get back on track.</p>
                      <ul className="list-unstyled">
                        <li>
                          <a href="#">Login Problems</a>
                        </li>
                        <li>
                          <a href="#">Data Import Issues</a>
                        </li>
                        <li>
                          <a href="#">Report Generation Errors</a>
                        </li>
                        <li>
                          <a href="#">Email Integration Troubleshooting</a>
                        </li>
                        <li>
                          <a href="#">View all articles...</a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* FAQ Tab */}
        {activeTab === "faq" && (
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">Frequently Asked Questions</h3>
            </div>
            <div className="card-body">
              <div className="accordion" id="faqAccordion">
                <div className="accordion-item">
                  <h2 className="accordion-header" id="headingOne">
                    <button
                      className="accordion-button"
                      type="button"
                      data-bs-toggle="collapse"
                      data-bs-target="#collapseOne"
                      aria-expanded="true"
                      aria-controls="collapseOne"
                    >
                      How do I reset my password?
                    </button>
                  </h2>
                  <div
                    id="collapseOne"
                    className="accordion-collapse collapse show"
                    aria-labelledby="headingOne"
                    data-bs-parent="#faqAccordion"
                  >
                    <div className="accordion-body">
                      <p>To reset your password, follow these steps:</p>
                      <ol>
                        <li>Click on the "Forgot Password" link on the login page.</li>
                        <li>Enter your email address and click "Submit".</li>
                        <li>Check your email for a password reset link.</li>
                        <li>Click the link and follow the instructions to create a new password.</li>
                      </ol>
                      <p>If you don't receive the email, check your spam folder or contact support for assistance.</p>
                    </div>
                  </div>
                </div>
                <div className="accordion-item">
                  <h2 className="accordion-header" id="headingTwo">
                    <button
                      className="accordion-button collapsed"
                      type="button"
                      data-bs-toggle="collapse"
                      data-bs-target="#collapseTwo"
                      aria-expanded="false"
                      aria-controls="collapseTwo"
                    >
                      How do I import contacts from a CSV file?
                    </button>
                  </h2>
                  <div
                    id="collapseTwo"
                    className="accordion-collapse collapse"
                    aria-labelledby="headingTwo"
                    data-bs-parent="#faqAccordion"
                  >
                    <div className="accordion-body">
                      <p>Importing contacts from a CSV file is easy:</p>
                      <ol>
                        <li>Go to the Customers section.</li>
                        <li>Click on the "Import" button.</li>
                        <li>Select "CSV" as the file format.</li>
                        <li>Click "Choose File" and select your CSV file.</li>
                        <li>Map the CSV columns to the CRM fields.</li>
                        <li>Click "Import" to start the process.</li>
                      </ol>
                      <p>Make sure your CSV file has headers that match or can be mapped to the CRM fields.</p>
                    </div>
                  </div>
                </div>
                <div className="accordion-item">
                  <h2 className="accordion-header" id="headingThree">
                    <button
                      className="accordion-button collapsed"
                      type="button"
                      data-bs-toggle="collapse"
                      data-bs-target="#collapseThree"
                      aria-expanded="false"
                      aria-controls="collapseThree"
                    >
                      How do I create a custom report?
                    </button>
                  </h2>
                  <div
                    id="collapseThree"
                    className="accordion-collapse collapse"
                    aria-labelledby="headingThree"
                    data-bs-parent="#faqAccordion"
                  >
                    <div className="accordion-body">
                      <p>To create a custom report:</p>
                      <ol>
                        <li>Go to the Reports section.</li>
                        <li>Click on "Create New Report".</li>
                        <li>Select the report type (Sales, Activity, Performance, etc.).</li>
                        <li>Choose the fields you want to include in the report.</li>
                        <li>Set filters to narrow down the data if needed.</li>
                        <li>Select the grouping and sorting options.</li>
                        <li>Choose the visualization type (table, chart, etc.).</li>
                        <li>Save the report with a descriptive name.</li>
                      </ol>
                      <p>You can schedule reports to be generated and emailed automatically on a regular basis.</p>
                    </div>
                  </div>
                </div>
                <div className="accordion-item">
                  <h2 className="accordion-header" id="headingFour">
                    <button
                      className="accordion-button collapsed"
                      type="button"
                      data-bs-toggle="collapse"
                      data-bs-target="#collapseFour"
                      aria-expanded="false"
                      aria-controls="collapseFour"
                    >
                      How do I set up email integration?
                    </button>
                  </h2>
                  <div
                    id="collapseFour"
                    className="accordion-collapse collapse"
                    aria-labelledby="headingFour"
                    data-bs-parent="#faqAccordion"
                  >
                    <div className="accordion-body">
                      <p>To set up email integration:</p>
                      <ol>
                        <li>Go to Settings > Email Settings.</li>
                        <li>Click on "Add Email Account".</li>
                        <li>Enter your email credentials (SMTP server, username, password, etc.).</li>
                        <li>Test the connection to ensure it works.</li>
                        <li>Configure email templates if needed.</li>
                        <li>Set up email tracking options.</li>
                        <li>Save your settings.</li>
                      </ol>
                      <p>We support integration with Gmail, Outlook, and most other email providers.</p>
                    </div>
                  </div>
                </div>
                <div className="accordion-item">
                  <h2 className="accordion-header" id="headingFive">
                    <button
                      className="accordion-button collapsed"
                      type="button"
                      data-bs-toggle="collapse"
                      data-bs-target="#collapseFive"
                      aria-expanded="false"
                      aria-controls="collapseFive"
                    >
                      How do I add a new user to the CRM?
                    </button>
                  </h2>
                  <div
                    id="collapseFive"
                    className="accordion-collapse collapse"
                    aria-labelledby="headingFive"
                    data-bs-parent="#faqAccordion"
                  >
                    <div className="accordion-body">
                      <p>To add a new user:</p>
                      <ol>
                        <li>Go to Settings > Users.</li>
                        <li>Click on "Add User".</li>
                        <li>Enter the user's name, email, and other required information.</li>
                        <li>Assign a role to the user (Administrator, Sales Rep, etc.).</li>
                        <li>Set permissions for the user.</li>
                        <li>Click "Save" to create the user account.</li>
                        <li>The user will receive an email with login instructions.</li>
                      </ol>
                      <p>Note that the number of users you can add depends on your subscription plan.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

