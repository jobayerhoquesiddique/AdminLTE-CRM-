"use client"

import type React from "react"

import { useState } from "react"
import { useCrm } from "@/lib/context/CrmContext"
import { LoadingSpinner } from "@/components/ui/loading-spinner"

// Add proper type definitions for campaigns
interface Campaign {
  id: string
  name: string
  type: string
  status: string
  startDate: string
  endDate: string
  budget: number
  spent: number
  leads: number
  conversions: number
  roi: number
  description: string
  assignedTo: string
}

export default function Campaigns() {
  const { state, dispatch, generateId } = useCrm()
  const { campaigns, isLoading } = state
  const [showAddModal, setShowAddModal] = useState(false)
  const [showEditModal, setShowEditModal] = useState(false)
  const [showDeleteModal, setShowDeleteModal] = useState(false)
  const [selectedCampaign, setSelectedCampaign] = useState<Campaign | null>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [filterType, setFilterType] = useState("All")
  const [filterStatus, setFilterStatus] = useState("All")
  const [newCampaign, setNewCampaign] = useState<Omit<Campaign, "id">>({
    name: "",
    type: "Email",
    status: "Planned",
    startDate: "",
    endDate: "",
    budget: 0,
    spent: 0,
    leads: 0,
    conversions: 0,
    roi: 0,
    description: "",
    assignedTo: "user1",
  })

  // Get unique types and statuses
  const types = ["All", ...new Set(campaigns.map((campaign) => campaign.type))]
  const statuses = ["All", ...new Set(campaigns.map((campaign) => campaign.status))]

  // Filter campaigns
  const filteredCampaigns = campaigns.filter((campaign) => {
    const matchesSearch =
      campaign.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      campaign.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesType = filterType === "All" || campaign.type === filterType
    const matchesStatus = filterStatus === "All" || campaign.status === filterStatus
    return matchesSearch && matchesType && matchesStatus
  })

  // Update the handleInputChange function to properly handle different input types
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target

    // Handle numeric inputs properly
    let parsedValue: string | number = value
    if (type === "number") {
      parsedValue = value === "" ? 0 : Number.parseFloat(value)
    }

    if (showEditModal && selectedCampaign) {
      setSelectedCampaign({
        ...selectedCampaign,
        [name]: parsedValue,
      })
    } else {
      setNewCampaign({
        ...newCampaign,
        [name]: parsedValue,
      })
    }
  }

  // Add error handling for form submissions
  const handleAddCampaign = (e: React.FormEvent) => {
    e.preventDefault()

    try {
      // Validate dates
      const startDate = new Date(newCampaign.startDate)
      const endDate = new Date(newCampaign.endDate)

      if (endDate < startDate) {
        alert("End date cannot be before start date")
        return
      }

      const campaign = {
        id: generateId(),
        ...newCampaign,
      }
      dispatch({ type: "ADD_CAMPAIGN", payload: campaign })
      setNewCampaign({
        name: "",
        type: "Email",
        status: "Planned",
        startDate: "",
        endDate: "",
        budget: 0,
        spent: 0,
        leads: 0,
        conversions: 0,
        roi: 0,
        description: "",
        assignedTo: "user1",
      })
      setShowAddModal(false)
    } catch (error) {
      console.error("Error adding campaign:", error)
      alert("There was an error adding the campaign. Please try again.")
    }
  }

  // Add error handling for edit form submissions
  const handleEditCampaign = (e: React.FormEvent) => {
    e.preventDefault()

    if (!selectedCampaign) return

    try {
      // Validate dates
      const startDate = new Date(selectedCampaign.startDate)
      const endDate = new Date(selectedCampaign.endDate)

      if (endDate < startDate) {
        alert("End date cannot be before start date")
        return
      }

      dispatch({ type: "UPDATE_CAMPAIGN", payload: selectedCampaign })
      setShowEditModal(false)
    } catch (error) {
      console.error("Error updating campaign:", error)
      alert("There was an error updating the campaign. Please try again.")
    }
  }

  const handleDeleteCampaign = () => {
    if (selectedCampaign) {
      dispatch({ type: "DELETE_CAMPAIGN", payload: selectedCampaign.id })
      setShowDeleteModal(false)
    }
  }

  if (isLoading) {
    return <LoadingSpinner />
  }

  return (
    <div className="row">
      <div className="col-12">
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Marketing Campaigns</h3>
            <div className="card-tools">
              <div className="input-group input-group-sm" style={{ width: "150px" }}>
                <input
                  type="text"
                  name="table_search"
                  className="form-control float-right"
                  placeholder="Search"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                <div className="input-group-append">
                  <button type="submit" className="btn btn-default">
                    <i className="bi bi-search"></i>
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div className="card-body">
            <div className="d-flex justify-content-between mb-3">
              <div>
                <button className="btn btn-primary me-2" onClick={() => setShowAddModal(true)}>
                  <i className="bi bi-plus-circle me-1"></i> Add Campaign
                </button>
                <div className="btn-group me-2">
                  <button type="button" className="btn btn-default dropdown-toggle" data-bs-toggle="dropdown">
                    Type: {filterType}
                  </button>
                  <ul className="dropdown-menu">
                    {types.map((type) => (
                      <li key={type}>
                        <a
                          className="dropdown-item"
                          href="#"
                          onClick={(e) => {
                            e.preventDefault()
                            setFilterType(type)
                          }}
                        >
                          {type}
                        </a>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="btn-group">
                  <button type="button" className="btn btn-default dropdown-toggle" data-bs-toggle="dropdown">
                    Status: {filterStatus}
                  </button>
                  <ul className="dropdown-menu">
                    {statuses.map((status) => (
                      <li key={status}>
                        <a
                          className="dropdown-item"
                          href="#"
                          onClick={(e) => {
                            e.preventDefault()
                            setFilterStatus(status)
                          }}
                        >
                          {status}
                        </a>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
              <div>
                <button className="btn btn-outline-success me-2">
                  <i className="bi bi-file-earmark-excel me-1"></i> Export
                </button>
                <button className="btn btn-outline-primary">
                  <i className="bi bi-printer me-1"></i> Print
                </button>
              </div>
            </div>

            <div className="table-responsive">
              <table className="table table-hover text-nowrap">
                <thead>
                  <tr>
                    <th>Campaign Name</th>
                    <th>Type</th>
                    <th>Status</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Budget</th>
                    <th>Spent</th>
                    <th>ROI</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredCampaigns.map((campaign) => (
                    <tr key={campaign.id}>
                      <td>{campaign.name}</td>
                      <td>{campaign.type}</td>
                      <td>
                        <span
                          className={`badge ${
                            campaign.status === "Active"
                              ? "bg-success"
                              : campaign.status === "Completed"
                                ? "bg-info"
                                : campaign.status === "Planned"
                                  ? "bg-warning"
                                  : "bg-secondary"
                          }`}
                        >
                          {campaign.status}
                        </span>
                      </td>
                      <td>{campaign.startDate}</td>
                      <td>{campaign.endDate}</td>
                      <td>${campaign.budget.toLocaleString()}</td>
                      <td>${campaign.spent.toLocaleString()}</td>
                      <td>{campaign.roi}%</td>
                      <td>
                        <button
                          className="btn btn-info btn-sm me-1"
                          onClick={() => {
                            setSelectedCampaign(campaign)
                            setShowEditModal(true)
                          }}
                        >
                          <i className="bi bi-eye"></i>
                        </button>
                        <button
                          className="btn btn-primary btn-sm me-1"
                          onClick={() => {
                            setSelectedCampaign(campaign)
                            setShowEditModal(true)
                          }}
                        >
                          <i className="bi bi-pencil"></i>
                        </button>
                        <button
                          className="btn btn-danger btn-sm"
                          onClick={() => {
                            setSelectedCampaign(campaign)
                            setShowDeleteModal(true)
                          }}
                        >
                          <i className="bi bi-trash"></i>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          <div className="card-footer clearfix">
            <ul className="pagination pagination-sm m-0 float-end">
              <li className="page-item">
                <a className="page-link" href="#">
                  «
                </a>
              </li>
              <li className="page-item">
                <a className="page-link" href="#">
                  1
                </a>
              </li>
              <li className="page-item">
                <a className="page-link" href="#">
                  2
                </a>
              </li>
              <li className="page-item">
                <a className="page-link" href="#">
                  3
                </a>
              </li>
              <li className="page-item">
                <a className="page-link" href="#">
                  »
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Add Campaign Modal */}
      {showAddModal && (
        <div className="modal fade show" style={{ display: "block", backgroundColor: "rgba(0,0,0,0.5)" }}>
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Add New Campaign</h5>
                <button type="button" className="btn-close" onClick={() => setShowAddModal(false)}></button>
              </div>
              <form onSubmit={handleAddCampaign}>
                <div className="modal-body">
                  <div className="row mb-3">
                    <div className="col-md-6">
                      <div className="form-group">
                        <label htmlFor="name">Campaign Name</label>
                        <input
                          type="text"
                          className="form-control"
                          id="name"
                          name="name"
                          value={newCampaign.name}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="form-group">
                        <label htmlFor="type">Campaign Type</label>
                        <select
                          className="form-control"
                          id="type"
                          name="type"
                          value={newCampaign.type}
                          onChange={handleInputChange}
                        >
                          <option value="Email">Email</option>
                          <option value="Social">Social Media</option>
                          <option value="PPC">Pay-Per-Click</option>
                          <option value="Event">Event</option>
                          <option value="Webinar">Webinar</option>
                          <option value="Content">Content Marketing</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col-md-4">
                      <div className="form-group">
                        <label htmlFor="status">Status</label>
                        <select
                          className="form-control"
                          id="status"
                          name="status"
                          value={newCampaign.status}
                          onChange={handleInputChange}
                        >
                          <option value="Planned">Planned</option>
                          <option value="Active">Active</option>
                          <option value="Completed">Completed</option>
                          <option value="Cancelled">Cancelled</option>
                        </select>
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="form-group">
                        <label htmlFor="startDate">Start Date</label>
                        <input
                          type="date"
                          className="form-control"
                          id="startDate"
                          name="startDate"
                          value={newCampaign.startDate}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="form-group">
                        <label htmlFor="endDate">End Date</label>
                        <input
                          type="date"
                          className="form-control"
                          id="endDate"
                          name="endDate"
                          value={newCampaign.endDate}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col-md-4">
                      <div className="form-group">
                        <label htmlFor="budget">Budget ($)</label>
                        <input
                          type="number"
                          className="form-control"
                          id="budget"
                          name="budget"
                          value={newCampaign.budget}
                          onChange={handleInputChange}
                          min="0"
                          required
                        />
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="form-group">
                        <label htmlFor="spent">Spent ($)</label>
                        <input
                          type="number"
                          className="form-control"
                          id="spent"
                          name="spent"
                          value={newCampaign.spent}
                          onChange={handleInputChange}
                          min="0"
                        />
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="form-group">
                        <label htmlFor="assignedTo">Assigned To</label>
                        <select
                          className="form-control"
                          id="assignedTo"
                          name="assignedTo"
                          value={newCampaign.assignedTo}
                          onChange={handleInputChange}
                        >
                          <option value="user1">John Doe</option>
                          <option value="user2">Sarah Johnson</option>
                          <option value="user3">Michael Brown</option>
                          <option value="user4">Emily Davis</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col-md-4">
                      <div className="form-group">
                        <label htmlFor="leads">Expected Leads</label>
                        <input
                          type="number"
                          className="form-control"
                          id="leads"
                          name="leads"
                          value={newCampaign.leads}
                          onChange={handleInputChange}
                          min="0"
                        />
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="form-group">
                        <label htmlFor="conversions">Expected Conversions</label>
                        <input
                          type="number"
                          className="form-control"
                          id="conversions"
                          name="conversions"
                          value={newCampaign.conversions}
                          onChange={handleInputChange}
                          min="0"
                        />
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="form-group">
                        <label htmlFor="roi">Expected ROI (%)</label>
                        <input
                          type="number"
                          className="form-control"
                          id="roi"
                          name="roi"
                          value={newCampaign.roi}
                          onChange={handleInputChange}
                          min="0"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-group mb-3">
                    <label htmlFor="description">Description</label>
                    <textarea
                      className="form-control"
                      id="description"
                      name="description"
                      rows={3}
                      value={newCampaign.description}
                      onChange={handleInputChange}
                    ></textarea>
                  </div>
                </div>
                <div className="modal-footer">
                  <button type="button" className="btn btn-secondary" onClick={() => setShowAddModal(false)}>
                    Cancel
                  </button>
                  <button type="submit" className="btn btn-primary">
                    Add Campaign
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Edit Campaign Modal */}
      {showEditModal && selectedCampaign && (
        <div className="modal fade show" style={{ display: "block", backgroundColor: "rgba(0,0,0,0.5)" }}>
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Edit Campaign: {selectedCampaign.name}</h5>
                <button type="button" className="btn-close" onClick={() => setShowEditModal(false)}></button>
              </div>
              <form onSubmit={handleEditCampaign}>
                <div className="modal-body">
                  {/* Same form fields as Add Campaign Modal, but with selectedCampaign values */}
                  <div className="row mb-3">
                    <div className="col-md-6">
                      <div className="form-group">
                        <label htmlFor="editName">Campaign Name</label>
                        <input
                          type="text"
                          className="form-control"
                          id="editName"
                          name="name"
                          value={selectedCampaign.name}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="form-group">
                        <label htmlFor="editType">Campaign Type</label>
                        <select
                          className="form-control"
                          id="editType"
                          name="type"
                          value={selectedCampaign.type}
                          onChange={handleInputChange}
                        >
                          <option value="Email">Email</option>
                          <option value="Social">Social Media</option>
                          <option value="PPC">Pay-Per-Click</option>
                          <option value="Event">Event</option>
                          <option value="Webinar">Webinar</option>
                          <option value="Content">Content Marketing</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col-md-4">
                      <div className="form-group">
                        <label htmlFor="editStatus">Status</label>
                        <select
                          className="form-control"
                          id="editStatus"
                          name="status"
                          value={selectedCampaign.status}
                          onChange={handleInputChange}
                        >
                          <option value="Planned">Planned</option>
                          <option value="Active">Active</option>
                          <option value="Completed">Completed</option>
                          <option value="Cancelled">Cancelled</option>
                        </select>
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="form-group">
                        <label htmlFor="editStartDate">Start Date</label>
                        <input
                          type="date"
                          className="form-control"
                          id="editStartDate"
                          name="startDate"
                          value={selectedCampaign.startDate}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="form-group">
                        <label htmlFor="editEndDate">End Date</label>
                        <input
                          type="date"
                          className="form-control"
                          id="editEndDate"
                          name="endDate"
                          value={selectedCampaign.endDate}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col-md-4">
                      <div className="form-group">
                        <label htmlFor="editBudget">Budget ($)</label>
                        <input
                          type="number"
                          className="form-control"
                          id="editBudget"
                          name="budget"
                          value={selectedCampaign.budget}
                          onChange={handleInputChange}
                          min="0"
                          required
                        />
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="form-group">
                        <label htmlFor="editSpent">Spent ($)</label>
                        <input
                          type="number"
                          className="form-control"
                          id="editSpent"
                          name="spent"
                          value={selectedCampaign.spent}
                          onChange={handleInputChange}
                          min="0"
                        />
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="form-group">
                        <label htmlFor="editAssignedTo">Assigned To</label>
                        <select
                          className="form-control"
                          id="editAssignedTo"
                          name="assignedTo"
                          value={selectedCampaign.assignedTo}
                          onChange={handleInputChange}
                        >
                          <option value="user1">John Doe</option>
                          <option value="user2">Sarah Johnson</option>
                          <option value="user3">Michael Brown</option>
                          <option value="user4">Emily Davis</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col-md-4">
                      <div className="form-group">
                        <label htmlFor="editLeads">Leads Generated</label>
                        <input
                          type="number"
                          className="form-control"
                          id="editLeads"
                          name="leads"
                          value={selectedCampaign.leads}
                          onChange={handleInputChange}
                          min="0"
                        />
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="form-group">
                        <label htmlFor="editConversions">Conversions</label>
                        <input
                          type="number"
                          className="form-control"
                          id="editConversions"
                          name="conversions"
                          value={selectedCampaign.conversions}
                          onChange={handleInputChange}
                          min="0"
                        />
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="form-group">
                        <label htmlFor="editRoi">ROI (%)</label>
                        <input
                          type="number"
                          className="form-control"
                          id="editRoi"
                          name="roi"
                          value={selectedCampaign.roi}
                          onChange={handleInputChange}
                          min="0"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-group mb-3">
                    <label htmlFor="editDescription">Description</label>
                    <textarea
                      className="form-control"
                      id="editDescription"
                      name="description"
                      rows={3}
                      value={selectedCampaign.description}
                      onChange={handleInputChange}
                    ></textarea>
                  </div>
                </div>
                <div className="modal-footer">
                  <button
                    type="button"
                    className="btn btn-danger me-auto"
                    onClick={() => {
                      setShowEditModal(false)
                      setShowDeleteModal(true)
                    }}
                  >
                    Delete
                  </button>
                  <button type="button" className="btn btn-secondary" onClick={() => setShowEditModal(false)}>
                    Cancel
                  </button>
                  <button type="submit" className="btn btn-primary">
                    Save Changes
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Delete Campaign Modal */}
      {showDeleteModal && selectedCampaign && (
        <div className="modal fade show" style={{ display: "block", backgroundColor: "rgba(0,0,0,0.5)" }}>
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Delete Campaign</h5>
                <button type="button" className="btn-close" onClick={() => setShowDeleteModal(false)}></button>
              </div>
              <div className="modal-body">
                <p>
                  Are you sure you want to delete the campaign <strong>{selectedCampaign.name}</strong>?
                </p>
                <p className="text-danger">This action cannot be undone.</p>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowDeleteModal(false)}>
                  Cancel
                </button>
                <button type="button" className="btn btn-danger" onClick={handleDeleteCampaign}>
                  Delete Campaign
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

