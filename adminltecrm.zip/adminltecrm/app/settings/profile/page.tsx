"use client"

import { useState } from "react"

export default function ProfileSettings() {
  const [activeTab, setActiveTab] = useState("profile")

  return (
    <div className="row">
      <div className="col-md-3">
        <div className="card card-primary card-outline">
          <div className="card-body box-profile">
            <div className="text-center">
              <img
                className="profile-user-img img-fluid img-circle"
                src="/images/profile.jpg"
                alt="User profile picture"
              />
            </div>
            <h3 className="profile-username text-center">Jobayer Hoque Siddique</h3>
            <p className="text-muted text-center">JHS CRM Administrator</p>

            <ul className="list-group list-group-unbordered mb-3">
              <li className="list-group-item">
                <b>Deals Closed</b> <a className="float-end">12</a>
              </li>
              <li className="list-group-item">
                <b>Tasks Completed</b> <a className="float-end">45</a>
              </li>
              <li className="list-group-item">
                <b>Customers</b> <a className="float-end">25</a>
              </li>
            </ul>

            <button className="btn btn-primary btn-block">
              <i className="bi bi-cloud-upload me-1"></i> Update Profile Picture
            </button>
          </div>
        </div>

        <div className="card">
          <div className="card-header">
            <h3 className="card-title">About Me</h3>
          </div>
          <div className="card-body">
            <strong>
              <i className="bi bi-briefcase me-1"></i> Position
            </strong>
            <p className="text-muted">JHS CRM Administrator</p>
            <hr />

            <strong>
              <i className="bi bi-building me-1"></i> Department
            </strong>
            <p className="text-muted">Management</p>
            <hr />

            <strong>
              <i className="bi bi-envelope me-1"></i> Email
            </strong>
            <p className="text-muted">jobayerhoquesiddique@gmail.com</p>
            <hr />

            <strong>
              <i className="bi bi-phone me-1"></i> Phone
            </strong>
            <p className="text-muted">01821784207</p>
          </div>
        </div>
      </div>

      <div className="col-md-9">
        <div className="card">
          <div className="card-header p-2">
            <ul className="nav nav-pills">
              <li className="nav-item">
                <a
                  className={`nav-link ${activeTab === "profile" ? "active" : ""}`}
                  href="#"
                  onClick={(e) => {
                    e.preventDefault()
                    setActiveTab("profile")
                  }}
                >
                  Edit Profile
                </a>
              </li>
              <li className="nav-item">
                <a
                  className={`nav-link ${activeTab === "settings" ? "active" : ""}`}
                  href="#"
                  onClick={(e) => {
                    e.preventDefault()
                    setActiveTab("settings")
                  }}
                >
                  Settings
                </a>
              </li>
              <li className="nav-item">
                <a
                  className={`nav-link ${activeTab === "security" ? "active" : ""}`}
                  href="#"
                  onClick={(e) => {
                    e.preventDefault()
                    setActiveTab("security")
                  }}
                >
                  Security
                </a>
              </li>
            </ul>
          </div>
          <div className="card-body">
            <div className="tab-content">
              {/* Profile Edit Tab */}
              <div className={`tab-pane ${activeTab === "profile" ? "active" : ""}`}>
                <form className="form-horizontal">
                  <div className="form-group row mb-3">
                    <label htmlFor="inputName" className="col-sm-2 col-form-label">
                      Name
                    </label>
                    <div className="col-sm-10">
                      <input
                        type="text"
                        className="form-control"
                        id="inputName"
                        placeholder="Name"
                        defaultValue="Jobayer Hoque Siddique"
                      />
                    </div>
                  </div>
                  <div className="form-group row mb-3">
                    <label htmlFor="inputEmail" className="col-sm-2 col-form-label">
                      Email
                    </label>
                    <div className="col-sm-10">
                      <input
                        type="email"
                        className="form-control"
                        id="inputEmail"
                        placeholder="Email"
                        defaultValue="jobayerhoquesiddique@gmail.com"
                      />
                    </div>
                  </div>
                  <div className="form-group row mb-3">
                    <label htmlFor="inputPhone" className="col-sm-2 col-form-label">
                      Phone
                    </label>
                    <div className="col-sm-10">
                      <input
                        type="text"
                        className="form-control"
                        id="inputPhone"
                        placeholder="Phone"
                        defaultValue="01821784207"
                      />
                    </div>
                  </div>
                  <div className="form-group row mb-3">
                    <label htmlFor="inputPosition" className="col-sm-2 col-form-label">
                      Position
                    </label>
                    <div className="col-sm-10">
                      <input
                        type="text"
                        className="form-control"
                        id="inputPosition"
                        placeholder="Position"
                        defaultValue="JHS CRM Administrator"
                      />
                    </div>
                  </div>
                  <div className="form-group row mb-3">
                    <label htmlFor="inputDepartment" className="col-sm-2 col-form-label">
                      Department
                    </label>
                    <div className="col-sm-10">
                      <select className="form-control" id="inputDepartment" defaultValue="Management">
                        <option>Management</option>
                        <option>Sales</option>
                        <option>Marketing</option>
                        <option>Customer Support</option>
                        <option>IT</option>
                        <option>Administration</option>
                      </select>
                    </div>
                  </div>
                  <div className="form-group row mb-3">
                    <label htmlFor="inputBio" className="col-sm-2 col-form-label">
                      Bio
                    </label>
                    <div className="col-sm-10">
                      <textarea
                        className="form-control"
                        id="inputBio"
                        placeholder="Bio"
                        rows={3}
                        defaultValue="JHS professional with extensive experience in CRM administration and customer relationship management."
                      ></textarea>
                    </div>
                  </div>
                  <div className="form-group row">
                    <div className="offset-sm-2 col-sm-10">
                      <button type="submit" className="btn btn-primary">
                        Save Changes
                      </button>
                    </div>
                  </div>
                </form>
              </div>

              {/* Settings Tab */}
              <div className={`tab-pane ${activeTab === "settings" ? "active" : ""}`}>
                <form className="form-horizontal">
                  <div className="form-group row mb-3">
                    <label className="col-sm-2 col-form-label">Notifications</label>
                    <div className="col-sm-10">
                      <div className="form-check mb-2">
                        <input className="form-check-input" type="checkbox" id="emailNotifications" defaultChecked />
                        <label className="form-check-label" htmlFor="emailNotifications">
                          Email Notifications
                        </label>
                      </div>
                      <div className="form-check mb-2">
                        <input className="form-check-input" type="checkbox" id="smsNotifications" />
                        <label className="form-check-label" htmlFor="smsNotifications">
                          SMS Notifications
                        </label>
                      </div>
                      <div className="form-check mb-2">
                        <input className="form-check-input" type="checkbox" id="browserNotifications" defaultChecked />
                        <label className="form-check-label" htmlFor="browserNotifications">
                          Browser Notifications
                        </label>
                      </div>
                    </div>
                  </div>
                  <div className="form-group row mb-3">
                    <label className="col-sm-2 col-form-label">Email Preferences</label>
                    <div className="col-sm-10">
                      <div className="form-check mb-2">
                        <input className="form-check-input" type="checkbox" id="dealUpdates" defaultChecked />
                        <label className="form-check-label" htmlFor="dealUpdates">
                          Deal Updates
                        </label>
                      </div>
                      <div className="form-check mb-2">
                        <input className="form-check-input" type="checkbox" id="taskReminders" defaultChecked />
                        <label className="form-check-label" htmlFor="taskReminders">
                          Task Reminders
                        </label>
                      </div>
                      <div className="form-check mb-2">
                        <input className="form-check-input" type="checkbox" id="leadAlerts" defaultChecked />
                        <label className="form-check-label" htmlFor="leadAlerts">
                          New Lead Alerts
                        </label>
                      </div>
                      <div className="form-check mb-2">
                        <input className="form-check-input" type="checkbox" id="marketingEmails" />
                        <label className="form-check-label" htmlFor="marketingEmails">
                          Marketing Emails
                        </label>
                      </div>
                    </div>
                  </div>
                  <div className="form-group row mb-3">
                    <label htmlFor="language" className="col-sm-2 col-form-label">
                      Language
                    </label>
                    <div className="col-sm-10">
                      <select className="form-control" id="language" defaultValue="English">
                        <option>English</option>
                        <option>Bengali</option>
                        <option>Spanish</option>
                        <option>French</option>
                        <option>German</option>
                        <option>Chinese</option>
                      </select>
                    </div>
                  </div>
                  <div className="form-group row mb-3">
                    <label htmlFor="timezone" className="col-sm-2 col-form-label">
                      Timezone
                    </label>
                    <div className="col-sm-10">
                      <select className="form-control" id="timezone" defaultValue="(GMT+06:00) Bangladesh Time">
                        <option>(GMT+06:00) Bangladesh Time</option>
                        <option>(GMT-08:00) Pacific Time</option>
                        <option>(GMT-07:00) Mountain Time</option>
                        <option>(GMT-06:00) Central Time</option>
                        <option>(GMT-05:00) Eastern Time</option>
                        <option>(GMT) Greenwich Mean Time</option>
                        <option>(GMT+01:00) Central European Time</option>
                      </select>
                    </div>
                  </div>
                  <div className="form-group row">
                    <div className="offset-sm-2 col-sm-10">
                      <button type="submit" className="btn btn-primary">
                        Save Preferences
                      </button>
                    </div>
                  </div>
                </form>
              </div>

              {/* Security Tab */}
              <div className={`tab-pane ${activeTab === "security" ? "active" : ""}`}>
                <form className="form-horizontal">
                  <div className="form-group row mb-3">
                    <label htmlFor="currentPassword" className="col-sm-3 col-form-label">
                      Current Password
                    </label>
                    <div className="col-sm-9">
                      <input
                        type="password"
                        className="form-control"
                        id="currentPassword"
                        placeholder="Current Password"
                      />
                    </div>
                  </div>
                  <div className="form-group row mb-3">
                    <label htmlFor="newPassword" className="col-sm-3 col-form-label">
                      New Password
                    </label>
                    <div className="col-sm-9">
                      <input type="password" className="form-control" id="newPassword" placeholder="New Password" />
                    </div>
                  </div>
                  <div className="form-group row mb-3">
                    <label htmlFor="confirmPassword" className="col-sm-3 col-form-label">
                      Confirm New Password
                    </label>
                    <div className="col-sm-9">
                      <input
                        type="password"
                        className="form-control"
                        id="confirmPassword"
                        placeholder="Confirm New Password"
                      />
                    </div>
                  </div>
                  <div className="form-group row mb-4">
                    <div className="offset-sm-3 col-sm-9">
                      <button type="submit" className="btn btn-primary">
                        Change Password
                      </button>
                    </div>
                  </div>

                  <hr />

                  <h5 className="mt-4 mb-3">Two-Factor Authentication</h5>
                  <div className="form-group row mb-3">
                    <div className="col-sm-9 offset-sm-3">
                      <div className="form-check">
                        <input className="form-check-input" type="checkbox" id="twoFactorAuth" />
                        <label className="form-check-label" htmlFor="twoFactorAuth">
                          Enable Two-Factor Authentication
                        </label>
                      </div>
                      <small className="form-text text-muted">
                        Two-factor authentication adds an additional layer of security to your account by requiring more
                        than just a password to sign in.
                      </small>
                    </div>
                  </div>
                  <div className="form-group row mb-3">
                    <div className="offset-sm-3 col-sm-9">
                      <button type="button" className="btn btn-outline-primary" disabled>
                        Set Up Two-Factor Authentication
                      </button>
                    </div>
                  </div>

                  <hr />

                  <h5 className="mt-4 mb-3">Sessions</h5>
                  <div className="table-responsive">
                    <table className="table table-bordered">
                      <thead>
                        <tr>
                          <th>Device</th>
                          <th>Location</th>
                          <th>IP Address</th>
                          <th>Last Activity</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>
                            <i className="bi bi-laptop me-1"></i> Windows PC - Chrome
                          </td>
                          <td>Dhaka, Bangladesh</td>
                          <td>192.168.1.1</td>
                          <td>Current session</td>
                          <td>
                            <span className="badge bg-success">Current</span>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <i className="bi bi-phone me-1"></i> iPhone - Safari
                          </td>
                          <td>Dhaka, Bangladesh</td>
                          <td>192.168.1.2</td>
                          <td>2 days ago</td>
                          <td>
                            <button className="btn btn-danger btn-sm">Revoke</button>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <i className="bi bi-tablet me-1"></i> iPad - Safari
                          </td>
                          <td>Chittagong, Bangladesh</td>
                          <td>192.168.1.3</td>
                          <td>5 days ago</td>
                          <td>
                            <button className="btn btn-danger btn-sm">Revoke</button>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                  <div className="form-group row">
                    <div className="col-sm-12">
                      <button type="button" className="btn btn-warning">
                        Sign Out All Other Sessions
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

