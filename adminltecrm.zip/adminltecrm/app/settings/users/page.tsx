"use client"

import { useState } from "react"

export default function UsersSettings() {
  const [showAddUserModal, setShowAddUserModal] = useState(false)
  const [showEditUserModal, setShowEditUserModal] = useState(false)
  const [showDeleteUserModal, setShowDeleteUserModal] = useState(false)
  const [selectedUser, setSelectedUser] = useState<any>(null)

  const users = [
    {
      id: 1,
      name: "John Doe",
      email: "john.doe@example.com",
      role: "Administrator",
      department: "Sales",
      status: "Active",
      lastLogin: "Today, 10:30 AM",
      avatar: "/placeholder.svg?height=128&width=128",
    },
    {
      id: 2,
      name: "Sarah Johnson",
      email: "sarah.johnson@example.com",
      role: "Sales Manager",
      department: "Sales",
      status: "Active",
      lastLogin: "Yesterday, 3:15 PM",
      avatar: "/placeholder.svg?height=128&width=128",
    },
    {
      id: 3,
      name: "Michael Brown",
      email: "michael.brown@example.com",
      role: "Sales Representative",
      department: "Sales",
      status: "Active",
      lastLogin: "Mar 15, 2023, 9:20 AM",
      avatar: "/placeholder.svg?height=128&width=128",
    },
    {
      id: 4,
      name: "Emily Davis",
      email: "emily.davis@example.com",
      role: "Marketing Specialist",
      department: "Marketing",
      status: "Active",
      lastLogin: "Mar 14, 2023, 2:45 PM",
      avatar: "/placeholder.svg?height=128&width=128",
    },
    {
      id: 5,
      name: "Robert Wilson",
      email: "robert.wilson@example.com",
      role: "Support Specialist",
      department: "Customer Support",
      status: "Inactive",
      lastLogin: "Feb 28, 2023, 11:10 AM",
      avatar: "/placeholder.svg?height=128&width=128",
    },
  ]

  const handleEditUser = (user: any) => {
    setSelectedUser(user)
    setShowEditUserModal(true)
  }

  const handleDeleteUser = (user: any) => {
    setSelectedUser(user)
    setShowDeleteUserModal(true)
  }

  return (
    <div className="row">
      <div className="col-12">
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">User Management</h3>
            <div className="card-tools">
              <div className="input-group input-group-sm" style={{ width: "150px" }}>
                <input type="text" name="table_search" className="form-control float-right" placeholder="Search" />
                <div className="input-group-append">
                  <button type="submit" className="btn btn-default">
                    <i className="bi bi-search"></i>
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div className="card-body">
            <div className="d-flex justify-content-between mb-3">
              <div>
                <button className="btn btn-primary me-2" onClick={() => setShowAddUserModal(true)}>
                  <i className="bi bi-person-plus-fill me-1"></i> Add User
                </button>
                <button className="btn btn-outline-secondary me-2">
                  <i className="bi bi-filter me-1"></i> Filter
                </button>
                <div className="btn-group">
                  <button type="button" className="btn btn-outline-secondary">
                    <i className="bi bi-sort-down me-1"></i> Sort
                  </button>
                  <button
                    type="button"
                    className="btn btn-outline-secondary dropdown-toggle dropdown-toggle-split"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                  >
                    <span className="visually-hidden">Toggle Dropdown</span>
                  </button>
                  <ul className="dropdown-menu">
                    <li>
                      <a className="dropdown-item" href="#">
                        Name (A-Z)
                      </a>
                    </li>
                    <li>
                      <a className="dropdown-item" href="#">
                        Name (Z-A)
                      </a>
                    </li>
                    <li>
                      <a className="dropdown-item" href="#">
                        Role
                      </a>
                    </li>
                    <li>
                      <a className="dropdown-item" href="#">
                        Department
                      </a>
                    </li>
                    <li>
                      <a className="dropdown-item" href="#">
                        Last Login
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
              <div>
                <button className="btn btn-outline-success me-2">
                  <i className="bi bi-file-earmark-excel me-1"></i> Export
                </button>
                <button className="btn btn-outline-primary">
                  <i className="bi bi-printer me-1"></i> Print
                </button>
              </div>
            </div>

            <div className="table-responsive">
              <table className="table table-bordered table-hover">
                <thead>
                  <tr>
                    <th style={{ width: "40px" }}>
                      <div className="form-check">
                        <input className="form-check-input" type="checkbox" />
                      </div>
                    </th>
                    <th>User</th>
                    <th>Role</th>
                    <th>Department</th>
                    <th>Status</th>
                    <th>Last Login</th>
                    <th style={{ width: "150px" }}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((user) => (
                    <tr key={user.id}>
                      <td>
                        <div className="form-check">
                          <input className="form-check-input" type="checkbox" />
                        </div>
                      </td>
                      <td>
                        <div className="d-flex align-items-center">
                          <img
                            src={user.avatar || "/placeholder.svg"}
                            alt={user.name}
                            className="img-circle me-2"
                            style={{ width: "40px", height: "40px" }}
                          />
                          <div>
                            <div className="fw-bold">{user.name}</div>
                            <div className="text-muted small">{user.email}</div>
                          </div>
                        </div>
                      </td>
                      <td>{user.role}</td>
                      <td>{user.department}</td>
                      <td>
                        <span className={`badge ${user.status === "Active" ? "bg-success" : "bg-secondary"}`}>
                          {user.status}
                        </span>
                      </td>
                      <td>{user.lastLogin}</td>
                      <td>
                        <button
                          className="btn btn-info btn-sm me-1"
                          title="View User"
                          onClick={() => handleEditUser(user)}
                        >
                          <i className="bi bi-eye"></i>
                        </button>
                        <button
                          className="btn btn-primary btn-sm me-1"
                          title="Edit User"
                          onClick={() => handleEditUser(user)}
                        >
                          <i className="bi bi-pencil"></i>
                        </button>
                        <button
                          className="btn btn-danger btn-sm"
                          title="Delete User"
                          onClick={() => handleDeleteUser(user)}
                        >
                          <i className="bi bi-trash"></i>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          <div className="card-footer clearfix">
            <ul className="pagination pagination-sm m-0 float-end">
              <li className="page-item">
                <a className="page-link" href="#">
                  «
                </a>
              </li>
              <li className="page-item">
                <a className="page-link" href="#">
                  1
                </a>
              </li>
              <li className="page-item">
                <a className="page-link" href="#">
                  2
                </a>
              </li>
              <li className="page-item">
                <a className="page-link" href="#">
                  3
                </a>
              </li>
              <li className="page-item">
                <a className="page-link" href="#">
                  »
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="row">
          <div className="col-md-6">
            <div className="card">
              <div className="card-header">
                <h3 className="card-title">User Roles</h3>
                <div className="card-tools">
                  <button type="button" className="btn btn-tool" data-lte-toggle="card-collapse">
                    <i className="bi bi-minus"></i>
                  </button>
                </div>
              </div>
              <div className="card-body p-0">
                <table className="table table-striped">
                  <thead>
                    <tr>
                      <th>Role</th>
                      <th>Description</th>
                      <th style={{ width: "100px" }}>Users</th>
                      <th style={{ width: "100px" }}>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Administrator</td>
                      <td>Full system access and control</td>
                      <td>
                        <span className="badge bg-primary">1</span>
                      </td>
                      <td>
                        <button className="btn btn-primary btn-sm me-1">
                          <i className="bi bi-pencil"></i>
                        </button>
                        <button className="btn btn-info btn-sm">
                          <i className="bi bi-eye"></i>
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>Sales Manager</td>
                      <td>Manage sales team and view all sales data</td>
                      <td>
                        <span className="badge bg-primary">1</span>
                      </td>
                      <td>
                        <button className="btn btn-primary btn-sm me-1">
                          <i className="bi bi-pencil"></i>
                        </button>
                        <button className="btn btn-info btn-sm">
                          <i className="bi bi-eye"></i>
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>Sales Representative</td>
                      <td>Manage own customers, leads, and deals</td>
                      <td>
                        <span className="badge bg-primary">1</span>
                      </td>
                      <td>
                        <button className="btn btn-primary btn-sm me-1">
                          <i className="bi bi-pencil"></i>
                        </button>
                        <button className="btn btn-info btn-sm">
                          <i className="bi bi-eye"></i>
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>Marketing Specialist</td>
                      <td>Manage marketing campaigns and leads</td>
                      <td>
                        <span className="badge bg-primary">1</span>
                      </td>
                      <td>
                        <button className="btn btn-primary btn-sm me-1">
                          <i className="bi bi-pencil"></i>
                        </button>
                        <button className="btn btn-info btn-sm">
                          <i className="bi bi-eye"></i>
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>Support Specialist</td>
                      <td>Manage customer support tickets</td>
                      <td>
                        <span className="badge bg-primary">1</span>
                      </td>
                      <td>
                        <button className="btn btn-primary btn-sm me-1">
                          <i className="bi bi-pencil"></i>
                        </button>
                        <button className="btn btn-info btn-sm">
                          <i className="bi bi-eye"></i>
                        </button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div className="card-footer">
                <button className="btn btn-primary btn-sm">
                  <i className="bi bi-plus"></i> Add Role
                </button>
              </div>
            </div>
          </div>

          <div className="col-md-6">
            <div className="card">
              <div className="card-header">
                <h3 className="card-title">Departments</h3>
                <div className="card-tools">
                  <button type="button" className="btn btn-tool" data-lte-toggle="card-collapse">
                    <i className="bi bi-minus"></i>
                  </button>
                </div>
              </div>
              <div className="card-body p-0">
                <table className="table table-striped">
                  <thead>
                    <tr>
                      <th>Department</th>
                      <th>Description</th>
                      <th style={{ width: "100px" }}>Users</th>
                      <th style={{ width: "100px" }}>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Sales</td>
                      <td>Sales and business development</td>
                      <td>
                        <span className="badge bg-primary">3</span>
                      </td>
                      <td>
                        <button className="btn btn-primary btn-sm me-1">
                          <i className="bi bi-pencil"></i>
                        </button>
                        <button className="btn btn-info btn-sm">
                          <i className="bi bi-eye"></i>
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>Marketing</td>
                      <td>Marketing and lead generation</td>
                      <td>
                        <span className="badge bg-primary">1</span>
                      </td>
                      <td>
                        <button className="btn btn-primary btn-sm me-1">
                          <i className="bi bi-pencil"></i>
                        </button>
                        <button className="btn btn-info btn-sm">
                          <i className="bi bi-eye"></i>
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>Customer Support</td>
                      <td>Customer service and support</td>
                      <td>
                        <span className="badge bg-primary">1</span>
                      </td>
                      <td>
                        <button className="btn btn-primary btn-sm me-1">
                          <i className="bi bi-pencil"></i>
                        </button>
                        <button className="btn btn-info btn-sm">
                          <i className="bi bi-eye"></i>
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>IT</td>
                      <td>Information technology and systems</td>
                      <td>
                        <span className="badge bg-primary">0</span>
                      </td>
                      <td>
                        <button className="btn btn-primary btn-sm me-1">
                          <i className="bi bi-pencil"></i>
                        </button>
                        <button className="btn btn-info btn-sm">
                          <i className="bi bi-eye"></i>
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>Administration</td>
                      <td>Administrative and management</td>
                      <td>
                        <span className="badge bg-primary">0</span>
                      </td>
                      <td>
                        <button className="btn btn-primary btn-sm me-1">
                          <i className="bi bi-pencil"></i>
                        </button>
                        <button className="btn btn-info btn-sm">
                          <i className="bi bi-eye"></i>
                        </button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div className="card-footer">
                <button className="btn btn-primary btn-sm">
                  <i className="bi bi-plus"></i> Add Department
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Add User Modal */}
      {showAddUserModal && (
        <div className="modal fade show" style={{ display: "block", backgroundColor: "rgba(0,0,0,0.5)" }}>
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Add New User</h5>
                <button type="button" className="btn-close" onClick={() => setShowAddUserModal(false)}></button>
              </div>
              <div className="modal-body">
                <form>
                  <div className="row mb-3">
                    <div className="col-md-6">
                      <label htmlFor="firstName" className="form-label">
                        First Name
                      </label>
                      <input type="text" className="form-control" id="firstName" />
                    </div>
                    <div className="col-md-6">
                      <label htmlFor="lastName" className="form-label">
                        Last Name
                      </label>
                      <input type="text" className="form-control" id="lastName" />
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col-md-6">
                      <label htmlFor="email" className="form-label">
                        Email
                      </label>
                      <input type="email" className="form-control" id="email" />
                    </div>
                    <div className="col-md-6">
                      <label htmlFor="phone" className="form-label">
                        Phone
                      </label>
                      <input type="text" className="form-control" id="phone" />
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col-md-6">
                      <label htmlFor="role" className="form-label">
                        Role
                      </label>
                      <select className="form-control" id="role">
                        <option>Administrator</option>
                        <option>Sales Manager</option>
                        <option>Sales Representative</option>
                        <option>Marketing Specialist</option>
                        <option>Support Specialist</option>
                      </select>
                    </div>
                    <div className="col-md-6">
                      <label htmlFor="department" className="form-label">
                        Department
                      </label>
                      <select className="form-control" id="department">
                        <option>Sales</option>
                        <option>Marketing</option>
                        <option>Customer Support</option>
                        <option>IT</option>
                        <option>Administration</option>
                      </select>
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col-md-6">
                      <label htmlFor="password" className="form-label">
                        Password
                      </label>
                      <input type="password" className="form-control" id="password" />
                    </div>
                    <div className="col-md-6">
                      <label htmlFor="confirmPassword" className="form-label">
                        Confirm Password
                      </label>
                      <input type="password" className="form-control" id="confirmPassword" />
                    </div>
                  </div>
                  <div className="mb-3">
                    <div className="form-check">
                      <input className="form-check-input" type="checkbox" id="sendWelcomeEmail" checked />
                      <label className="form-check-label" htmlFor="sendWelcomeEmail">
                        Send welcome email with login instructions
                      </label>
                    </div>
                  </div>
                </form>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowAddUserModal(false)}>
                  Cancel
                </button>
                <button type="button" className="btn btn-primary">
                  Add User
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit User Modal */}
      {showEditUserModal && selectedUser && (
        <div className="modal fade show" style={{ display: "block", backgroundColor: "rgba(0,0,0,0.5)" }}>
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Edit User: {selectedUser.name}</h5>
                <button type="button" className="btn-close" onClick={() => setShowEditUserModal(false)}></button>
              </div>
              <div className="modal-body">
                <form>
                  <div className="row mb-3">
                    <div className="col-md-6">
                      <label htmlFor="editFirstName" className="form-label">
                        First Name
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        id="editFirstName"
                        defaultValue={selectedUser.name.split(" ")[0]}
                      />
                    </div>
                    <div className="col-md-6">
                      <label htmlFor="editLastName" className="form-label">
                        Last Name
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        id="editLastName"
                        defaultValue={selectedUser.name.split(" ")[1]}
                      />
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col-md-6">
                      <label htmlFor="editEmail" className="form-label">
                        Email
                      </label>
                      <input type="email" className="form-control" id="editEmail" defaultValue={selectedUser.email} />
                    </div>
                    <div className="col-md-6">
                      <label htmlFor="editPhone" className="form-label">
                        Phone
                      </label>
                      <input type="text" className="form-control" id="editPhone" defaultValue="(123) 456-7890" />
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col-md-6">
                      <label htmlFor="editRole" className="form-label">
                        Role
                      </label>
                      <select className="form-control" id="editRole" defaultValue={selectedUser.role}>
                        <option>Administrator</option>
                        <option>Sales Manager</option>
                        <option>Sales Representative</option>
                        <option>Marketing Specialist</option>
                        <option>Support Specialist</option>
                      </select>
                    </div>
                    <div className="col-md-6">
                      <label htmlFor="editDepartment" className="form-label">
                        Department
                      </label>
                      <select className="form-control" id="editDepartment" defaultValue={selectedUser.department}>
                        <option>Sales</option>
                        <option>Marketing</option>
                        <option>Customer Support</option>
                        <option>IT</option>
                        <option>Administration</option>
                      </select>
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col-md-6">
                      <label htmlFor="editStatus" className="form-label">
                        Status
                      </label>
                      <select className="form-control" id="editStatus" defaultValue={selectedUser.status}>
                        <option>Active</option>
                        <option>Inactive</option>
                      </select>
                    </div>
                  </div>
                </form>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowEditUserModal(false)}>
                  Cancel
                </button>
                <button type="button" className="btn btn-primary">
                  Save Changes
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete User Modal */}
      {showDeleteUserModal && selectedUser && (
        <div className="modal fade show" style={{ display: "block", backgroundColor: "rgba(0,0,0,0.5)" }}>
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Delete User</h5>
                <button type="button" className="btn-close" onClick={() => setShowDeleteUserModal(false)}></button>
              </div>
              <div className="modal-body">
                <p>
                  Are you sure you want to delete the user <strong>{selectedUser.name}</strong>?
                </p>
                <p className="text-danger">This action cannot be undone.</p>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowDeleteUserModal(false)}>
                  Cancel
                </button>
                <button type="button" className="btn btn-danger">
                  Delete User
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

