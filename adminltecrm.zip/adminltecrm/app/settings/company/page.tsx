"use client"

import { useState } from "react"

export default function CompanySettings() {
  const [activeTab, setActiveTab] = useState("general")

  return (
    <div className="row">
      <div className="col-md-3">
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Settings</h3>
          </div>
          <div className="card-body p-0">
            <ul className="nav nav-pills flex-column">
              <li className="nav-item">
                <a
                  className={`nav-link ${activeTab === "general" ? "active" : ""}`}
                  href="#"
                  onClick={(e) => {
                    e.preventDefault()
                    setActiveTab("general")
                  }}
                >
                  <i className="bi bi-gear me-2"></i> General
                </a>
              </li>
              <li className="nav-item">
                <a
                  className={`nav-link ${activeTab === "branding" ? "active" : ""}`}
                  href="#"
                  onClick={(e) => {
                    e.preventDefault()
                    setActiveTab("branding")
                  }}
                >
                  <i className="bi bi-palette me-2"></i> Branding
                </a>
              </li>
              <li className="nav-item">
                <a
                  className={`nav-link ${activeTab === "localization" ? "active" : ""}`}
                  href="#"
                  onClick={(e) => {
                    e.preventDefault()
                    setActiveTab("localization")
                  }}
                >
                  <i className="bi bi-globe me-2"></i> Localization
                </a>
              </li>
              <li className="nav-item">
                <a
                  className={`nav-link ${activeTab === "email" ? "active" : ""}`}
                  href="#"
                  onClick={(e) => {
                    e.preventDefault()
                    setActiveTab("email")
                  }}
                >
                  <i className="bi bi-envelope me-2"></i> Email
                </a>
              </li>
              <li className="nav-item">
                <a
                  className={`nav-link ${activeTab === "security" ? "active" : ""}`}
                  href="#"
                  onClick={(e) => {
                    e.preventDefault()
                    setActiveTab("security")
                  }}
                >
                  <i className="bi bi-shield-lock me-2"></i> Security
                </a>
              </li>
              <li className="nav-item">
                <a
                  className={`nav-link ${activeTab === "billing" ? "active" : ""}`}
                  href="#"
                  onClick={(e) => {
                    e.preventDefault()
                    setActiveTab("billing")
                  }}
                >
                  <i className="bi bi-credit-card me-2"></i> Billing
                </a>
              </li>
              <li className="nav-item">
                <a
                  className={`nav-link ${activeTab === "integrations" ? "active" : ""}`}
                  href="#"
                  onClick={(e) => {
                    e.preventDefault()
                    setActiveTab("integrations")
                  }}
                >
                  <i className="bi bi-puzzle me-2"></i> Integrations
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div className="col-md-9">
        {/* General Settings */}
        {activeTab === "general" && (
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">General Settings</h3>
            </div>
            <div className="card-body">
              <form>
                <div className="form-group mb-3">
                  <label htmlFor="companyName">Company Name</label>
                  <input
                    type="text"
                    className="form-control"
                    id="companyName"
                    placeholder="Enter company name"
                    defaultValue="Acme Corporation"
                  />
                </div>
                <div className="form-group mb-3">
                  <label htmlFor="companyWebsite">Company Website</label>
                  <input
                    type="text"
                    className="form-control"
                    id="companyWebsite"
                    placeholder="Enter company website"
                    defaultValue="https://www.acmecorp.com"
                  />
                </div>
                <div className="form-group mb-3">
                  <label htmlFor="companyAddress">Company Address</label>
                  <textarea
                    className="form-control"
                    id="companyAddress"
                    rows={3}
                    placeholder="Enter company address"
                    defaultValue="123 Main Street, Suite 100, Anytown, CA 12345, USA"
                  ></textarea>
                </div>
                <div className="row mb-3">
                  <div className="col-md-6">
                    <div className="form-group">
                      <label htmlFor="companyPhone">Phone Number</label>
                      <input
                        type="text"
                        className="form-control"
                        id="companyPhone"
                        placeholder="Enter phone number"
                        defaultValue="(123) 456-7890"
                      />
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="form-group">
                      <label htmlFor="companyEmail">Email Address</label>
                      <input
                        type="email"
                        className="form-control"
                        id="companyEmail"
                        placeholder="Enter email address"
                        defaultValue="info@acmecorp.com"
                      />
                    </div>
                  </div>
                </div>
                <div className="form-group mb-3">
                  <label htmlFor="taxId">Tax ID / VAT Number</label>
                  <input
                    type="text"
                    className="form-control"
                    id="taxId"
                    placeholder="Enter tax ID or VAT number"
                    defaultValue="US123456789"
                  />
                </div>
                <div className="form-group mb-3">
                  <label htmlFor="fiscalYear">Fiscal Year Start</label>
                  <select className="form-control" id="fiscalYear">
                    <option>January</option>
                    <option>February</option>
                    <option>March</option>
                    <option>April</option>
                    <option>May</option>
                    <option>June</option>
                    <option>July</option>
                    <option selected>August</option>
                    <option>September</option>
                    <option>October</option>
                    <option>November</option>
                    <option>December</option>
                  </select>
                </div>
                <button type="submit" className="btn btn-primary">
                  Save Changes
                </button>
              </form>
            </div>
          </div>
        )}

        {/* Branding Settings */}
        {activeTab === "branding" && (
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">Branding Settings</h3>
            </div>
            <div className="card-body">
              <form>
                <div className="row mb-4">
                  <div className="col-md-6">
                    <div className="form-group">
                      <label>Company Logo</label>
                      <div className="mt-2 mb-3">
                        <img
                          src="/placeholder.svg?height=100&width=200"
                          alt="Company Logo"
                          className="img-fluid mb-2"
                          style={{ maxHeight: "100px" }}
                        />
                      </div>
                      <div className="input-group">
                        <input type="file" className="form-control" id="companyLogo" />
                        <button className="btn btn-outline-secondary" type="button">
                          Upload
                        </button>
                      </div>
                      <small className="form-text text-muted">
                        Recommended size: 200x100 pixels. Max file size: 2MB.
                      </small>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="form-group">
                      <label>Favicon</label>
                      <div className="mt-2 mb-3">
                        <img
                          src="/placeholder.svg?height=32&width=32"
                          alt="Favicon"
                          className="img-fluid mb-2"
                          style={{ maxHeight: "32px" }}
                        />
                      </div>
                      <div className="input-group">
                        <input type="file" className="form-control" id="favicon" />
                        <button className="btn btn-outline-secondary" type="button">
                          Upload
                        </button>
                      </div>
                      <small className="form-text text-muted">
                        Recommended size: 32x32 pixels. Max file size: 1MB.
                      </small>
                    </div>
                  </div>
                </div>

                <div className="form-group mb-3">
                  <label>Primary Color</label>
                  <div className="input-group">
                    <span className="input-group-text">
                      <div
                        style={{
                          width: "20px",
                          height: "20px",
                          backgroundColor: "#0d6efd",
                          borderRadius: "3px",
                        }}
                      ></div>
                    </span>
                    <input type="text" className="form-control" defaultValue="#0d6efd" />
                    <button className="btn btn-outline-secondary" type="button">
                      Choose
                    </button>
                  </div>
                </div>

                <div className="form-group mb-3">
                  <label>Secondary Color</label>
                  <div className="input-group">
                    <span className="input-group-text">
                      <div
                        style={{
                          width: "20px",
                          height: "20px",
                          backgroundColor: "#6c757d",
                          borderRadius: "3px",
                        }}
                      ></div>
                    </span>
                    <input type="text" className="form-control" defaultValue="#6c757d" />
                    <button className="btn btn-outline-secondary" type="button">
                      Choose
                    </button>
                  </div>
                </div>

                <div className="form-group mb-3">
                  <label htmlFor="emailSignature">Email Signature</label>
                  <textarea
                    className="form-control"
                    id="emailSignature"
                    rows={4}
                    defaultValue={`Best regards,\n\nThe Acme Corporation Team\nwww.acmecorp.com | (123) 456-7890`}
                  ></textarea>
                </div>

                <button type="submit" className="btn btn-primary">
                  Save Changes
                </button>
              </form>
            </div>
          </div>
        )}

        {/* Localization Settings */}
        {activeTab === "localization" && (
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">Localization Settings</h3>
            </div>
            <div className="card-body">
              <form>
                <div className="row mb-3">
                  <div className="col-md-6">
                    <div className="form-group">
                      <label htmlFor="defaultLanguage">Default Language</label>
                      <select className="form-control" id="defaultLanguage">
                        <option selected>English (United States)</option>
                        <option>English (United Kingdom)</option>
                        <option>Spanish</option>
                        <option>French</option>
                        <option>German</option>
                        <option>Chinese (Simplified)</option>
                        <option>Japanese</option>
                      </select>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="form-group">
                      <label htmlFor="defaultTimezone">Default Timezone</label>
                      <select className="form-control" id="defaultTimezone">
                        <option>(GMT-08:00) Pacific Time</option>
                        <option>(GMT-07:00) Mountain Time</option>
                        <option>(GMT-06:00) Central Time</option>
                        <option selected>(GMT-05:00) Eastern Time</option>
                        <option>(GMT) Greenwich Mean Time</option>
                        <option>(GMT+01:00) Central European Time</option>
                        <option>(GMT+08:00) China Standard Time</option>
                        <option>(GMT+09:00) Japan Standard Time</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div className="row mb-3">
                  <div className="col-md-6">
                    <div className="form-group">
                      <label htmlFor="dateFormat">Date Format</label>
                      <select className="form-control" id="dateFormat">
                        <option selected>MM/DD/YYYY (e.g., 03/15/2023)</option>
                        <option>DD/MM/YYYY (e.g., 15/03/2023)</option>
                        <option>YYYY-MM-DD (e.g., 2023-03-15)</option>
                        <option>DD.MM.YYYY (e.g., 15.03.2023)</option>
                      </select>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="form-group">
                      <label htmlFor="timeFormat">Time Format</label>
                      <select className="form-control" id="timeFormat">
                        <option selected>12-hour (e.g., 2:30 PM)</option>
                        <option>24-hour (e.g., 14:30)</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div className="row mb-3">
                  <div className="col-md-6">
                    <div className="form-group">
                      <label htmlFor="currencyFormat">Currency</label>
                      <select className="form-control" id="currencyFormat">
                        <option selected>USD ($)</option>
                        <option>EUR (€)</option>
                        <option>GBP (£)</option>
                        <option>JPY (¥)</option>
                        <option>CNY (¥)</option>
                        <option>CAD ($)</option>
                        <option>AUD ($)</option>
                      </select>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="form-group">
                      <label htmlFor="numberFormat">Number Format</label>
                      <select className="form-control" id="numberFormat">
                        <option selected>1,234.56 (comma as thousands separator)</option>
                        <option>1.234,56 (dot as thousands separator)</option>
                        <option>1 234,56 (space as thousands separator)</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div className="form-group mb-3">
                  <label>Enabled Languages</label>
                  <div className="form-check">
                    <input className="form-check-input" type="checkbox" id="langEnglishUS" checked />
                    <label className="form-check-label" htmlFor="langEnglishUS">
                      English (United States)
                    </label>
                  </div>
                  <div className="form-check">
                    <input className="form-check-input" type="checkbox" id="langEnglishUK" />
                    <label className="form-check-label" htmlFor="langEnglishUK">
                      English (United Kingdom)
                    </label>
                  </div>
                  <div className="form-check">
                    <input className="form-check-input" type="checkbox" id="langSpanish" checked />
                    <label className="form-check-label" htmlFor="langSpanish">
                      Spanish
                    </label>
                  </div>
                  <div className="form-check">
                    <input className="form-check-input" type="checkbox" id="langFrench" checked />
                    <label className="form-check-label" htmlFor="langFrench">
                      French
                    </label>
                  </div>
                  <div className="form-check">
                    <input className="form-check-input" type="checkbox" id="langGerman" />
                    <label className="form-check-label" htmlFor="langGerman">
                      German
                    </label>
                  </div>
                  <div className="form-check">
                    <input className="form-check-input" type="checkbox" id="langChinese" />
                    <label className="form-check-label" htmlFor="langChinese">
                      Chinese (Simplified)
                    </label>
                  </div>
                  <div className="form-check">
                    <input className="form-check-input" type="checkbox" id="langJapanese" />
                    <label className="form-check-label" htmlFor="langJapanese">
                      Japanese
                    </label>
                  </div>
                </div>

                <button type="submit" className="btn btn-primary">
                  Save Changes
                </button>
              </form>
            </div>
          </div>
        )}

        {/* Email Settings */}
        {activeTab === "email" && (
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">Email Settings</h3>
            </div>
            <div className="card-body">
              <form>
                <div className="form-group mb-3">
                  <label htmlFor="smtpServer">SMTP Server</label>
                  <input
                    type="text"
                    className="form-control"
                    id="smtpServer"
                    placeholder="Enter SMTP server"
                    defaultValue="smtp.acmecorp.com"
                  />
                </div>
                <div className="row mb-3">
                  <div className="col-md-6">
                    <div className="form-group">
                      <label htmlFor="smtpPort">SMTP Port</label>
                      <input
                        type="text"
                        className="form-control"
                        id="smtpPort"
                        placeholder="Enter SMTP port"
                        defaultValue="587"
                      />
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="form-group">
                      <label htmlFor="smtpSecurity">Security</label>
                      <select className="form-control" id="smtpSecurity">
                        <option>None</option>
                        <option>SSL</option>
                        <option selected>TLS</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div className="form-group mb-3">
                  <label htmlFor="smtpUsername">SMTP Username</label>
                  <input
                    type="text"
                    className="form-control"
                    id="smtpUsername"
                    placeholder="Enter SMTP username"
                    defaultValue="notifications@acmecorp.com"
                  />
                </div>
                <div className="form-group mb-3">
                  <label htmlFor="smtpPassword">SMTP Password</label>
                  <input
                    type="password"
                    className="form-control"
                    id="smtpPassword"
                    placeholder="Enter SMTP password"
                    defaultValue="••••••••••••"
                  />
                </div>
                <div className="form-group mb-3">
                  <label htmlFor="fromEmail">From Email</label>
                  <input
                    type="email"
                    className="form-control"
                    id="fromEmail"
                    placeholder="Enter from email"
                    defaultValue="notifications@acmecorp.com"
                  />
                </div>
                <div className="form-group mb-3">
                  <label htmlFor="fromName">From Name</label>
                  <input
                    type="text"
                    className="form-control"
                    id="fromName"
                    placeholder="Enter from name"
                    defaultValue="Acme Corporation"
                  />
                </div>
                <div className="form-group mb-3">
                  <label htmlFor="testEmail">Test Email</label>
                  <div className="input-group">
                    <input
                      type="email"
                      className="form-control"
                      id="testEmail"
                      placeholder="Enter test email"
                      defaultValue="test@example.com"
                    />
                    <button className="btn btn-outline-secondary" type="button">
                      Send Test Email
                    </button>
                  </div>
                </div>
                <button type="submit" className="btn btn-primary">
                  Save Changes
                </button>
              </form>
            </div>
          </div>
        )}

        {/* Security Settings */}
        {activeTab === "security" && (
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">Security Settings</h3>
            </div>
            <div className="card-body">
              <form>
                <div className="form-group mb-3">
                  <label>Password Policy</label>
                  <div className="form-check mb-2">
                    <input className="form-check-input" type="checkbox" id="minLength" checked />
                    <label className="form-check-label" htmlFor="minLength">
                      Minimum length: 8 characters
                    </label>
                  </div>
                  <div className="form-check mb-2">
                    <input className="form-check-input" type="checkbox" id="requireUppercase" checked />
                    <label className="form-check-label" htmlFor="requireUppercase">
                      Require at least one uppercase letter
                    </label>
                  </div>
                  <div className="form-check mb-2">
                    <input className="form-check-input" type="checkbox" id="requireLowercase" checked />
                    <label className="form-check-label" htmlFor="requireLowercase">
                      Require at least one lowercase letter
                    </label>
                  </div>
                  <div className="form-check mb-2">
                    <input className="form-check-input" type="checkbox" id="requireNumber" checked />
                    <label className="form-check-label" htmlFor="requireNumber">
                      Require at least one number
                    </label>
                  </div>
                  <div className="form-check mb-2">
                    <input className="form-check-input" type="checkbox" id="requireSpecial" />
                    <label className="form-check-label" htmlFor="requireSpecial">
                      Require at least one special character
                    </label>
                  </div>
                </div>

                <div className="form-group mb-3">
                  <label htmlFor="passwordExpiration">Password Expiration</label>
                  <select className="form-control" id="passwordExpiration">
                    <option>Never</option>
                    <option>30 days</option>
                    <option selected>60 days</option>
                    <option>90 days</option>
                    <option>180 days</option>
                  </select>
                </div>

                <div className="form-group mb-3">
                  <label htmlFor="loginAttempts">Maximum Login Attempts</label>
                  <select className="form-control" id="loginAttempts">
                    <option>3 attempts</option>
                    <option selected>5 attempts</option>
                    <option>10 attempts</option>
                  </select>
                </div>

                <div className="form-group mb-3">
                  <label htmlFor="lockoutDuration">Account Lockout Duration</label>
                  <select className="form-control" id="lockoutDuration">
                    <option>15 minutes</option>
                    <option selected>30 minutes</option>
                    <option>1 hour</option>
                    <option>Until administrator unlocks</option>
                  </select>
                </div>

                <div className="form-group mb-3">
                  <label>Two-Factor Authentication</label>
                  <div className="form-check mb-2">
                    <input
                      className="form-check-input"
                      type="radio"
                      name="twoFactorAuth"
                      id="twoFactorOptional"
                      checked
                    />
                    <label className="form-check-label" htmlFor="twoFactorOptional">
                      Optional for all users
                    </label>
                  </div>
                  <div className="form-check mb-2">
                    <input className="form-check-input" type="radio" name="twoFactorAuth" id="twoFactorRequired" />
                    <label className="form-check-label" htmlFor="twoFactorRequired">
                      Required for all users
                    </label>
                  </div>
                  <div className="form-check mb-2">
                    <input className="form-check-input" type="radio" name="twoFactorAuth" id="twoFactorAdmins" />
                    <label className="form-check-label" htmlFor="twoFactorAdmins">
                      Required for administrators only
                    </label>
                  </div>
                </div>

                <div className="form-group mb-3">
                  <label>Session Settings</label>
                  <div className="form-check mb-2">
                    <input className="form-check-input" type="checkbox" id="sessionTimeout" checked />
                    <label className="form-check-label" htmlFor="sessionTimeout">
                      Enable session timeout
                    </label>
                  </div>
                  <div className="input-group mb-3">
                    <span className="input-group-text">Timeout after</span>
                    <input type="number" className="form-control" defaultValue="30" />
                    <span className="input-group-text">minutes of inactivity</span>
                  </div>
                </div>

                <button type="submit" className="btn btn-primary">
                  Save Changes
                </button>
              </form>
            </div>
          </div>
        )}

        {/* Billing Settings */}
        {activeTab === "billing" && (
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">Billing Settings</h3>
            </div>
            <div className="card-body">
              <div className="alert alert-info">
                <i className="bi bi-info-circle me-2"></i> Your current plan: <strong>Enterprise</strong> ($499/month)
              </div>

              <div className="row mb-4">
                <div className="col-md-6">
                  <div className="card bg-light">
                    <div className="card-body">
                      <h5 className="card-title">Subscription Details</h5>
                      <p className="card-text">
                        <strong>Plan:</strong> Enterprise
                        <br />
                        <strong>Price:</strong> $499/month
                        <br />
                        <strong>Billing Cycle:</strong> Monthly
                        <br />
                        <strong>Next Billing Date:</strong> April 15, 2023
                        <br />
                        <strong>Users:</strong> 25/50 (Active/Licensed)
                      </p>
                      <button className="btn btn-outline-primary btn-sm">Change Plan</button>
                    </div>
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="card bg-light">
                    <div className="card-body">
                      <h5 className="card-title">Payment Method</h5>
                      <p className="card-text">
                        <i className="bi bi-credit-card me-2"></i> Visa ending in 4242
                        <br />
                        <strong>Expiration:</strong> 12/2025
                        <br />
                        <strong>Billing Address:</strong> 123 Main St, Anytown, CA 12345
                      </p>
                      <button className="btn btn-outline-primary btn-sm">Update Payment Method</button>
                    </div>
                  </div>
                </div>
              </div>

              <h5 className="mb-3">Billing History</h5>
              <div className="table-responsive">
                <table className="table table-striped">
                  <thead>
                    <tr>
                      <th>Date</th>
                      <th>Description</th>
                      <th>Amount</th>
                      <th>Status</th>
                      <th>Invoice</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Mar 15, 2023</td>
                      <td>Enterprise Plan - Monthly Subscription</td>
                      <td>$499.00</td>
                      <td>
                        <span className="badge bg-success">Paid</span>
                      </td>
                      <td>
                        <button className="btn btn-sm btn-outline-secondary">
                          <i className="bi bi-download"></i> PDF
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>Feb 15, 2023</td>
                      <td>Enterprise Plan - Monthly Subscription</td>
                      <td>$499.00</td>
                      <td>
                        <span className="badge bg-success">Paid</span>
                      </td>
                      <td>
                        <button className="btn btn-sm btn-outline-secondary">
                          <i className="bi bi-download"></i> PDF
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>Jan 15, 2023</td>
                      <td>Enterprise Plan - Monthly Subscription</td>
                      <td>$499.00</td>
                      <td>
                        <span className="badge bg-success">Paid</span>
                      </td>
                      <td>
                        <button className="btn btn-sm btn-outline-secondary">
                          <i className="bi bi-download"></i> PDF
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td>Dec 15, 2022</td>
                      <td>Enterprise Plan - Monthly Subscription</td>
                      <td>$499.00</td>
                      <td>
                        <span className="badge bg-success">Paid</span>
                      </td>
                      <td>
                        <button className="btn btn-sm btn-outline-secondary">
                          <i className="bi bi-download"></i> PDF
                        </button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <h5 className="mb-3 mt-4">Billing Settings</h5>
              <form>
                <div className="form-group mb-3">
                  <label htmlFor="billingEmail">Billing Email</label>
                  <input type="email" className="form-control" id="billingEmail" defaultValue="billing@acmecorp.com" />
                </div>
                <div className="form-group mb-3">
                  <label htmlFor="billingAddress">Billing Address</label>
                  <textarea
                    className="form-control"
                    id="billingAddress"
                    rows={3}
                    defaultValue="123 Main Street, Suite 100, Anytown, CA 12345, USA"
                  ></textarea>
                </div>
                <div className="form-group mb-3">
                  <label htmlFor="taxId">Tax ID / VAT Number</label>
                  <input type="text" className="form-control" id="taxId" defaultValue="US123456789" />
                </div>
                <button type="submit" className="btn btn-primary">
                  Save Changes
                </button>
              </form>
            </div>
          </div>
        )}

        {/* Integrations Settings */}
        {activeTab === "integrations" && (
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">Integrations</h3>
            </div>
            <div className="card-body">
              <div className="row">
                <div className="col-md-6 mb-4">
                  <div className="card">
                    <div className="card-body">
                      <div className="d-flex align-items-center mb-3">
                        <img
                          src="/placeholder.svg?height=40&width=40"
                          alt="Google Workspace"
                          className="me-3"
                          style={{ width: "40px", height: "40px" }}
                        />
                        <h5 className="card-title mb-0">Google Workspace</h5>
                        <span className="badge bg-success ms-auto">Connected</span>
                      </div>
                      <p className="card-text">Sync contacts, calendar events, and emails with Google Workspace.</p>
                      <button className="btn btn-outline-danger btn-sm">Disconnect</button>
                      <button className="btn btn-outline-secondary btn-sm ms-2">Configure</button>
                    </div>
                  </div>
                </div>
                <div className="col-md-6 mb-4">
                  <div className="card">
                    <div className="card-body">
                      <div className="d-flex align-items-center mb-3">
                        <img
                          src="/placeholder.svg?height=40&width=40"
                          alt="Slack"
                          className="me-3"
                          style={{ width: "40px", height: "40px" }}
                        />
                        <h5 className="card-title mb-0">Slack</h5>
                        <span className="badge bg-success ms-auto">Connected</span>
                      </div>
                      <p className="card-text">Receive notifications and updates from your CRM directly in Slack.</p>
                      <button className="btn btn-outline-danger btn-sm">Disconnect</button>
                      <button className="btn btn-outline-secondary btn-sm ms-2">Configure</button>
                    </div>
                  </div>
                </div>
                <div className="col-md-6 mb-4">
                  <div className="card">
                    <div className="card-body">
                      <div className="d-flex align-items-center mb-3">
                        <img
                          src="/placeholder.svg?height=40&width=40"
                          alt="Microsoft 365"
                          className="me-3"
                          style={{ width: "40px", height: "40px" }}
                        />
                        <h5 className="card-title mb-0">Microsoft 365</h5>
                        <span className="badge bg-secondary ms-auto">Not Connected</span>
                      </div>
                      <p className="card-text">Sync contacts, calendar events, and emails with Microsoft 365.</p>
                      <button className="btn btn-primary btn-sm">Connect</button>
                    </div>
                  </div>
                </div>
                <div className="col-md-6 mb-4">
                  <div className="card">
                    <div className="card-body">
                      <div className="d-flex align-items-center mb-3">
                        <img
                          src="/placeholder.svg?height=40&width=40"
                          alt="Mailchimp"
                          className="me-3"
                          style={{ width: "40px", height: "40px" }}
                        />
                        <h5 className="card-title mb-0">Mailchimp</h5>
                        <span className="badge bg-secondary ms-auto">Not Connected</span>
                      </div>
                      <p className="card-text">Sync contacts and email campaigns with Mailchimp.</p>
                      <button className="btn btn-primary btn-sm">Connect</button>
                    </div>
                  </div>
                </div>
                <div className="col-md-6 mb-4">
                  <div className="card">
                    <div className="card-body">
                      <div className="d-flex align-items-center mb-3">
                        <img
                          src="/placeholder.svg?height=40&width=40"
                          alt="Zapier"
                          className="me-3"
                          style={{ width: "40px", height: "40px" }}
                        />
                        <h5 className="card-title mb-0">Zapier</h5>
                        <span className="badge bg-success ms-auto">Connected</span>
                      </div>
                      <p className="card-text">Connect your CRM with thousands of apps through Zapier.</p>
                      <button className="btn btn-outline-danger btn-sm">Disconnect</button>
                      <button className="btn btn-outline-secondary btn-sm ms-2">Configure</button>
                    </div>
                  </div>
                </div>
                <div className="col-md-6 mb-4">
                  <div className="card">
                    <div className="card-body">
                      <div className="d-flex align-items-center mb-3">
                        <img
                          src="/placeholder.svg?height=40&width=40"
                          alt="QuickBooks"
                          className="me-3"
                          style={{ width: "40px", height: "40px" }}
                        />
                        <h5 className="card-title mb-0">QuickBooks</h5>
                        <span className="badge bg-secondary ms-auto">Not Connected</span>
                      </div>
                      <p className="card-text">Sync invoices, customers, and payments with QuickBooks.</p>
                      <button className="btn btn-primary btn-sm">Connect</button>
                    </div>
                  </div>
                </div>
              </div>

              <h5 className="mb-3 mt-2">API Access</h5>
              <div className="alert alert-warning">
                <i className="bi bi-exclamation-triangle me-2"></i> API keys provide full access to your account. Keep
                them secure!
              </div>
              <div className="form-group mb-3">
                <label htmlFor="apiKey">API Key</label>
                <div className="input-group">
                  <input
                    type="text"
                    className="form-control"
                    id="apiKey"
                    defaultValue="sk_live_51JKl2mHGnrT7YzQX9iGnrT7YzQX9iGnrT7YzQX"
                    readOnly
                  />
                  <button className="btn btn-outline-secondary" type="button">
                    Copy
                  </button>
                  <button className="btn btn-outline-danger" type="button">
                    Regenerate
                  </button>
                </div>
              </div>
              <div className="form-group mb-3">
                <label htmlFor="webhookUrl">Webhook URL</label>
                <input
                  type="text"
                  className="form-control"
                  id="webhookUrl"
                  placeholder="Enter webhook URL"
                  defaultValue="https://www.acmecorp.com/api/webhook"
                />
              </div>
              <button type="submit" className="btn btn-primary">
                Save Changes
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

