"use client"

import { useState } from "react"
import Link from "next/link"

export default function EditLead({ params }: { params: { id: string } }) {
  const [leadSource, setLeadSource] = useState("website")
  const [showCustomFields, setShowCustomFields] = useState(false)

  // In a real application, you would fetch lead data based on the ID
  const lead = {
    id: params.id,
    firstName: "David",
    lastName: "Miller",
    email: "david@futuretech.com",
    phone: "(123) 456-7890",
    jobTitle: "CTO",
    company: "Future Tech",
    website: "https://www.futuretech.com",
    industry: "Technology",
    employees: "51-200",
    street: "456 Tech Blvd",
    city: "Innovation City",
    state: "CA",
    zipCode: "94103",
    country: "United States",
    source: "Website",
    status: "New",
    owner: "John Doe",
    notes: "Interested in our enterprise software solutions. Initial contact through website form.",
  }

  return (
    <div className="row">
      <div className="col-md-12">
        <div className="card card-primary">
          <div className="card-header">
            <h3 className="card-title">
              Edit Lead: {lead.firstName} {lead.lastName}
            </h3>
          </div>
          <form>
            <div className="card-body">
              <div className="row">
                <div className="col-md-6">
                  <h4 className="mb-3">Contact Information</h4>
                  <div className="row">
                    <div className="col-md-6">
                      <div className="form-group mb-3">
                        <label htmlFor="firstName">First Name</label>
                        <input
                          type="text"
                          className="form-control"
                          id="firstName"
                          placeholder="Enter first name"
                          defaultValue={lead.firstName}
                        />
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="form-group mb-3">
                        <label htmlFor="lastName">Last Name</label>
                        <input
                          type="text"
                          className="form-control"
                          id="lastName"
                          placeholder="Enter last name"
                          defaultValue={lead.lastName}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-group mb-3">
                    <label htmlFor="email">Email</label>
                    <input
                      type="email"
                      className="form-control"
                      id="email"
                      placeholder="Enter email"
                      defaultValue={lead.email}
                    />
                  </div>
                  <div className="form-group mb-3">
                    <label htmlFor="phone">Phone</label>
                    <input
                      type="text"
                      className="form-control"
                      id="phone"
                      placeholder="Enter phone number"
                      defaultValue={lead.phone}
                    />
                  </div>
                  <div className="form-group mb-3">
                    <label htmlFor="jobTitle">Job Title</label>
                    <input
                      type="text"
                      className="form-control"
                      id="jobTitle"
                      placeholder="Enter job title"
                      defaultValue={lead.jobTitle}
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  <h4 className="mb-3">Company Information</h4>
                  <div className="form-group mb-3">
                    <label htmlFor="company">Company Name</label>
                    <input
                      type="text"
                      className="form-control"
                      id="company"
                      placeholder="Enter company name"
                      defaultValue={lead.company}
                    />
                  </div>
                  <div className="form-group mb-3">
                    <label htmlFor="website">Website</label>
                    <input
                      type="text"
                      className="form-control"
                      id="website"
                      placeholder="Enter website"
                      defaultValue={lead.website}
                    />
                  </div>
                  <div className="form-group mb-3">
                    <label htmlFor="industry">Industry</label>
                    <select className="form-control" id="industry" defaultValue={lead.industry}>
                      <option value="">Select Industry</option>
                      <option>Technology</option>
                      <option>Healthcare</option>
                      <option>Finance</option>
                      <option>Education</option>
                      <option>Manufacturing</option>
                      <option>Retail</option>
                      <option>Hospitality</option>
                      <option>Other</option>
                    </select>
                  </div>
                  <div className="form-group mb-3">
                    <label htmlFor="employees">Number of Employees</label>
                    <select className="form-control" id="employees" defaultValue={lead.employees}>
                      <option value="">Select Range</option>
                      <option>1-10</option>
                      <option>11-50</option>
                      <option>51-200</option>
                      <option>201-500</option>
                      <option>501-1000</option>
                      <option>1000+</option>
                    </select>
                  </div>
                </div>
              </div>

              <div className="row mt-3">
                <div className="col-md-6">
                  <h4 className="mb-3">Address</h4>
                  <div className="form-group mb-3">
                    <label htmlFor="street">Street Address</label>
                    <input
                      type="text"
                      className="form-control"
                      id="street"
                      placeholder="Enter street address"
                      defaultValue={lead.street}
                    />
                  </div>
                  <div className="row">
                    <div className="col-md-6">
                      <div className="form-group mb-3">
                        <label htmlFor="city">City</label>
                        <input
                          type="text"
                          className="form-control"
                          id="city"
                          placeholder="Enter city"
                          defaultValue={lead.city}
                        />
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="form-group mb-3">
                        <label htmlFor="state">State/Province</label>
                        <input
                          type="text"
                          className="form-control"
                          id="state"
                          placeholder="Enter state/province"
                          defaultValue={lead.state}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-6">
                      <div className="form-group mb-3">
                        <label htmlFor="zipCode">Zip/Postal Code</label>
                        <input
                          type="text"
                          className="form-control"
                          id="zipCode"
                          placeholder="Enter zip/postal code"
                          defaultValue={lead.zipCode}
                        />
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="form-group mb-3">
                        <label htmlFor="country">Country</label>
                        <select className="form-control" id="country" defaultValue={lead.country}>
                          <option value="">Select Country</option>
                          <option>United States</option>
                          <option>Canada</option>
                          <option>United Kingdom</option>
                          <option>Australia</option>
                          <option>Germany</option>
                          <option>France</option>
                          <option>Japan</option>
                          <option>Other</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-md-6">
                  <h4 className="mb-3">Lead Details</h4>
                  <div className="form-group mb-3">
                    <label htmlFor="source">Lead Source</label>
                    <select
                      className="form-control"
                      id="source"
                      value={leadSource}
                      onChange={(e) => setLeadSource(e.target.value)}
                      defaultValue={lead.source}
                    >
                      <option value="website">Website</option>
                      <option value="referral">Referral</option>
                      <option value="social_media">Social Media</option>
                      <option value="email_campaign">Email Campaign</option>
                      <option value="trade_show">Trade Show</option>
                      <option value="cold_call">Cold Call</option>
                      <option value="other">Other</option>
                    </select>
                  </div>

                  {leadSource === "referral" && (
                    <div className="form-group mb-3">
                      <label htmlFor="referralSource">Referred By</label>
                      <input
                        type="text"
                        className="form-control"
                        id="referralSource"
                        placeholder="Enter referral name"
                      />
                    </div>
                  )}

                  {leadSource === "social_media" && (
                    <div className="form-group mb-3">
                      <label htmlFor="socialPlatform">Social Media Platform</label>
                      <select className="form-control" id="socialPlatform">
                        <option>LinkedIn</option>
                        <option>Twitter</option>
                        <option>Facebook</option>
                        <option>Instagram</option>
                        <option>YouTube</option>
                        <option>Other</option>
                      </select>
                    </div>
                  )}

                  {leadSource === "trade_show" && (
                    <div className="form-group mb-3">
                      <label htmlFor="tradeShowName">Trade Show Name</label>
                      <input
                        type="text"
                        className="form-control"
                        id="tradeShowName"
                        placeholder="Enter trade show name"
                      />
                    </div>
                  )}

                  {leadSource === "other" && (
                    <div className="form-group mb-3">
                      <label htmlFor="otherSource">Specify Source</label>
                      <input type="text" className="form-control" id="otherSource" placeholder="Enter lead source" />
                    </div>
                  )}

                  <div className="form-group mb-3">
                    <label htmlFor="status">Status</label>
                    <select className="form-control" id="status" defaultValue={lead.status}>
                      <option>New</option>
                      <option>Contacted</option>
                      <option>Qualified</option>
                      <option>Proposal</option>
                      <option>Negotiation</option>
                      <option>Unqualified</option>
                    </select>
                  </div>
                  <div className="form-group mb-3">
                    <label htmlFor="owner">Lead Owner</label>
                    <select className="form-control" id="owner" defaultValue={lead.owner}>
                      <option>John Doe</option>
                      <option>Sarah Johnson</option>
                      <option>Michael Brown</option>
                      <option>Emily Davis</option>
                      <option>Robert Wilson</option>
                    </select>
                  </div>
                  <div className="form-group mb-3">
                    <label htmlFor="notes">Notes</label>
                    <textarea
                      className="form-control"
                      id="notes"
                      rows={3}
                      placeholder="Enter notes about this lead"
                      defaultValue={lead.notes}
                    ></textarea>
                  </div>
                </div>
              </div>

              <div className="row mt-3">
                <div className="col-md-12">
                  <div className="d-flex justify-content-between align-items-center mb-3">
                    <h4>Additional Information</h4>
                    <button
                      type="button"
                      className="btn btn-outline-primary"
                      onClick={() => setShowCustomFields(!showCustomFields)}
                    >
                      {showCustomFields ? "Hide Custom Fields" : "Show Custom Fields"}
                    </button>
                  </div>

                  {showCustomFields && (
                    <div className="row">
                      <div className="col-md-4">
                        <div className="form-group mb-3">
                          <label htmlFor="budget">Budget</label>
                          <select className="form-control" id="budget">
                            <option value="">Select Budget Range</option>
                            <option>$0 - $5,000</option>
                            <option>$5,001 - $10,000</option>
                            <option>$10,001 - $25,000</option>
                            <option>$25,001 - $50,000</option>
                            <option>$50,001+</option>
                            <option>Unknown</option>
                          </select>
                        </div>
                      </div>
                      <div className="col-md-4">
                        <div className="form-group mb-3">
                          <label htmlFor="timeframe">Purchase Timeframe</label>
                          <select className="form-control" id="timeframe">
                            <option value="">Select Timeframe</option>
                            <option>Immediate</option>
                            <option>1-3 Months</option>
                            <option>3-6 Months</option>
                            <option>6-12 Months</option>
                            <option>12+ Months</option>
                            <option>Unknown</option>
                          </select>
                        </div>
                      </div>
                      <div className="col-md-4">
                        <div className="form-group mb-3">
                          <label htmlFor="decisionMaker">Decision Maker</label>
                          <select className="form-control" id="decisionMaker">
                            <option value="">Select Option</option>
                            <option>Yes</option>
                            <option>No</option>
                            <option>Unknown</option>
                          </select>
                        </div>
                      </div>
                      <div className="col-md-4">
                        <div className="form-group mb-3">
                          <label htmlFor="interests">Product Interests</label>
                          <select className="form-control" id="interests" multiple>
                            <option>Enterprise Software Package</option>
                            <option>Cloud Migration</option>
                            <option>Support Contract</option>
                            <option>Hardware Upgrade</option>
                            <option>IT Consulting</option>
                          </select>
                        </div>
                      </div>
                      <div className="col-md-4">
                        <div className="form-group mb-3">
                          <label htmlFor="competitors">Competitors Considered</label>
                          <input
                            type="text"
                            className="form-control"
                            id="competitors"
                            placeholder="Enter competitors"
                          />
                        </div>
                      </div>
                      <div className="col-md-4">
                        <div className="form-group mb-3">
                          <label htmlFor="painPoints">Pain Points</label>
                          <textarea
                            className="form-control"
                            id="painPoints"
                            rows={3}
                            placeholder="Enter pain points"
                          ></textarea>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
            <div className="card-footer">
              <button type="submit" className="btn btn-primary">
                Save Changes
              </button>
              <Link href={`/leads/${lead.id}`} className="btn btn-default float-end">
                Cancel
              </Link>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}

