"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useCrm } from "@/lib/context/CrmContext"
import { useFormValidation } from "@/lib/hooks/useFormValidation"
import { LoadingSpinner } from "@/components/ui/loading-spinner"

export default function LeadDetail({ params }: { params: { id: string } }) {
  const {
    state,
    getLeadById,
    getActivitiesByRelation,
    getTasksByRelation,
    getDocumentsByRelation,
    addActivity,
    addTask,
    addDocument,
    convertLead,
    deleteLead,
  } = useCrm()
  const { isLoading } = state

  const [activeTab, setActiveTab] = useState("overview")
  const [showConvertModal, setShowConvertModal] = useState(false)
  const [showDeleteModal, setShowDeleteModal] = useState(false)
  const [showAddActivityModal, setShowAddActivityModal] = useState(false)
  const [activityType, setActivityType] = useState("call")
  const [showAddTaskModal, setShowAddTaskModal] = useState(false)
  const [showUploadModal, setShowUploadModal] = useState(false)

  // Get lead data
  const lead = getLeadById(params.id)
  const activities = getActivitiesByRelation("lead", params.id)
  const tasks = getTasksByRelation("lead", params.id)
  const documents = getDocumentsByRelation("lead", params.id)

  // Form validation for activity
  const activityValidation = useFormValidation(
    {
      type: activityType,
      date: new Date().toISOString().split("T")[0],
      time: new Date().toTimeString().split(" ")[0].substring(0, 5),
      description: "",
      outcome: "",
      duration: "30",
      subject: "",
      content: "",
      location: "",
      attendees: "",
    },
    {
      description: { required: true, message: "Description is required" },
      date: { required: true, message: "Date is required" },
      time: { required: true, message: "Time is required" },
    },
  )

  // Form validation for task
  const taskValidation = useFormValidation(
    {
      title: "",
      dueDate: new Date().toISOString().split("T")[0],
      priority: "Medium",
      status: "Pending",
      description: "",
      assignedTo: state.users[0]?.id || "",
    },
    {
      title: { required: true, message: "Title is required" },
      dueDate: { required: true, message: "Due date is required" },
      assignedTo: { required: true, message: "Assignee is required" },
    },
  )

  // Form validation for document upload
  const documentValidation = useFormValidation(
    {
      name: "",
      type: "PDF",
      description: "",
    },
    {
      name: { required: true, message: "Name is required" },
    },
  )

  // Form validation for lead conversion
  const convertValidation = useFormValidation(
    {
      createDeal: true,
      dealName: lead ? `${lead.company} Deal` : "",
      dealValue: "5000",
      dealStage: "Proposal",
      notifyTeam: true,
    },
    {
      dealName: {
        required: (values) => values.createDeal,
        message: "Deal name is required when creating a deal",
      },
      dealValue: {
        required: (values) => values.createDeal,
        isNumber: true,
        message: "Please enter a valid deal value",
      },
    },
  )

  // Handle activity form submission
  const handleActivitySubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (activityValidation.validateForm()) {
      const { type, date, time, description, outcome, duration, subject, content, location, attendees } =
        activityValidation.values

      addActivity({
        type,
        date,
        time,
        description: type === "email" ? subject : description,
        outcome: type === "email" ? "Sent" : outcome,
        relatedTo: { type: "lead", id: params.id },
      })

      setShowAddActivityModal(false)
      activityValidation.resetForm()
    }
  }

  // Handle task form submission
  const handleTaskSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (taskValidation.validateForm()) {
      const { title, dueDate, priority, status, description, assignedTo } = taskValidation.values

      addTask({
        title,
        dueDate,
        priority,
        status,
        description,
        assignedTo,
        relatedTo: { type: "lead", id: params.id },
      })

      setShowAddTaskModal(false)
      taskValidation.resetForm()
    }
  }

  // Handle document upload
  const handleDocumentSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (documentValidation.validateForm()) {
      const { name, type, description } = documentValidation.values

      addDocument({
        name,
        type,
        size: "1.2 MB", // In a real app, this would be calculated from the file
        uploaded: new Date().toLocaleDateString(),
        description,
        relatedTo: { type: "lead", id: params.id },
      })

      setShowUploadModal(false)
      documentValidation.resetForm()
    }
  }

  // Handle lead conversion
  const handleConvertSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (convertValidation.validateForm() && lead) {
      const { createDeal, dealName, dealValue, dealStage, notifyTeam } = convertValidation.values

      // Create customer from lead
      const customer = {
        name: lead.name,
        company: lead.company,
        email: lead.email,
        phone: lead.phone,
        address: lead.address || "",
        status: "Active",
        created: new Date().toLocaleDateString(),
        notes: lead.notes,
      }

      // Create deal if selected
      let deal
      if (createDeal) {
        deal = {
          name: dealName,
          value: Number.parseFloat(dealValue),
          stage: dealStage,
          customer: "", // This will be set by the convertLead function
          owner: lead.owner,
          created: new Date().toLocaleDateString(),
          closingDate: new Date(new Date().setDate(new Date().getDate() + 30)).toLocaleDateString(),
          probability: dealStage === "Proposal" ? 50 : 75,
        }
      }

      convertLead(params.id, customer, deal)
      setShowConvertModal(false)
    }
  }

  // Handle lead deletion
  const handleDeleteLead = () => {
    deleteLead(params.id)
    // Redirect to leads page
    window.location.href = "/leads"
  }

  if (isLoading || !lead) {
    return <LoadingSpinner />
  }

  return (
    <div className="row">
      <div className="col-md-4">
        <div className="card card-primary card-outline">
          <div className="card-body box-profile">
            <div className="text-center">
              <img
                className="profile-user-img img-fluid img-circle"
                src="/placeholder.svg?height=128&width=128"
                alt="Lead profile picture"
              />
            </div>
            <h3 className="profile-username text-center">{lead.name}</h3>
            <p className="text-muted text-center">{lead.company}</p>

            <div className="d-flex justify-content-center mb-3">
              <div className="btn-group">
                <button className="btn btn-primary" onClick={() => setShowConvertModal(true)}>
                  <i className="bi bi-person-check me-1"></i> Convert
                </button>
                <Link href={`/leads/edit/${lead.id}`} className="btn btn-info">
                  <i className="bi bi-pencil me-1"></i> Edit
                </Link>
                <button className="btn btn-danger" onClick={() => setShowDeleteModal(true)}>
                  <i className="bi bi-trash me-1"></i> Delete
                </button>
              </div>
            </div>

            <ul className="list-group list-group-unbordered mb-3">
              <li className="list-group-item">
                <b>Email</b> <a className="float-end">{lead.email}</a>
              </li>
              <li className="list-group-item">
                <b>Phone</b> <a className="float-end">{lead.phone}</a>
              </li>
              <li className="list-group-item">
                <b>Source</b> <a className="float-end">{lead.source}</a>
              </li>
              <li className="list-group-item">
                <b>Status</b> <span className="float-end badge bg-warning">{lead.status}</span>
              </li>
              <li className="list-group-item">
                <b>Created</b> <a className="float-end">{lead.created}</a>
              </li>
              <li className="list-group-item">
                <b>Owner</b> <a className="float-end">{lead.owner}</a>
              </li>
            </ul>

            <div className="progress mb-3">
              <div
                className="progress-bar bg-success"
                role="progressbar"
                style={{ width: `${lead.score || 0}%` }}
                aria-valuenow={lead.score || 0}
                aria-valuemin={0}
                aria-valuemax={100}
              >
                {lead.score || 0}%
              </div>
            </div>
            <p className="text-center">Lead Score</p>
          </div>
        </div>

        <div className="card card-primary">
          <div className="card-header">
            <h3 className="card-title">About {lead.name}</h3>
          </div>
          <div className="card-body">
            {lead.address && (
              <>
                <strong>
                  <i className="bi bi-map-marker me-1"></i> Address
                </strong>
                <p className="text-muted">{lead.address}</p>
                <hr />
              </>
            )}
            {lead.notes && (
              <>
                <strong>
                  <i className="bi bi-pencil me-1"></i> Notes
                </strong>
                <p className="text-muted">{lead.notes}</p>
              </>
            )}
          </div>
        </div>
      </div>

      <div className="col-md-8">
        <div className="card">
          <div className="card-header p-2">
            <ul className="nav nav-pills">
              <li className="nav-item">
                <a
                  className={`nav-link ${activeTab === "overview" ? "active" : ""}`}
                  href="#"
                  onClick={(e) => {
                    e.preventDefault()
                    setActiveTab("overview")
                  }}
                >
                  Overview
                </a>
              </li>
              <li className="nav-item">
                <a
                  className={`nav-link ${activeTab === "activities" ? "active" : ""}`}
                  href="#"
                  onClick={(e) => {
                    e.preventDefault()
                    setActiveTab("activities")
                  }}
                >
                  Activities
                </a>
              </li>
              <li className="nav-item">
                <a
                  className={`nav-link ${activeTab === "tasks" ? "active" : ""}`}
                  href="#"
                  onClick={(e) => {
                    e.preventDefault()
                    setActiveTab("tasks")
                  }}
                >
                  Tasks
                </a>
              </li>
              <li className="nav-item">
                <a
                  className={`nav-link ${activeTab === "documents" ? "active" : ""}`}
                  href="#"
                  onClick={(e) => {
                    e.preventDefault()
                    setActiveTab("documents")
                  }}
                >
                  Documents
                </a>
              </li>
            </ul>
          </div>
          <div className="card-body">
            <div className="tab-content">
              {/* Overview Tab */}
              <div className={`tab-pane ${activeTab === "overview" ? "active" : ""}`}>
                <div className="row">
                  <div className="col-md-6">
                    <div className="card">
                      <div className="card-header">
                        <h3 className="card-title">Lead Information</h3>
                      </div>
                      <div className="card-body">
                        <div className="table-responsive">
                          <table className="table table-bordered">
                            <tbody>
                              <tr>
                                <th style={{ width: "30%" }}>Full Name</th>
                                <td>{lead.name}</td>
                              </tr>
                              <tr>
                                <th>Company</th>
                                <td>{lead.company}</td>
                              </tr>
                              <tr>
                                <th>Email</th>
                                <td>{lead.email}</td>
                              </tr>
                              <tr>
                                <th>Phone</th>
                                <td>{lead.phone}</td>
                              </tr>
                              {lead.address && (
                                <tr>
                                  <th>Address</th>
                                  <td>{lead.address}</td>
                                </tr>
                              )}
                              <tr>
                                <th>Source</th>
                                <td>{lead.source}</td>
                              </tr>
                              <tr>
                                <th>Status</th>
                                <td>
                                  <span className="badge bg-warning">{lead.status}</span>
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="card">
                      <div className="card-header">
                        <h3 className="card-title">Recent Activities</h3>
                      </div>
                      <div className="card-body p-0">
                        <ul className="list-group list-group-flush">
                          {activities.slice(0, 3).map((activity) => (
                            <li key={activity.id} className="list-group-item">
                              <div className="d-flex w-100 justify-content-between">
                                <h5 className="mb-1">
                                  <i
                                    className={`bi ${
                                      activity.type === "Call"
                                        ? "bi-telephone"
                                        : activity.type === "Email"
                                          ? "bi-envelope"
                                          : "bi-journal-text"
                                    } me-2`}
                                  ></i>
                                  {activity.type}
                                </h5>
                                <small>
                                  {activity.date}, {activity.time}
                                </small>
                              </div>
                              <p className="mb-1">{activity.description}</p>
                              <small className="text-muted">Outcome: {activity.outcome}</small>
                            </li>
                          ))}
                          {activities.length === 0 && (
                            <li className="list-group-item text-center">No activities yet. Add your first activity.</li>
                          )}
                        </ul>
                      </div>
                      <div className="card-footer text-center">
                        <a
                          href="#"
                          onClick={(e) => {
                            e.preventDefault()
                            setActiveTab("activities")
                          }}
                        >
                          View All Activities
                        </a>
                      </div>
                    </div>

                    <div className="card">
                      <div className="card-header">
                        <h3 className="card-title">Upcoming Tasks</h3>
                      </div>
                      <div className="card-body p-0">
                        <ul className="list-group list-group-flush">
                          {tasks.slice(0, 3).map((task) => (
                            <li key={task.id} className="list-group-item">
                              <div className="d-flex w-100 justify-content-between">
                                <h5 className="mb-1">{task.title}</h5>
                                <small>Due: {task.dueDate}</small>
                              </div>
                              <p className="mb-1">
                                <span
                                  className={`badge ${
                                    task.priority === "High"
                                      ? "bg-danger"
                                      : task.priority === "Medium"
                                        ? "bg-warning"
                                        : "bg-info"
                                  }`}
                                >
                                  {task.priority}
                                </span>{" "}
                                <span className="badge bg-secondary">{task.status}</span>
                              </p>
                            </li>
                          ))}
                          {tasks.length === 0 && (
                            <li className="list-group-item text-center">No tasks yet. Add your first task.</li>
                          )}
                        </ul>
                      </div>
                      <div className="card-footer text-center">
                        <a
                          href="#"
                          onClick={(e) => {
                            e.preventDefault()
                            setActiveTab("tasks")
                          }}
                        >
                          View All Tasks
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Activities Tab */}
              <div className={`tab-pane ${activeTab === "activities" ? "active" : ""}`}>
                <div className="d-flex justify-content-between mb-3">
                  <h4>Activity History</h4>
                  <button className="btn btn-primary" onClick={() => setShowAddActivityModal(true)}>
                    <i className="bi bi-plus"></i> Add Activity
                  </button>
                </div>
                <div className="table-responsive">
                  <table className="table table-striped">
                    <thead>
                      <tr>
                        <th>Type</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Description</th>
                        <th>Outcome</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {activities.map((activity) => (
                        <tr key={activity.id}>
                          <td>
                            <i
                              className={`bi ${
                                activity.type === "Call"
                                  ? "bi-telephone"
                                  : activity.type === "Email"
                                    ? "bi-envelope"
                                    : activity.type === "journal-text"
                              } me-2`}
                            ></i>
                            {activity.type}
                          </td>
                          <td>{activity.date}</td>
                          <td>{activity.time}</td>
                          <td>{activity.description}</td>
                          <td>{activity.outcome}</td>
                          <td>
                            <button className="btn btn-info btn-sm me-1">
                              <i className="bi bi-eye"></i>
                            </button>
                            <button className="btn btn-primary btn-sm me-1">
                              <i className="bi bi-pencil"></i>
                            </button>
                            <button className="btn btn-danger btn-sm">
                              <i className="bi bi-trash"></i>
                            </button>
                          </td>
                        </tr>
                      ))}
                      {activities.length === 0 && (
                        <tr>
                          <td colSpan={6} className="text-center">
                            No activities found. Add your first activity.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>

                <div className="timeline mt-4">
                  <div className="time-label">
                    <span className="bg-primary">Activity Timeline</span>
                  </div>

                  {activities.map((activity) => (
                    <div key={activity.id}>
                      <i
                        className={`bi ${
                          activity.type === "Call"
                            ? "bi-telephone bg-info"
                            : activity.type === "Email"
                              ? "bi-envelope bg-success"
                              : "bi-journal-text bg-warning"
                        }`}
                      ></i>
                      <div className="timeline-item">
                        <span className="time">
                          <i className="bi bi-clock"></i> {activity.time}
                        </span>
                        <h3 className="timeline-header">
                          <a href="#">{activity.type}</a> - {activity.date}
                        </h3>
                        <div className="timeline-body">{activity.description}</div>
                        <div className="timeline-footer">
                          <span className="text-muted">Outcome: {activity.outcome}</span>
                        </div>
                      </div>
                    </div>
                  ))}

                  {activities.length === 0 && (
                    <div>
                      <i className="bi bi-info-circle bg-info"></i>
                      <div className="timeline-item">
                        <h3 className="timeline-header">No activities yet</h3>
                        <div className="timeline-body">
                          Click the "Add Activity" button to record your first interaction with this lead.
                        </div>
                      </div>
                    </div>
                  )}

                  <div>
                    <i className="bi bi-clock bg-gray"></i>
                  </div>
                </div>
              </div>

              {/* Tasks Tab */}
              <div className={`tab-pane ${activeTab === "tasks" ? "active" : ""}`}>
                <div className="d-flex justify-content-between mb-3">
                  <h4>Tasks</h4>
                  <button className="btn btn-primary" onClick={() => setShowAddTaskModal(true)}>
                    <i className="bi bi-plus"></i> Add Task
                  </button>
                </div>
                <div className="table-responsive">
                  <table className="table table-striped">
                    <thead>
                      <tr>
                        <th style={{ width: "5%" }}></th>
                        <th>Title</th>
                        <th>Due Date</th>
                        <th>Priority</th>
                        <th>Status</th>
                        <th>Assigned To</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {tasks.map((task) => {
                        const assignee = state.users.find((user) => user.id === task.assignedTo)
                        return (
                          <tr key={task.id}>
                            <td>
                              <div className="form-check">
                                <input className="form-check-input" type="checkbox" />
                              </div>
                            </td>
                            <td>{task.title}</td>
                            <td>{task.dueDate}</td>
                            <td>
                              <span
                                className={`badge ${
                                  task.priority === "High"
                                    ? "bg-danger"
                                    : task.priority === "Medium"
                                      ? "bg-warning"
                                      : "bg-info"
                                }`}
                              >
                                {task.priority}
                              </span>
                            </td>
                            <td>
                              <span className="badge bg-secondary">{task.status}</span>
                            </td>
                            <td>{assignee?.name || "Unassigned"}</td>
                            <td>
                              <button className="btn btn-info btn-sm me-1">
                                <i className="bi bi-eye"></i>
                              </button>
                              <button className="btn btn-primary btn-sm me-1">
                                <i className="bi bi-pencil"></i>
                              </button>
                              <button className="btn btn-danger btn-sm">
                                <i className="bi bi-trash"></i>
                              </button>
                            </td>
                          </tr>
                        )
                      })}
                      {tasks.length === 0 && (
                        <tr>
                          <td colSpan={7} className="text-center">
                            No tasks found. Add your first task.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Documents Tab */}
              <div className={`tab-pane ${activeTab === "documents" ? "active" : ""}`}>
                <div className="d-flex justify-content-between mb-3">
                  <h4>Documents</h4>
                  <button className="btn btn-primary" onClick={() => setShowUploadModal(true)}>
                    <i className="bi bi-upload"></i> Upload Document
                  </button>
                </div>
                <div className="table-responsive">
                  <table className="table table-striped">
                    <thead>
                      <tr>
                        <th>Name</th>
                        <th>Type</th>
                        <th>Size</th>
                        <th>Uploaded</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {documents.map((document) => (
                        <tr key={document.id}>
                          <td>
                            <i
                              className={`bi ${
                                document.type === "PDF"
                                  ? "bi-file-earmark-pdf"
                                  : document.type === "DOCX"
                                    ? "bi-file-earmark-word"
                                    : "bi-file-earmark"
                              } me-2 text-danger`}
                            ></i>
                            {document.name}
                          </td>
                          <td>{document.type}</td>
                          <td>{document.size}</td>
                          <td>{document.uploaded}</td>
                          <td>
                            <button className="btn btn-info btn-sm me-1">
                              <i className="bi bi-eye"></i> View
                            </button>
                            <button className="btn btn-success btn-sm me-1">
                              <i className="bi bi-download"></i> Download
                            </button>
                            <button className="btn btn-danger btn-sm">
                              <i className="bi bi-trash"></i> Delete
                            </button>
                          </td>
                        </tr>
                      ))}
                      {documents.length === 0 && (
                        <tr>
                          <td colSpan={5} className="text-center">
                            No documents found. Upload your first document.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Convert Lead Modal */}
      {showConvertModal && (
        <div className="modal fade show" style={{ display: "block", backgroundColor: "rgba(0,0,0,0.5)" }}>
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Convert Lead to Customer</h5>
                <button type="button" className="btn-close" onClick={() => setShowConvertModal(false)}></button>
              </div>
              <form onSubmit={handleConvertSubmit}>
                <div className="modal-body">
                  <p>
                    You are about to convert <strong>{lead.name}</strong> from <strong>{lead.company}</strong> to a
                    customer. This will:
                  </p>
                  <ul>
                    <li>Create a new customer record</li>
                    <li>Transfer all lead information to the customer record</li>
                    <li>Move all activities, tasks, and documents to the customer record</li>
                    <li>Archive this lead record</li>
                  </ul>

                  <div className="form-check mb-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="createDeal"
                      name="createDeal"
                      checked={convertValidation.values.createDeal}
                      onChange={convertValidation.handleChange}
                    />
                    <label className="form-check-label" htmlFor="createDeal">
                      Create a deal for this customer
                    </label>
                  </div>

                  {convertValidation.values.createDeal && (
                    <div className="card mb-3">
                      <div className="card-header">
                        <h6 className="mb-0">Deal Information</h6>
                      </div>
                      <div className="card-body">
                        <div className="row">
                          <div className="col-md-6 mb-3">
                            <label htmlFor="dealName" className="form-label">
                              Deal Name
                            </label>
                            <input
                              type="text"
                              className={`form-control ${convertValidation.touched.dealName && convertValidation.errors.dealName ? "is-invalid" : ""}`}
                              id="dealName"
                              name="dealName"
                              value={convertValidation.values.dealName}
                              onChange={convertValidation.handleChange}
                              onBlur={convertValidation.handleBlur}
                            />
                            {convertValidation.touched.dealName && convertValidation.errors.dealName && (
                              <div className="invalid-feedback">{convertValidation.errors.dealName}</div>
                            )}
                          </div>
                          <div className="col-md-6 mb-3">
                            <label htmlFor="dealValue" className="form-label">
                              Deal Value
                            </label>
                            <div className="input-group">
                              <span className="input-group-text">$</span>
                              <input
                                type="text"
                                className={`form-control ${convertValidation.touched.dealValue && convertValidation.errors.dealValue ? "is-invalid" : ""}`}
                                id="dealValue"
                                name="dealValue"
                                value={convertValidation.values.dealValue}
                                onChange={convertValidation.handleChange}
                                onBlur={convertValidation.handleBlur}
                              />
                              {convertValidation.touched.dealValue && convertValidation.errors.dealValue && (
                                <div className="invalid-feedback">{convertValidation.errors.dealValue}</div>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="mb-3">
                          <label htmlFor="dealStage" className="form-label">
                            Deal Stage
                          </label>
                          <select
                            className="form-control"
                            id="dealStage"
                            name="dealStage"
                            value={convertValidation.values.dealStage}
                            onChange={convertValidation.handleChange}
                          >
                            <option value="Proposal">Proposal</option>
                            <option value="Negotiation">Negotiation</option>
                            <option value="Closed Won">Closed Won</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  )}

                  <div className="form-check mb-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="notifyTeam"
                      name="notifyTeam"
                      checked={convertValidation.values.notifyTeam}
                      onChange={convertValidation.handleChange}
                    />
                    <label className="form-check-label" htmlFor="notifyTeam">
                      Notify team members
                    </label>
                  </div>
                </div>
                <div className="modal-footer">
                  <button type="button" className="btn btn-secondary" onClick={() => setShowConvertModal(false)}>
                    Cancel
                  </button>
                  <button type="submit" className="btn btn-success">
                    Convert Lead
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Delete Lead Modal */}
      {showDeleteModal && (
        <div className="modal fade show" style={{ display: "block", backgroundColor: "rgba(0,0,0,0.5)" }}>
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Delete Lead</h5>
                <button type="button" className="btn-close" onClick={() => setShowDeleteModal(false)}></button>
              </div>
              <div className="modal-body">
                <p>
                  Are you sure you want to delete the lead <strong>{lead.name}</strong> from{" "}
                  <strong>{lead.company}</strong>?
                </p>
                <p className="text-danger">This action cannot be undone.</p>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowDeleteModal(false)}>
                  Cancel
                </button>
                <button type="button" className="btn btn-danger" onClick={handleDeleteLead}>
                  Delete Lead
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Activity Modal */}
      {showAddActivityModal && (
        <div className="modal fade show" style={{ display: "block", backgroundColor: "rgba(0,0,0,0.5)" }}>
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Add Activity</h5>
                <button type="button" className="btn-close" onClick={() => setShowAddActivityModal(false)}></button>
              </div>
              <form onSubmit={handleActivitySubmit}>
                <div className="modal-body">
                  <div className="mb-3">
                    <label htmlFor="type" className="form-label">
                      Activity Type
                    </label>
                    <select
                      className="form-control"
                      id="type"
                      name="type"
                      value={activityValidation.values.type}
                      onChange={(e) => {
                        activityValidation.handleChange(e)
                        setActivityType(e.target.value)
                      }}
                    >
                      <option value="call">Call</option>
                      <option value="email">Email</option>
                      <option value="meeting">Meeting</option>
                      <option value="note">Note</option>
                    </select>
                  </div>

                  {activityType === "call" && (
                    <>
                      <div className="row">
                        <div className="col-md-6 mb-3">
                          <label htmlFor="date" className="form-label">
                            Call Date
                          </label>
                          <input
                            type="date"
                            className={`form-control ${activityValidation.touched.date && activityValidation.errors.date ? "is-invalid" : ""}`}
                            id="date"
                            name="date"
                            value={activityValidation.values.date}
                            onChange={activityValidation.handleChange}
                            onBlur={activityValidation.handleBlur}
                          />
                          {activityValidation.touched.date && activityValidation.errors.date && (
                            <div className="invalid-feedback">{activityValidation.errors.date}</div>
                          )}
                        </div>
                        <div className="col-md-6 mb-3">
                          <label htmlFor="time" className="form-label">
                            Call Time
                          </label>
                          <input
                            type="time"
                            className={`form-control ${activityValidation.touched.time && activityValidation.errors.time ? "is-invalid" : ""}`}
                            id="time"
                            name="time"
                            value={activityValidation.values.time}
                            onChange={activityValidation.handleChange}
                            onBlur={activityValidation.handleBlur}
                          />
                          {activityValidation.touched.time && activityValidation.errors.time && (
                            <div className="invalid-feedback">{activityValidation.errors.time}</div>
                          )}
                        </div>
                      </div>
                      <div className="mb-3">
                        <label htmlFor="duration" className="form-label">
                          Duration (minutes)
                        </label>
                        <input
                          type="number"
                          className="form-control"
                          id="duration"
                          name="duration"
                          min="1"
                          value={activityValidation.values.duration}
                          onChange={activityValidation.handleChange}
                        />
                      </div>
                      <div className="mb-3">
                        <label htmlFor="description" className="form-label">
                          Description
                        </label>
                        <textarea
                          className={`form-control ${activityValidation.touched.description && activityValidation.errors.description ? "is-invalid" : ""}`}
                          id="description"
                          name="description"
                          rows={3}
                          placeholder="Enter call details"
                          value={activityValidation.values.description}
                          onChange={activityValidation.handleChange}
                          onBlur={activityValidation.handleBlur}
                        ></textarea>
                        {activityValidation.touched.description && activityValidation.errors.description && (
                          <div className="invalid-feedback">{activityValidation.errors.description}</div>
                        )}
                      </div>
                      <div className="mb-3">
                        <label htmlFor="outcome" className="form-label">
                          Outcome
                        </label>
                        <select
                          className="form-control"
                          id="outcome"
                          name="outcome"
                          value={activityValidation.values.outcome}
                          onChange={activityValidation.handleChange}
                        >
                          <option value="Positive">Positive</option>
                          <option value="Neutral">Neutral</option>
                          <option value="Negative">Negative</option>
                          <option value="No Answer">No Answer</option>
                          <option value="Left Voicemail">Left Voicemail</option>
                        </select>
                      </div>
                    </>
                  )}

                  {activityType === "email" && (
                    <>
                      <div className="row">
                        <div className="col-md-6 mb-3">
                          <label htmlFor="date" className="form-label">
                            Email Date
                          </label>
                          <input
                            type="date"
                            className={`form-control ${activityValidation.touched.date && activityValidation.errors.date ? "is-invalid" : ""}`}
                            id="date"
                            name="date"
                            value={activityValidation.values.date}
                            onChange={activityValidation.handleChange}
                            onBlur={activityValidation.handleBlur}
                          />
                          {activityValidation.touched.date && activityValidation.errors.date && (
                            <div className="invalid-feedback">{activityValidation.errors.date}</div>
                          )}
                        </div>
                        <div className="col-md-6 mb-3">
                          <label htmlFor="time" className="form-label">
                            Email Time
                          </label>
                          <input
                            type="time"
                            className={`form-control ${activityValidation.touched.time && activityValidation.errors.time ? "is-invalid" : ""}`}
                            id="time"
                            name="time"
                            value={activityValidation.values.time}
                            onChange={activityValidation.handleChange}
                            onBlur={activityValidation.handleBlur}
                          />
                          {activityValidation.touched.time && activityValidation.errors.time && (
                            <div className="invalid-feedback">{activityValidation.errors.time}</div>
                          )}
                        </div>
                      </div>
                      <div className="mb-3">
                        <label htmlFor="subject" className="form-label">
                          Subject
                        </label>
                        <input
                          type="text"
                          className={`form-control ${activityValidation.touched.subject && activityValidation.errors.subject ? "is-invalid" : ""}`}
                          id="subject"
                          name="subject"
                          value={activityValidation.values.subject}
                          onChange={activityValidation.handleChange}
                          onBlur={activityValidation.handleBlur}
                        />
                        {activityValidation.touched.subject && activityValidation.errors.subject && (
                          <div className="invalid-feedback">{activityValidation.errors.subject}</div>
                        )}
                      </div>
                      <div className="mb-3">
                        <label htmlFor="content" className="form-label">
                          Content
                        </label>
                        <textarea
                          className="form-control"
                          id="content"
                          name="content"
                          rows={3}
                          placeholder="Enter email content"
                          value={activityValidation.values.content}
                          onChange={activityValidation.handleChange}
                        ></textarea>
                      </div>
                    </>
                  )}

                  {activityType === "meeting" && (
                    <>
                      <div className="row">
                        <div className="col-md-6 mb-3">
                          <label htmlFor="date" className="form-label">
                            Meeting Date
                          </label>
                          <input
                            type="date"
                            className="form-control"
                            id="date"
                            name="date"
                            value={activityValidation.values.date}
                            onChange={activityValidation.handleChange}
                          />
                        </div>
                        <div className="col-md-6 mb-3">
                          <label htmlFor="time" className="form-label">
                            Meeting Time
                          </label>
                          <input
                            type="time"
                            className="form-control"
                            id="time"
                            name="time"
                            value={activityValidation.values.time}
                            onChange={activityValidation.handleChange}
                          />
                        </div>
                      </div>
                      <div className="mb-3">
                        <label htmlFor="location" className="form-label">
                          Location
                        </label>
                        <input
                          type="text"
                          className="form-control"
                          id="location"
                          name="location"
                          placeholder="Enter meeting location"
                          value={activityValidation.values.location}
                          onChange={activityValidation.handleChange}
                        />
                      </div>
                      <div className="mb-3">
                        <label htmlFor="attendees" className="form-label">
                          Attendees
                        </label>
                        <input
                          type="text"
                          className="form-control"
                          id="attendees"
                          name="attendees"
                          placeholder="Enter attendees (comma-separated)"
                          value={activityValidation.values.attendees}
                          onChange={activityValidation.handleChange}
                        />
                      </div>
                      <div className="mb-3">
                        <label htmlFor="description" className="form-label">
                          Description
                        </label>
                        <textarea
                          className="form-control"
                          id="description"
                          name="description"
                          rows={3}
                          placeholder="Enter meeting details"
                          value={activityValidation.values.description}
                          onChange={activityValidation.handleChange}
                        ></textarea>
                      </div>
                    </>
                  )}

                  {activityType === "note" && (
                    <div className="mb-3">
                      <label htmlFor="description" className="form-label">
                        Note
                      </label>
                      <textarea
                        className={`form-control ${activityValidation.touched.description && activityValidation.errors.description ? "is-invalid" : ""}`}
                        id="description"
                        name="description"
                        rows={5}
                        placeholder="Enter your note"
                        value={activityValidation.values.description}
                        onChange={activityValidation.handleChange}
                        onBlur={activityValidation.handleBlur}
                      ></textarea>
                      {activityValidation.touched.description && activityValidation.errors.description && (
                        <div className="invalid-feedback">{activityValidation.errors.description}</div>
                      )}
                    </div>
                  )}
                </div>
                <div className="modal-footer">
                  <button type="button" className="btn btn-secondary" onClick={() => setShowAddActivityModal(false)}>
                    Cancel
                  </button>
                  <button type="submit" className="btn btn-primary">
                    Save Activity
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Add Task Modal */}
      {showAddTaskModal && (
        <div className="modal fade show" style={{ display: "block", backgroundColor: "rgba(0,0,0,0.5)" }}>
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Add Task</h5>
                <button type="button" className="btn-close" onClick={() => setShowAddTaskModal(false)}></button>
              </div>
              <form onSubmit={handleTaskSubmit}>
                <div className="modal-body">
                  <div className="mb-3">
                    <label htmlFor="title" className="form-label">
                      Title
                    </label>
                    <input
                      type="text"
                      className={`form-control ${taskValidation.touched.title && taskValidation.errors.title ? "is-invalid" : ""}`}
                      id="title"
                      name="title"
                      value={taskValidation.values.title}
                      onChange={taskValidation.handleChange}
                      onBlur={taskValidation.handleBlur}
                      placeholder="Enter task title"
                    />
                    {taskValidation.touched.title && taskValidation.errors.title && (
                      <div className="invalid-feedback">{taskValidation.errors.title}</div>
                    )}
                  </div>
                  <div className="row">
                    <div className="col-md-6 mb-3">
                      <label htmlFor="dueDate" className="form-label">
                        Due Date
                      </label>
                      <input
                        type="date"
                        className={`form-control ${taskValidation.touched.dueDate && taskValidation.errors.dueDate ? "is-invalid" : ""}`}
                        id="dueDate"
                        name="dueDate"
                        value={taskValidation.values.dueDate}
                        onChange={taskValidation.handleChange}
                        onBlur={taskValidation.handleBlur}
                      />
                      {taskValidation.touched.dueDate && taskValidation.errors.dueDate && (
                        <div className="invalid-feedback">{taskValidation.errors.dueDate}</div>
                      )}
                    </div>
                    <div className="col-md-6 mb-3">
                      <label htmlFor="priority" className="form-label">
                        Priority
                      </label>
                      <select
                        className="form-control"
                        id="priority"
                        name="priority"
                        value={taskValidation.values.priority}
                        onChange={taskValidation.handleChange}
                      >
                        <option value="High">High</option>
                        <option value="Medium">Medium</option>
                        <option value="Low">Low</option>
                      </select>
                    </div>
                  </div>
                  <div className="mb-3">
                    <label htmlFor="status" className="form-label">
                      Status
                    </label>
                    <select
                      className="form-control"
                      id="status"
                      name="status"
                      value={taskValidation.values.status}
                      onChange={taskValidation.handleChange}
                    >
                      <option value="Pending">Pending</option>
                      <option value="In Progress">In Progress</option>
                      <option value="Completed">Completed</option>
                      <option value="Cancelled">Cancelled</option>
                    </select>
                  </div>
                  <div className="mb-3">
                    <label htmlFor="assignedTo" className="form-label">
                      Assigned To
                    </label>
                    <select
                      className={`form-control ${taskValidation.touched.assignedTo && taskValidation.errors.assignedTo ? "is-invalid" : ""}`}
                      id="assignedTo"
                      name="assignedTo"
                      value={taskValidation.values.assignedTo}
                      onChange={taskValidation.handleChange}
                      onBlur={taskValidation.handleBlur}
                    >
                      {state.users.map((user) => (
                        <option key={user.id} value={user.id}>
                          {user.name}
                        </option>
                      ))}
                    </select>
                    {taskValidation.touched.assignedTo && taskValidation.errors.assignedTo && (
                      <div className="invalid-feedback">{taskValidation.errors.assignedTo}</div>
                    )}
                  </div>
                  <div className="mb-3">
                    <label htmlFor="description" className="form-label">
                      Description
                    </label>
                    <textarea
                      className="form-control"
                      id="description"
                      name="description"
                      rows={3}
                      placeholder="Enter task description"
                      value={taskValidation.values.description}
                      onChange={taskValidation.handleChange}
                    ></textarea>
                  </div>
                </div>
                <div className="modal-footer">
                  <button type="button" className="btn btn-secondary" onClick={() => setShowAddTaskModal(false)}>
                    Cancel
                  </button>
                  <button type="submit" className="btn btn-primary">
                    Save Task
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Upload Document Modal */}
      {showUploadModal && (
        <div className="modal fade show" style={{ display: "block", backgroundColor: "rgba(0,0,0,0.5)" }}>
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Upload Document</h5>
                <button type="button" className="btn-close" onClick={() => setShowUploadModal(false)}></button>
              </div>
              <form onSubmit={handleDocumentSubmit}>
                <div className="modal-body">
                  <div className="mb-3">
                    <label htmlFor="name" className="form-label">
                      Document Name
                    </label>
                    <input
                      type="text"
                      className={`form-control ${documentValidation.touched.name && documentValidation.errors.name ? "is-invalid" : ""}`}
                      id="name"
                      name="name"
                      value={documentValidation.values.name}
                      onChange={documentValidation.handleChange}
                      onBlur={documentValidation.handleBlur}
                      placeholder="Enter document name"
                    />
                    {documentValidation.touched.name && documentValidation.errors.name && (
                      <div className="invalid-feedback">{documentValidation.errors.name}</div>
                    )}
                  </div>
                  <div className="mb-3">
                    <label htmlFor="type" className="form-label">
                      Document Type
                    </label>
                    <select
                      className="form-control"
                      id="type"
                      name="type"
                      value={documentValidation.values.type}
                      onChange={documentValidation.handleChange}
                    >
                      <option value="PDF">PDF</option>
                      <option value="DOCX">DOCX</option>
                      <option value="TXT">TXT</option>
                      <option value="CSV">CSV</option>
                      <option value="XLSX">XLSX</option>
                    </select>
                  </div>
                  <div className="mb-3">
                    <label htmlFor="description" className="form-label">
                      Description
                    </label>
                    <textarea
                      className="form-control"
                      id="description"
                      name="description"
                      rows={3}
                      placeholder="Enter document description"
                      value={documentValidation.values.description}
                      onChange={documentValidation.handleChange}
                    ></textarea>
                  </div>
                  <div className="mb-3">
                    <label htmlFor="file" className="form-label">
                      Choose File
                    </label>
                    <input type="file" className="form-control" id="file" name="file" disabled />
                    <p className="text-muted mt-2">Note: File upload functionality is not implemented in this demo.</p>
                  </div>
                </div>
                <div className="modal-footer">
                  <button type="button" className="btn btn-secondary" onClick={() => setShowUploadModal(false)}>
                    Cancel
                  </button>
                  <button type="submit" className="btn btn-primary">
                    Upload Document
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

