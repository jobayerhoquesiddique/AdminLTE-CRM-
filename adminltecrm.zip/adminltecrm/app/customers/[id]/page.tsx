import Link from "next/link"

export default function CustomerDetail({ params }: { params: { id: string } }) {
  // In a real application, you would fetch customer data based on the ID
  const customer = {
    id: params.id,
    name: "John Smith",
    company: "Acme Inc.",
    email: "john@acme.com",
    phone: "(123) 456-7890",
    address: "123 Main St, Anytown, USA",
    status: "Active",
    created: "Jan 15, 2023",
    notes: "Key decision maker for enterprise accounts.",
    deals: [
      { id: 1, name: "Enterprise Software Package", value: "$15,000", status: "Closed Won" },
      { id: 2, name: "Support Contract", value: "$5,000", status: "Negotiation" },
    ],
    activities: [
      { id: 1, type: "Call", date: "Mar 15, 2023", description: "Discussed renewal options" },
      { id: 2, type: "Email", date: "Mar 10, 2023", description: "Sent proposal" },
      { id: 3, type: "Meeting", date: "Feb 28, 2023", description: "Initial consultation" },
    ],
  }

  return (
    <div className="row">
      <div className="col-md-4">
        <div className="card card-primary card-outline">
          <div className="card-body box-profile">
            <div className="text-center">
              <img
                className="profile-user-img img-fluid img-circle"
                src="/placeholder.svg?height=128&width=128"
                alt="Customer profile picture"
              />
            </div>
            <h3 className="profile-username text-center">{customer.name}</h3>
            <p className="text-muted text-center">{customer.company}</p>
            <ul className="list-group list-group-unbordered mb-3">
              <li className="list-group-item">
                <b>Email</b> <a className="float-end">{customer.email}</a>
              </li>
              <li className="list-group-item">
                <b>Phone</b> <a className="float-end">{customer.phone}</a>
              </li>
              <li className="list-group-item">
                <b>Status</b> <span className="float-end badge bg-success">{customer.status}</span>
              </li>
              <li className="list-group-item">
                <b>Customer Since</b> <a className="float-end">{customer.created}</a>
              </li>
            </ul>
            <Link href={`/customers/edit/${customer.id}`} className="btn btn-primary btn-block">
              <i className="bi bi-pencil"></i> Edit
            </Link>
          </div>
        </div>

        <div className="card card-primary">
          <div className="card-header">
            <h3 className="card-title">About {customer.name}</h3>
          </div>
          <div className="card-body">
            <strong>
              <i className="bi bi-map-marker me-1"></i> Address
            </strong>
            <p className="text-muted">{customer.address}</p>
            <hr />
            <strong>
              <i className="bi bi-pencil me-1"></i> Notes
            </strong>
            <p className="text-muted">{customer.notes}</p>
          </div>
        </div>
      </div>

      <div className="col-md-8">
        <div className="card">
          <div className="card-header p-2">
            <ul className="nav nav-pills">
              <li className="nav-item">
                <a className="nav-link active" href="#deals" data-bs-toggle="tab">
                  Deals
                </a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="#activities" data-bs-toggle="tab">
                  Activities
                </a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="#timeline" data-bs-toggle="tab">
                  Timeline
                </a>
              </li>
            </ul>
          </div>
          <div className="card-body">
            <div className="tab-content">
              <div className="active tab-pane" id="deals">
                <div className="table-responsive">
                  <table className="table table-striped">
                    <thead>
                      <tr>
                        <th>Deal</th>
                        <th>Value</th>
                        <th>Status</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {customer.deals.map((deal) => (
                        <tr key={deal.id}>
                          <td>{deal.name}</td>
                          <td>{deal.value}</td>
                          <td>
                            <span className={`badge ${deal.status === "Closed Won" ? "bg-success" : "bg-warning"}`}>
                              {deal.status}
                            </span>
                          </td>
                          <td>
                            <Link href={`/deals/${deal.id}`} className="btn btn-info btn-sm me-1">
                              <i className="bi bi-eye"></i>
                            </Link>
                            <Link href={`/deals/edit/${deal.id}`} className="btn btn-primary btn-sm">
                              <i className="bi bi-pencil"></i>
                            </Link>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="mt-3">
                  <Link href={`/deals/new?customer=${customer.id}`} className="btn btn-primary">
                    <i className="bi bi-plus"></i> Add New Deal
                  </Link>
                </div>
              </div>

              <div className="tab-pane" id="activities">
                <div className="table-responsive">
                  <table className="table table-striped">
                    <thead>
                      <tr>
                        <th>Type</th>
                        <th>Date</th>
                        <th>Description</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {customer.activities.map((activity) => (
                        <tr key={activity.id}>
                          <td>{activity.type}</td>
                          <td>{activity.date}</td>
                          <td>{activity.description}</td>
                          <td>
                            <button className="btn btn-info btn-sm me-1">
                              <i className="bi bi-eye"></i>
                            </button>
                            <button className="btn btn-primary btn-sm">
                              <i className="bi bi-pencil"></i>
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="mt-3">
                  <Link href={`/activities/new?customer=${customer.id}`} className="btn btn-primary">
                    <i className="bi bi-plus"></i> Add New Activity
                  </Link>
                </div>
              </div>

              <div className="tab-pane" id="timeline">
                <div className="timeline timeline-inverse">
                  <div className="time-label">
                    <span className="bg-danger">10 Mar 2023</span>
                  </div>
                  <div>
                    <i className="bi bi-envelope bg-primary"></i>
                    <div className="timeline-item">
                      <span className="time">
                        <i className="bi bi-clock"></i> 12:05
                      </span>
                      <h3 className="timeline-header">
                        <a href="#">Support Team</a> sent an email
                      </h3>
                      <div className="timeline-body">Sent proposal for the new support contract</div>
                    </div>
                  </div>
                  <div>
                    <i className="bi bi-person bg-info"></i>
                    <div className="timeline-item">
                      <span className="time">
                        <i className="bi bi-clock"></i> 5 hours ago
                      </span>
                      <h3 className="timeline-header">
                        <a href="#">Sarah</a> updated customer information
                      </h3>
                    </div>
                  </div>
                  <div className="time-label">
                    <span className="bg-success">28 Feb 2023</span>
                  </div>
                  <div>
                    <i className="bi bi-calendar bg-warning"></i>
                    <div className="timeline-item">
                      <span className="time">
                        <i className="bi bi-clock"></i> 2:00 pm
                      </span>
                      <h3 className="timeline-header">
                        <a href="#">Meeting</a> with customer
                      </h3>
                      <div className="timeline-body">Initial consultation about their needs</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

