"use client"

import type React from "react"

// Import the custom hook for calendar libraries
import { useCalendarLibraries } from "@/lib/hooks/useCalendarLibraries"
import { useState, useEffect } from "react"
import { useCrm } from "@/lib/context/CrmContext"
import { LoadingSpinner } from "@/components/ui/loading-spinner"
import type { EventInput } from "@fullcalendar/core"

export default function Calendar() {
  const { state, dispatch, generateId } = useCrm()
  const { events, customers, leads, isLoading } = state
  const [calendarInitialized, setCalendarInitialized] = useState(false)
  const [eventForm, setEventForm] = useState({
    title: "",
    start: "",
    end: "",
    allDay: false,
    type: "Meeting",
    description: "",
    relatedTo: { type: "none", id: "" },
    assignedTo: "user1",
  })
  const [selectedEvent, setSelectedEvent] = useState<string | null>(null)
  const [showEventModal, setShowEventModal] = useState(false)
  const [filterTypes, setFilterTypes] = useState({
    meetings: true,
    calls: true,
    tasks: true,
    reminders: true,
  })

  // Use the custom hook to load calendar libraries
  const { allLibrariesLoaded, error } = useCalendarLibraries()

  useEffect(() => {
    // Initialize calendar when libraries are loaded
    if (allLibrariesLoaded && !calendarInitialized && !isLoading) {
      initializeCalendar()
    }
  }, [allLibrariesLoaded, calendarInitialized, isLoading, events, filterTypes])

  // Function to initialize the calendar
  const initializeCalendar = async () => {
    try {
      // Import FullCalendar core and plugins
      const { Calendar } = await import("@fullcalendar/core")
      const dayGridPlugin = (await import("@fullcalendar/daygrid")).default
      const timeGridPlugin = (await import("@fullcalendar/timegrid")).default
      const interactionPlugin = (await import("@fullcalendar/interaction")).default

      // Get filtered events based on type filters
      const filteredEvents = events.filter((event) => {
        if (event.type === "Meeting" && filterTypes.meetings) return true
        if (event.type === "Call" && filterTypes.calls) return true
        if (event.type === "Task" && filterTypes.tasks) return true
        if (event.type === "Reminder" && filterTypes.reminders) return true
        return false
      })

      // Map events to FullCalendar format
      const calendarEvents: EventInput[] = filteredEvents.map((event) => ({
        id: event.id,
        title: event.title,
        start: event.start,
        end: event.end,
        allDay: event.allDay,
        backgroundColor: getEventColor(event.type),
        borderColor: getEventColor(event.type),
        extendedProps: {
          type: event.type,
          description: event.description,
          relatedTo: event.relatedTo,
          assignedTo: event.assignedTo,
        },
      }))

      // Initialize calendar
      const calendarEl = document.getElementById("calendar")
      if (calendarEl) {
        try {
          const calendar = new Calendar(calendarEl, {
            plugins: [dayGridPlugin, timeGridPlugin, interactionPlugin],
            initialView: "dayGridMonth",
            headerToolbar: {
              left: "prev,next today",
              center: "title",
              right: "dayGridMonth,timeGridWeek,timeGridDay",
            },
            events: calendarEvents,
            editable: true,
            selectable: true,
            selectMirror: true,
            dayMaxEvents: true,
            select: (arg) => {
              // Open event form with selected dates
              setEventForm({
                ...eventForm,
                start: arg.startStr,
                end: arg.endStr || arg.startStr, // Ensure end date exists
                allDay: arg.allDay,
              })
              setSelectedEvent(null)
              setShowEventModal(true)
            },
            eventClick: (arg) => {
              // Find the clicked event
              const eventId = arg.event.id
              const event = events.find((e) => e.id === eventId)
              if (event) {
                // Set form values for editing
                setEventForm({
                  title: event.title,
                  start: event.start,
                  end: event.end,
                  allDay: event.allDay,
                  type: event.type,
                  description: event.description,
                  relatedTo: event.relatedTo,
                  assignedTo: event.assignedTo,
                })
                setSelectedEvent(eventId)
                setShowEventModal(true)
              }
            },
            eventDrop: (arg) => {
              // Update event when dragged and dropped
              const eventId = arg.event.id
              const updatedEvent = {
                id: eventId,
                title: arg.event.title,
                start: arg.event.startStr,
                end: arg.event.endStr || arg.event.startStr, // Ensure end date exists
                allDay: arg.event.allDay,
                type: arg.event.extendedProps?.type || "Meeting",
                description: arg.event.extendedProps?.description || "",
                relatedTo: arg.event.extendedProps?.relatedTo || { type: "none", id: "" },
                assignedTo: arg.event.extendedProps?.assignedTo || "user1",
              }
              dispatch({ type: "UPDATE_EVENT", payload: updatedEvent })
            },
            eventResize: (arg) => {
              // Update event when resized
              const eventId = arg.event.id
              const updatedEvent = {
                id: eventId,
                title: arg.event.title,
                start: arg.event.startStr,
                end: arg.event.endStr,
                allDay: arg.event.allDay,
                type: arg.event.extendedProps?.type || "Meeting",
                description: arg.event.extendedProps?.description || "",
                relatedTo: arg.event.extendedProps?.relatedTo || { type: "none", id: "" },
                assignedTo: arg.event.extendedProps?.assignedTo || "user1",
              }
              dispatch({ type: "UPDATE_EVENT", payload: updatedEvent })
            },
          })

          calendar.render()
          setCalendarInitialized(true)
        } catch (error) {
          console.error("Error initializing calendar:", error)
        }
      }
    } catch (error) {
      console.error("Error loading FullCalendar:", error)
    }
  }

  // Helper function to get event color based on type
  const getEventColor = (type: string) => {
    switch (type) {
      case "Meeting":
        return "#0d6efd" // primary
      case "Call":
        return "#20c997" // success
      case "Task":
        return "#ffc107" // warning
      case "Reminder":
        return "#6c757d" // secondary
      default:
        return "#0d6efd" // primary
    }
  }

  // Handle form input changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target
    if (type === "checkbox") {
      const target = e.target as HTMLInputElement
      setEventForm({ ...eventForm, [name]: target.checked })
    } else {
      setEventForm({ ...eventForm, [name]: value })
    }
  }

  // Handle related entity type change
  const handleRelatedTypeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setEventForm({
      ...eventForm,
      relatedTo: { type: e.target.value, id: "" },
    })
  }

  // Handle related entity id change
  const handleRelatedIdChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setEventForm({
      ...eventForm,
      relatedTo: { ...eventForm.relatedTo, id: e.target.value },
    })
  }

  // Handle form submission with validation
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Validate dates
    const startDate = new Date(eventForm.start)
    const endDate = new Date(eventForm.end)

    if (endDate < startDate) {
      alert("End date cannot be before start date")
      return
    }

    try {
      if (selectedEvent) {
        // Update existing event
        const updatedEvent = {
          id: selectedEvent,
          ...eventForm,
        }
        dispatch({ type: "UPDATE_EVENT", payload: updatedEvent })
      } else {
        // Create new event
        const newEvent = {
          id: generateId(),
          ...eventForm,
        }
        dispatch({ type: "ADD_EVENT", payload: newEvent })
      }

      // Reset form and close modal
      setEventForm({
        title: "",
        start: "",
        end: "",
        allDay: false,
        type: "Meeting",
        description: "",
        relatedTo: { type: "none", id: "" },
        assignedTo: "user1",
      })
      setSelectedEvent(null)
      setShowEventModal(false)
    } catch (error) {
      console.error("Error saving event:", error)
      alert("There was an error saving the event. Please try again.")
    }
  }

  // Handle event deletion
  const handleDeleteEvent = () => {
    if (selectedEvent) {
      dispatch({ type: "DELETE_EVENT", payload: selectedEvent })
      setShowEventModal(false)
    }
  }

  // Handle filter changes
  const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { id, checked } = e.target
    setFilterTypes({ ...filterTypes, [id]: checked })

    // Reset calendar when filters change
    if (calendarInitialized) {
      setCalendarInitialized(false)
    }
  }

  if (isLoading) {
    return <LoadingSpinner />
  }

  if (error) {
    return (
      <div className="alert alert-danger">
        <h4 className="alert-heading">Error Loading Calendar</h4>
        <p>{error}</p>
        <hr />
        <p className="mb-0">Please refresh the page or try again later.</p>
      </div>
    )
  }

  return (
    <div className="row">
      <div className="col-md-3">
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Create Event</h3>
          </div>
          <div className="card-body">
            <div className="form-group mb-3">
              <label htmlFor="quickEventTitle">Quick Event</label>
              <div className="input-group">
                <input type="text" className="form-control" id="quickEventTitle" placeholder="Enter title" />
                <button
                  className="btn btn-primary"
                  onClick={() => {
                    const titleInput = document.getElementById("quickEventTitle") as HTMLInputElement
                    const title = titleInput?.value
                    if (title) {
                      const today = new Date().toISOString().split("T")[0]
                      setEventForm({
                        title,
                        start: today,
                        end: today,
                        allDay: true,
                        type: "Task",
                        description: "",
                        relatedTo: { type: "none", id: "" },
                        assignedTo: "user1",
                      })
                      setSelectedEvent(null)
                      setShowEventModal(true)
                      // Clear the input
                      if (titleInput) titleInput.value = ""
                    }
                  }}
                >
                  Add
                </button>
              </div>
            </div>
            <button
              className="btn btn-success btn-block mb-3"
              onClick={() => {
                const now = new Date()
                const start = now.toISOString().slice(0, 16)
                now.setHours(now.getHours() + 1)
                const end = now.toISOString().slice(0, 16)

                setEventForm({
                  title: "",
                  start,
                  end,
                  allDay: false,
                  type: "Meeting",
                  description: "",
                  relatedTo: { type: "none", id: "" },
                  assignedTo: "user1",
                })
                setSelectedEvent(null)
                setShowEventModal(true)
              }}
            >
              <i className="bi bi-plus-circle me-2"></i>
              Create New Event
            </button>
          </div>
        </div>
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Filters</h3>
          </div>
          <div className="card-body">
            <div className="form-group">
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="checkbox"
                  id="meetings"
                  checked={filterTypes.meetings}
                  onChange={handleFilterChange}
                />
                <label className="form-check-label" htmlFor="meetings">
                  <span className="badge bg-primary me-1">•</span> Meetings
                </label>
              </div>
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="checkbox"
                  id="calls"
                  checked={filterTypes.calls}
                  onChange={handleFilterChange}
                />
                <label className="form-check-label" htmlFor="calls">
                  <span className="badge bg-success me-1">•</span> Calls
                </label>
              </div>
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="checkbox"
                  id="tasks"
                  checked={filterTypes.tasks}
                  onChange={handleFilterChange}
                />
                <label className="form-check-label" htmlFor="tasks">
                  <span className="badge bg-warning me-1">•</span> Tasks
                </label>
              </div>
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="checkbox"
                  id="reminders"
                  checked={filterTypes.reminders}
                  onChange={handleFilterChange}
                />
                <label className="form-check-label" htmlFor="reminders">
                  <span className="badge bg-secondary me-1">•</span> Reminders
                </label>
              </div>
            </div>
          </div>
        </div>
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Upcoming Events</h3>
          </div>
          <div className="card-body p-0">
            <ul className="list-group list-group-flush">
              {events
                .filter((event) => new Date(event.start) >= new Date())
                .sort((a, b) => new Date(a.start).getTime() - new Date(b.start).getTime())
                .slice(0, 5)
                .map((event) => {
                  const eventDate = new Date(event.start)
                  const formattedDate = eventDate.toLocaleDateString()
                  const formattedTime = event.allDay
                    ? "All Day"
                    : eventDate.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })

                  let relatedEntity = ""
                  if (event.relatedTo.type === "customer") {
                    const customer = customers.find((c) => c.id === event.relatedTo.id)
                    relatedEntity = customer ? customer.name : ""
                  } else if (event.relatedTo.type === "lead") {
                    const lead = leads.find((l) => l.id === event.relatedTo.id)
                    relatedEntity = lead ? lead.name : ""
                  }

                  return (
                    <li key={event.id} className="list-group-item">
                      <div className="d-flex w-100 justify-content-between">
                        <h5 className="mb-1">{event.title}</h5>
                        <small>
                          {formattedDate}, {formattedTime}
                        </small>
                      </div>
                      <p className="mb-1">{event.description}</p>
                      <small className="text-muted">
                        {relatedEntity && (
                          <>
                            <i className={event.relatedTo.type === "customer" ? "bi bi-building" : "bi bi-person"}></i>{" "}
                            {relatedEntity} |
                          </>
                        )}
                        <i className="bi bi-person"></i>{" "}
                        {event.assignedTo === "user1"
                          ? "John Doe"
                          : event.assignedTo === "user2"
                            ? "Sarah Johnson"
                            : event.assignedTo === "user3"
                              ? "Michael Brown"
                              : "Unknown"}
                      </small>
                    </li>
                  )
                })}
              {events.filter((event) => new Date(event.start) >= new Date()).length === 0 && (
                <li className="list-group-item text-center">No upcoming events</li>
              )}
            </ul>
          </div>
        </div>
      </div>
      <div className="col-md-9">
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Calendar</h3>
            <div className="card-tools">
              <div className="btn-group">
                <button type="button" className="btn btn-sm btn-primary">
                  Month
                </button>
                <button type="button" className="btn btn-sm btn-default">
                  Week
                </button>
                <button type="button" className="btn btn-sm btn-default">
                  Day
                </button>
              </div>
            </div>
          </div>
          <div className="card-body">
            {!allLibrariesLoaded || !calendarInitialized ? (
              <div className="d-flex justify-content-center align-items-center" style={{ height: "600px" }}>
                <div className="spinner-border text-primary" role="status">
                  <span className="visually-hidden">Loading...</span>
                </div>
              </div>
            ) : (
              <div id="calendar" style={{ height: "600px" }}></div>
            )}
          </div>
        </div>
      </div>

      {/* Event Modal */}
      {showEventModal && (
        <div className="modal fade show" style={{ display: "block", backgroundColor: "rgba(0,0,0,0.5)" }}>
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">{selectedEvent ? "Edit Event" : "Create Event"}</h5>
                <button type="button" className="btn-close" onClick={() => setShowEventModal(false)}></button>
              </div>
              <form onSubmit={handleSubmit}>
                <div className="modal-body">
                  <div className="form-group mb-3">
                    <label htmlFor="title">Event Title</label>
                    <input
                      type="text"
                      className="form-control"
                      id="title"
                      name="title"
                      value={eventForm.title}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  <div className="row mb-3">
                    <div className="col-md-6">
                      <div className="form-group">
                        <label htmlFor="start">Start Date/Time</label>
                        <input
                          type="datetime-local"
                          className="form-control"
                          id="start"
                          name="start"
                          value={eventForm.start}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="form-group">
                        <label htmlFor="end">End Date/Time</label>
                        <input
                          type="datetime-local"
                          className="form-control"
                          id="end"
                          name="end"
                          value={eventForm.end}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-check mb-3">
                    <input
                      type="checkbox"
                      className="form-check-input"
                      id="allDay"
                      name="allDay"
                      checked={eventForm.allDay}
                      onChange={handleInputChange}
                    />
                    <label className="form-check-label" htmlFor="allDay">
                      All Day Event
                    </label>
                  </div>
                  <div className="form-group mb-3">
                    <label htmlFor="type">Event Type</label>
                    <select
                      className="form-control"
                      id="type"
                      name="type"
                      value={eventForm.type}
                      onChange={handleInputChange}
                    >
                      <option value="Meeting">Meeting</option>
                      <option value="Call">Call</option>
                      <option value="Task">Task</option>
                      <option value="Reminder">Reminder</option>
                    </select>
                  </div>
                  <div className="row mb-3">
                    <div className="col-md-6">
                      <div className="form-group">
                        <label htmlFor="relatedType">Related To</label>
                        <select
                          className="form-control"
                          id="relatedType"
                          value={eventForm.relatedTo.type}
                          onChange={handleRelatedTypeChange}
                        >
                          <option value="none">None</option>
                          <option value="customer">Customer</option>
                          <option value="lead">Lead</option>
                          <option value="deal">Deal</option>
                          <option value="other">Other</option>
                        </select>
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="form-group">
                        <label htmlFor="relatedId">
                          Select {eventForm.relatedTo.type !== "none" ? eventForm.relatedTo.type : "entity"}
                        </label>
                        <select
                          className="form-control"
                          id="relatedId"
                          value={eventForm.relatedTo.id}
                          onChange={handleRelatedIdChange}
                          disabled={eventForm.relatedTo.type === "none" || eventForm.relatedTo.type === "other"}
                        >
                          <option value="">Select...</option>
                          {eventForm.relatedTo.type === "customer" &&
                            customers.map((customer) => (
                              <option key={customer.id} value={customer.id}>
                                {customer.name}
                              </option>
                            ))}
                          {eventForm.relatedTo.type === "lead" &&
                            leads.map((lead) => (
                              <option key={lead.id} value={lead.id}>
                                {lead.name}
                              </option>
                            ))}
                        </select>
                      </div>
                    </div>
                  </div>
                  <div className="form-group mb-3">
                    <label htmlFor="assignedTo">Assigned To</label>
                    <select
                      className="form-control"
                      id="assignedTo"
                      name="assignedTo"
                      value={eventForm.assignedTo}
                      onChange={handleInputChange}
                    >
                      <option value="user1">John Doe</option>
                      <option value="user2">Sarah Johnson</option>
                      <option value="user3">Michael Brown</option>
                    </select>
                  </div>
                  <div className="form-group mb-3">
                    <label htmlFor="description">Description</label>
                    <textarea
                      className="form-control"
                      id="description"
                      name="description"
                      rows={3}
                      value={eventForm.description}
                      onChange={handleInputChange}
                    ></textarea>
                  </div>
                </div>
                <div className="modal-footer">
                  {selectedEvent && (
                    <button type="button" className="btn btn-danger me-auto" onClick={handleDeleteEvent}>
                      Delete
                    </button>
                  )}
                  <button type="button" className="btn btn-secondary" onClick={() => setShowEventModal(false)}>
                    Cancel
                  </button>
                  <button type="submit" className="btn btn-primary">
                    {selectedEvent ? "Update" : "Create"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

