/**
 * Utility function to convert paths to HTML-compatible paths.
 * @param {string} path - The base path.
 * @returns {string} - The converted HTML path.
 */
export function convertPathToHtml(path) {
  return path.replace(/\/dist$/, '');
}

/**
 * Utility function to debounce a function.
 * @param {Function} func - The function to debounce.
 * @param {number} wait - The debounce delay in milliseconds.
 * @returns {Function} - The debounced function.
 */
export function debounce(func, wait) {
  let timeout;
  return function (...args) {
    clearTimeout(timeout);
    timeout = setTimeout(() => func.apply(this, args), wait);
  };
}

/**
 * Utility function to check if an element is visible in the viewport.
 * @param {HTMLElement} element - The element to check.
 * @returns {boolean} - True if visible, false otherwise.
 */
export function isElementInViewport(element) {
  const rect = element.getBoundingClientRect();
  return (
    rect.top >= 0 &&
    rect.left >= 0 &&
    rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
    rect.right <= (window.innerWidth || document.documentElement.clientWidth)
  );
}
