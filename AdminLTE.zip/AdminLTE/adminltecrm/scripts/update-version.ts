import * as fs from "fs"
import * as path from "path"

// Get the new version from command line arguments or increment patch version
const getNewVersion = () => {
  const args = process.argv.slice(2)
  if (args.length > 0) {
    return args[0]
  }

  // Read current version from package.json
  const packageJsonPath = path.join(__dirname, "..", "package.json")
  const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, "utf8"))
  const currentVersion = packageJson.version || "1.0.0"

  // Increment patch version
  const versionParts = currentVersion.split(".")
  versionParts[2] = (Number.parseInt(versionParts[2]) + 1).toString()
  return versionParts.join(".")
}

// Update version in package.json
const updatePackageJson = (newVersion: string) => {
  const packageJsonPath = path.join(__dirname, "..", "package.json")
  const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, "utf8"))
  packageJson.version = newVersion
  fs.writeFileSync(packageJsonPath, JSON.stringify(packageJson, null, 2))
  console.log(`Updated package.json to version ${newVersion}`)
}

// Update version in index.html
const updateIndexHtml = (newVersion: string) => {
  const indexHtmlPath = path.join(__dirname, "..", "public", "index.html")
  if (!fs.existsSync(indexHtmlPath)) {
    console.error("index.html not found")
    return
  }

  let htmlContent = fs.readFileSync(indexHtmlPath, "utf8")

  // Update version number
  htmlContent = htmlContent.replace(
    /<p>Version: .*? \| Last Updated: .*?<\/p>/,
    `<p>Version: ${newVersion} | Last Updated: ${getCurrentDate()}</p>`,
  )

  fs.writeFileSync(indexHtmlPath, htmlContent)
  console.log(`Updated index.html to version ${newVersion}`)
}

// Get current date in format: Month Day, Year
const getCurrentDate = () => {
  const date = new Date()
  return date.toLocaleDateString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
  })
}

// Update README.md
const updateReadme = (newVersion: string) => {
  const readmePath = path.join(__dirname, "..", "README.md")
  if (!fs.existsSync(readmePath)) {
    console.error("README.md not found")
    return
  }

  let readmeContent = fs.readFileSync(readmePath, "utf8")

  // Update version number
  readmeContent = readmeContent.replace(/Current version: .*?/, `Current version: ${newVersion}`)

  // Update last updated date
  readmeContent = readmeContent.replace(/Last updated: .*?/, `Last updated: ${getCurrentDate()}`)

  fs.writeFileSync(readmePath, readmeContent)
  console.log(`Updated README.md to version ${newVersion}`)
}

// Main function
const main = () => {
  const newVersion = getNewVersion()
  updatePackageJson(newVersion)
  updateIndexHtml(newVersion)
  updateReadme(newVersion)
  console.log(`Version updated to ${newVersion}`)
}

// Run the script
main()

