import type React from "react"
import Link from "next/link"

export const Header: React.FC = () => {
  return (
    <nav className="main-header navbar navbar-expand navbar-white navbar-light">
      {/* Left navbar links */}
      <ul className="navbar-nav">
        <li className="nav-item">
          <a className="nav-link" data-lte-toggle="sidebar-full" href="#" role="button">
            <i className="bi bi-list"></i>
          </a>
        </li>
        <li className="nav-item d-none d-sm-inline-block">
          <Link href="/" className="nav-link">
            Home
          </Link>
        </li>
        <li className="nav-item d-none d-sm-inline-block">
          <Link href="/support" className="nav-link">
            Support
          </Link>
        </li>
      </ul>

      {/* Right navbar links */}
      <ul className="navbar-nav ms-auto">
        {/* Navbar Search */}
        <li className="nav-item">
          <a className="nav-link" data-lte-toggle="navbar-search" href="#" role="button">
            <i className="bi bi-search"></i>
          </a>
          <div className="navbar-search-block">
            <form className="form-inline">
              <div className="input-group input-group-sm">
                <input
                  className="form-control form-control-navbar"
                  type="search"
                  placeholder="Search"
                  aria-label="Search"
                />
                <div className="input-group-append">
                  <button className="btn btn-navbar" type="submit">
                    <i className="bi bi-search"></i>
                  </button>
                  <button className="btn btn-navbar" type="button" data-lte-toggle="navbar-search">
                    <i className="bi bi-x"></i>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </li>

        {/* Messages Dropdown Menu */}
        <li className="nav-item dropdown">
          <a className="nav-link" data-bs-toggle="dropdown" href="#">
            <i className="bi bi-chat-text"></i>
            <span className="badge bg-danger navbar-badge">3</span>
          </a>
          <div className="dropdown-menu dropdown-menu-lg dropdown-menu-end">
            <a href="#" className="dropdown-item">
              {/* Message Start */}
              <div className="media">
                <img
                  src="/placeholder.svg?height=128&width=128"
                  alt="User Avatar"
                  className="img-size-50 img-circle me-3"
                />
                <div className="media-body">
                  <h3 className="dropdown-item-title">
                    Brad Diesel
                    <span className="float-end text-sm text-danger">
                      <i className="bi bi-star-fill"></i>
                    </span>
                  </h3>
                  <p className="text-sm">Call me whenever you can...</p>
                  <p className="text-sm text-muted">
                    <i className="bi bi-clock me-1"></i> 4 Hours Ago
                  </p>
                </div>
              </div>
              {/* Message End */}
            </a>
            <div className="dropdown-divider"></div>
            <a href="#" className="dropdown-item">
              {/* Message Start */}
              <div className="media">
                <img
                  src="/placeholder.svg?height=128&width=128"
                  alt="User Avatar"
                  className="img-size-50 img-circle me-3"
                />
                <div className="media-body">
                  <h3 className="dropdown-item-title">
                    John Pierce
                    <span className="float-end text-sm text-muted">
                      <i className="bi bi-star-fill"></i>
                    </span>
                  </h3>
                  <p className="text-sm">I got your message bro</p>
                  <p className="text-sm text-muted">
                    <i className="bi bi-clock me-1"></i> 4 Hours Ago
                  </p>
                </div>
              </div>
              {/* Message End */}
            </a>
            <div className="dropdown-divider"></div>
            <a href="#" className="dropdown-item">
              {/* Message Start */}
              <div className="media">
                <img
                  src="/placeholder.svg?height=128&width=128"
                  alt="User Avatar"
                  className="img-size-50 img-circle me-3"
                />
                <div className="media-body">
                  <h3 className="dropdown-item-title">
                    Nora Silvester
                    <span className="float-end text-sm text-warning">
                      <i className="bi bi-star-fill"></i>
                    </span>
                  </h3>
                  <p className="text-sm">The subject goes here</p>
                  <p className="text-sm text-muted">
                    <i className="bi bi-clock me-1"></i> 4 Hours Ago
                  </p>
                </div>
              </div>
              {/* Message End */}
            </a>
            <div className="dropdown-divider"></div>
            <a href="#" className="dropdown-item dropdown-footer">
              See All Messages
            </a>
          </div>
        </li>
        {/* Notifications Dropdown Menu */}
        <li className="nav-item dropdown">
          <a className="nav-link" data-bs-toggle="dropdown" href="#">
            <i className="bi bi-bell"></i>
            <span className="badge bg-warning navbar-badge">15</span>
          </a>
          <div className="dropdown-menu dropdown-menu-lg dropdown-menu-end">
            <span className="dropdown-item dropdown-header">15 Notifications</span>
            <div className="dropdown-divider"></div>
            <a href="#" className="dropdown-item">
              <i className="bi bi-envelope me-2"></i> 4 new messages
              <span className="float-end text-muted text-sm">3 mins</span>
            </a>
            <div className="dropdown-divider"></div>
            <a href="#" className="dropdown-item">
              <i className="bi bi-people me-2"></i> 8 friend requests
              <span className="float-end text-muted text-sm">12 hours</span>
            </a>
            <div className="dropdown-divider"></div>
            <a href="#" className="dropdown-item">
              <i className="bi bi-file-earmark me-2"></i> 3 new reports
              <span className="float-end text-muted text-sm">2 days</span>
            </a>
            <div className="dropdown-divider"></div>
            <a href="#" className="dropdown-item dropdown-footer">
              See All Notifications
            </a>
          </div>
        </li>
        <li className="nav-item dropdown user-menu">
          <a href="#" className="nav-link dropdown-toggle" data-bs-toggle="dropdown">
            <img src="/images/profile.jpg" className="user-image img-circle elevation-2" alt="User Image" />
            <span className="d-none d-md-inline">Jobayer Hoque Siddique</span>
          </a>
          <ul className="dropdown-menu dropdown-menu-lg dropdown-menu-end">
            {/* User image */}
            <li className="user-header bg-primary">
              <img src="/images/profile.jpg" className="img-circle elevation-2" alt="User Image" />
              <p>
                Jobayer Hoque Siddique - Administrator
                <small>Member since Jan. 2023</small>
              </p>
            </li>
            {/* Menu Body */}
            <li className="user-body">
              <div className="row">
                <div className="col-4 text-center">
                  <a href="#">Followers</a>
                </div>
                <div className="col-4 text-center">
                  <a href="#">Sales</a>
                </div>
                <div className="col-4 text-center">
                  <a href="#">Friends</a>
                </div>
              </div>
              {/* /.row */}
            </li>
            {/* Menu Footer */}
            <li className="user-footer">
              <a href="/settings/profile" className="btn btn-default btn-flat">
                Profile
              </a>
              <a href="#" className="btn btn-default btn-flat float-end">
                Sign out
              </a>
            </li>
          </ul>
        </li>
        <li className="nav-item">
          <a className="nav-link" data-lte-toggle="control-sidebar" href="#" role="button">
            <i className="bi bi-gear"></i>
          </a>
        </li>
      </ul>
    </nav>
  )
}

