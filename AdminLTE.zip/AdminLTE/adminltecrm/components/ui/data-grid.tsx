"use client"

import type React from "react"
import { useState, useEffect, useMemo } from "react"
import { debounce } from "@/lib/utils/performance"
import { searchByTerm, sortBy } from "@/lib/utils/dataProcessing"

interface Column<T> {
  key: string
  header: React.ReactNode
  render?: (item: T) => React.ReactNode
  sortable?: boolean
  filterable?: boolean
  width?: string | number
}

interface DataGridProps<T> {
  data: T[]
  columns: Column<T>[]
  keyExtractor: (item: T) => string
  loading?: boolean
  searchable?: boolean
  pagination?: boolean
  pageSize?: number
  defaultSortKey?: string
  defaultSortDirection?: "asc" | "desc"
  onDataChange?: (data: T[]) => void
  toolbar?: React.ReactNode
  emptyMessage?: React.ReactNode
}

export function DataGrid<T>({
  data,
  columns,
  keyExtractor,
  loading = false,
  searchable = false,
  pagination = false,
  pageSize = 10,
  defaultSortKey,
  defaultSortDirection = "asc",
  onDataChange,
  toolbar,
  emptyMessage,
}: DataGridProps<T>) {
  // State for sorting
  const [sortKey, setSortKey] = useState<string | undefined>(defaultSortKey)
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">(defaultSortDirection)

  // State for searching
  const [searchTerm, setSearchTerm] = useState("")

  // State for pagination
  const [currentPage, setCurrentPage] = useState(1)

  // Debounced search handler
  const debouncedSetSearchTerm = useMemo(() => debounce((value: string) => setSearchTerm(value), 300), [])

  // Handle sort
  const handleSort = (key: string) => {
    if (sortKey === key) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc")
    } else {
      setSortKey(key)
      setSortDirection("asc")
    }
  }

  // Process data: filter, sort, paginate
  const processedData = useMemo(() => {
    // Step 1: Filter data based on search term
    let result = data

    if (searchTerm && searchable) {
      const filterableColumns = columns.filter((column) => column.filterable).map((column) => column.key)

      result = searchByTerm(result, searchTerm, filterableColumns as (keyof T)[])
    }

    // Step 2: Sort data
    if (sortKey) {
      result = sortBy(result, sortKey as keyof T, sortDirection)
    }

    // Step 3: Paginate data
    let paginatedData = result
    if (pagination) {
      const startIndex = (currentPage - 1) * pageSize
      paginatedData = result.slice(startIndex, startIndex + pageSize)
    }

    return {
      filteredData: result,
      displayData: paginatedData,
    }
  }, [data, searchTerm, sortKey, sortDirection, currentPage, pageSize, columns, searchable, pagination])

  // Calculate total pages
  const totalPages = useMemo(() => {
    return pagination ? Math.ceil(processedData.filteredData.length / pageSize) : 1
  }, [processedData.filteredData.length, pageSize, pagination])

  // Reset to first page when filtered data changes
  useEffect(() => {
    if (currentPage > totalPages) {
      setCurrentPage(1)
    }
  }, [totalPages, currentPage])

  // Notify parent of data changes
  useEffect(() => {
    if (onDataChange) {
      onDataChange(processedData.displayData)
    }
  }, [processedData.displayData, onDataChange])

  // Render loading state
  if (loading) {
    return (
      <div className="text-center p-4">
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
        <p className="mt-2">Loading data...</p>
      </div>
    )
  }

  // Render empty state
  if (data.length === 0) {
    return <div className="text-center p-4">{emptyMessage || "No data available"}</div>
  }

  return (
    <div className="data-grid">
      {/* Toolbar */}
      {(toolbar || searchable) && (
        <div className="data-grid-toolbar mb-3">
          <div className="d-flex justify-content-between align-items-center">
            {toolbar && <div className="data-grid-custom-toolbar">{toolbar}</div>}

            {searchable && (
              <div className="data-grid-search">
                <div className="input-group">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Search..."
                    onChange={(e) => debouncedSetSearchTerm(e.target.value)}
                  />
                  <span className="input-group-text">
                    <i className="bi bi-search"></i>
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Table */}
      <div className="table-responsive">
        <table className="table table-hover">
          <thead>
            <tr>
              {columns.map((column) => (
                <th
                  key={column.key}
                  style={{
                    cursor: column.sortable ? "pointer" : "default",
                    width: column.width,
                  }}
                  onClick={() => column.sortable && handleSort(column.key)}
                >
                  <div className="d-flex align-items-center">
                    <span>{column.header}</span>
                    {column.sortable && sortKey === column.key && (
                      <i className={`bi bi-arrow-${sortDirection === "asc" ? "up" : "down"} ms-1`}></i>
                    )}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {processedData.displayData.length === 0 ? (
              <tr>
                <td colSpan={columns.length} className="text-center">
                  No results found
                </td>
              </tr>
            ) : (
              processedData.displayData.map((item) => (
                <tr key={keyExtractor(item)}>
                  {columns.map((column) => (
                    <td key={`${keyExtractor(item)}-${column.key}`}>
                      {column.render ? column.render(item) : (item as any)[column.key]}
                    </td>
                  ))}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {pagination && totalPages > 1 && (
        <div className="d-flex justify-content-between align-items-center mt-3">
          <div className="pagination-info">
            Showing {(currentPage - 1) * pageSize + 1} to{" "}
            {Math.min(currentPage * pageSize, processedData.filteredData.length)} of {processedData.filteredData.length}{" "}
            entries
          </div>
          <ul className="pagination pagination-sm m-0">
            <li className={`page-item ${currentPage === 1 ? "disabled" : ""}`}>
              <button className="page-link" onClick={() => setCurrentPage(1)} disabled={currentPage === 1}>
                «
              </button>
            </li>
            <li className={`page-item ${currentPage === 1 ? "disabled" : ""}`}>
              <button
                className="page-link"
                onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
              >
                ‹
              </button>
            </li>

            {/* Page numbers */}
            {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
              let pageNum

              if (totalPages <= 5) {
                pageNum = i + 1
              } else if (currentPage <= 3) {
                pageNum = i + 1
              } else if (currentPage >= totalPages - 2) {
                pageNum = totalPages - 4 + i
              } else {
                pageNum = currentPage - 2 + i
              }

              return (
                <li key={pageNum} className={`page-item ${currentPage === pageNum ? "active" : ""}`}>
                  <button className="page-link" onClick={() => setCurrentPage(pageNum)}>
                    {pageNum}
                  </button>
                </li>
              )
            })}

            <li className={`page-item ${currentPage === totalPages ? "disabled" : ""}`}>
              <button
                className="page-link"
                onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages}
              >
                ›
              </button>
            </li>
            <li className={`page-item ${currentPage === totalPages ? "disabled" : ""}`}>
              <button
                className="page-link"
                onClick={() => setCurrentPage(totalPages)}
                disabled={currentPage === totalPages}
              >
                »
              </button>
            </li>
          </ul>
        </div>
      )}
    </div>
  )
}

