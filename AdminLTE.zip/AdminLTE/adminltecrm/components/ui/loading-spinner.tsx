import type React from "react"

interface LoadingSpinnerProps {
  size?: "sm" | "md" | "lg"
  color?: string
  text?: string
  fullPage?: boolean
}

export const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({
  size = "md",
  color = "primary",
  text = "Loading...",
  fullPage = false,
}) => {
  const spinnerSize = {
    sm: "spinner-border-sm",
    md: "",
    lg: "spinner-border-lg",
  }

  const spinner = (
    <div className="d-flex flex-column align-items-center justify-content-center">
      <div className={`spinner-border text-${color} ${spinnerSize[size]}`} role="status">
        <span className="visually-hidden">{text}</span>
      </div>
      {text && <p className="mt-2 text-muted">{text}</p>}
    </div>
  )

  if (fullPage) {
    return (
      <div className="d-flex align-items-center justify-content-center" style={{ minHeight: "60vh" }}>
        {spinner}
      </div>
    )
  }

  return spinner
}

