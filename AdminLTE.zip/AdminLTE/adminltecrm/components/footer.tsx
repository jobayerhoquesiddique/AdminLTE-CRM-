import type React from "react"

export const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="main-footer">
      <div className="float-right d-none d-sm-inline">JHS AdminLTE CRM v1.0.0</div>
      <strong>
        Copyright &copy; {currentYear}{" "}
        <a href="#" className="text-decoration-none">
          JHS AdminLTE CRM
        </a>
        .
      </strong>{" "}
      All rights reserved. Developed by Jobayer Hoque Siddique.
    </footer>
  )
}

