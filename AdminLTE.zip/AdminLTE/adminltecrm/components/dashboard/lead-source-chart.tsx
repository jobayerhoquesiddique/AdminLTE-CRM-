"use client"

import type React from "react"

import { useEffect, useRef } from "react"
import type { Lead } from "@/lib/context/CrmContext"

interface LeadSourceChartProps {
  leads: Lead[]
}

const LeadSourceChart: React.FC<LeadSourceChartProps> = ({ leads }) => {
  const chartRef = useRef<HTMLCanvasElement>(null)
  const chartInstanceRef = useRef<any>(null)

  useEffect(() => {
    const loadChart = async () => {
      try {
        if (!chartRef.current) return

        // Group leads by source
        const sourceGroups = leads.reduce((acc: Record<string, number>, lead) => {
          if (!acc[lead.source]) {
            acc[lead.source] = 0
          }
          acc[lead.source]++
          return acc
        }, {})

        const labels = Object.keys(sourceGroups)
        const data = Object.values(sourceGroups)

        // Define colors for the chart
        const backgroundColors = [
          "#0d6efd",
          "#20c997",
          "#ffc107",
          "#dc3545",
          "#6c757d",
          "#6610f2",
          "#fd7e14",
          "#198754",
          "#0dcaf0",
        ]

        // Load Chart.js dynamically
        const Chart = (await import("chart.js/auto")).default

        // Destroy previous chart if it exists
        if (chartInstanceRef.current) {
          chartInstanceRef.current.destroy()
        }

        // Create new chart
        chartInstanceRef.current = new Chart(chartRef.current, {
          type: "doughnut",
          data: {
            labels,
            datasets: [
              {
                data,
                backgroundColor: backgroundColors.slice(0, labels.length),
                borderWidth: 1,
              },
            ],
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                position: "right",
              },
              tooltip: {
                callbacks: {
                  label: (context) => {
                    const label = context.label || ""
                    const value = context.parsed || 0
                    const total = context.dataset.data.reduce((a: number, b: number) => a + b, 0)
                    const percentage = Math.round((value * 100) / total)
                    return `${label}: ${value} (${percentage}%)`
                  },
                },
              },
            },
          },
        })
      } catch (error) {
        console.error("Error loading lead source chart:", error)
      }
    }

    loadChart()

    // Cleanup function
    return () => {
      if (chartInstanceRef.current) {
        chartInstanceRef.current.destroy()
      }
    }
  }, [leads])

  return <canvas ref={chartRef} height="300"></canvas>
}

export default LeadSourceChart

