"use client"

import type React from "react"

import { useEffect, useRef } from "react"
import type { Deal } from "@/lib/context/CrmContext"

interface SalesPerformanceChartProps {
  deals: Deal[]
}

const SalesPerformanceChart: React.FC<SalesPerformanceChartProps> = ({ deals }) => {
  const chartRef = useRef<HTMLCanvasElement>(null)
  const chartInstanceRef = useRef<any>(null)

  useEffect(() => {
    const loadChart = async () => {
      try {
        if (!chartRef.current) return

        // Group deals by month and user
        const monthlyData: Record<string, Record<string, number>> = {}
        const users = new Set<string>()

        deals.forEach((deal) => {
          // Only include closed won deals
          if (deal.stage !== "Closed Won") return

          const date = new Date(deal.created)
          const month = date.toLocaleString("default", { month: "short" })
          const year = date.getFullYear()
          const monthYear = `${month} ${year}`

          if (!monthlyData[monthYear]) {
            monthlyData[monthYear] = {}
          }

          if (!monthlyData[monthYear][deal.assignedTo]) {
            monthlyData[monthYear][deal.assignedTo] = 0
          }

          monthlyData[monthYear][deal.assignedTo] += deal.value
          users.add(deal.assignedTo)
        })

        // Sort months chronologically
        const sortedMonths = Object.keys(monthlyData).sort((a, b) => {
          const dateA = new Date(a)
          const dateB = new Date(b)
          return dateA.getTime() - dateB.getTime()
        })

        // Prepare datasets for each user
        const datasets = Array.from(users).map((user, index) => {
          // Map user IDs to names
          const userNames: Record<string, string> = {
            user1: "John Doe",
            user2: "Sarah Johnson",
            user3: "Michael Brown",
            user4: "Emily Davis",
            user5: "Robert Wilson",
          }

          const colors = ["#0d6efd", "#20c997", "#ffc107", "#dc3545", "#6c757d"]

          return {
            label: userNames[user] || user,
            data: sortedMonths.map((month) => monthlyData[month][user] || 0),
            backgroundColor: colors[index % colors.length],
            borderColor: colors[index % colors.length],
            borderWidth: 1,
          }
        })

        // Load Chart.js dynamically
        const Chart = (await import("chart.js/auto")).default

        // Destroy previous chart if it exists
        if (chartInstanceRef.current) {
          chartInstanceRef.current.destroy()
        }

        // Create new chart
        chartInstanceRef.current = new Chart(chartRef.current, {
          type: "bar",
          data: {
            labels: sortedMonths,
            datasets,
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
              y: {
                beginAtZero: true,
                title: {
                  display: true,
                  text: "Revenue ($)",
                },
              },
            },
            plugins: {
              tooltip: {
                callbacks: {
                  label: (context) => `${context.dataset.label}: $${context.parsed.y.toLocaleString()}`,
                },
              },
            },
          },
        })
      } catch (error) {
        console.error("Error loading sales performance chart:", error)
      }
    }

    loadChart()

    // Cleanup function
    return () => {
      if (chartInstanceRef.current) {
        chartInstanceRef.current.destroy()
      }
    }
  }, [deals])

  return <canvas ref={chartRef} height="300"></canvas>
}

export default SalesPerformanceChart

