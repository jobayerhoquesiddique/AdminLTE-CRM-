// Format currency
function formatCurrency(value) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value)
}

// Initialize the application
document.addEventListener("DOMContentLoaded", () => {
  // Initialize data
  const data = initializeData()

  // Set up sidebar toggle
  const sidebarToggle = document.getElementById("sidebar-toggle")
  if (sidebarToggle) {
    sidebarToggle.addEventListener("click", () => {
      document.body.classList.toggle("sidebar-collapse")
    })
  }

  // Set up navigation
  const navLinks = document.querySelectorAll("[data-page]")
  navLinks.forEach((link) => {
    link.addEventListener("click", function (e) {
      e.preventDefault()
      const page = this.getAttribute("data-page")
      loadPage(page)

      // Update active state in sidebar
      document.querySelectorAll(".nav-link").forEach((navLink) => {
        navLink.classList.remove("active")
      })
      document.querySelectorAll(`[data-page="${page}"]`).forEach((navLink) => {
        navLink.classList.add("active")
      })
    })
  })

  // Load dashboard by default
  loadPage("dashboard")
})

// Load page content
function loadPage(page) {
  const contentContainer = document.getElementById("main-content")
  if (!contentContainer) return

  // Show loading spinner
  contentContainer.innerHTML = `
    <div class="loading-spinner">
      <div class="spinner-border text-primary" role="status">
        <span class="visually-hidden">Loading...</span>
      </div>
    </div>
  `

  // Load page content based on the page name
  switch (page) {
    case "dashboard":
      loadDashboard()
      break
    case "customers":
      loadCustomers()
      break
    case "leads":
      loadLeads()
      break
    case "deals":
      loadDeals()
      break
    case "tasks":
      loadTasks()
      break
    case "calendar":
      loadCalendar()
      break
    case "sales-report":
      loadSalesReport()
      break
    case "activity-report":
      loadActivityReport()
      break
    case "settings":
      loadSettings()
      break
    case "profile":
      loadProfile()
      break
    case "support":
      loadSupport()
      break
    default:
      contentContainer.innerHTML = `<div class="alert alert-warning">Page not found</div>`
  }
}

// Load dashboard page
function loadDashboard() {
  const data = loadDataFromLocalStorage()
  const contentContainer = document.getElementById("main-content")

  // Calculate summary metrics
  const activeCustomers = data.customers.filter((c) => c.status === "Active").length
  const activeDeals = data.deals.filter((d) => ["Proposal", "Negotiation"].includes(d.stage)).length
  const newLeads = data.leads.filter((l) => l.status === "New").length
  const pendingTasks = data.tasks.filter((t) => t.status === "Pending").length
  const totalRevenue = data.deals.filter((d) => d.stage === "Closed Won").reduce((sum, deal) => sum + deal.value, 0)

  // Get recent deals
  const recentDeals = [...data.deals]
    .sort((a, b) => new Date(b.created).getTime() - new Date(a.created).getTime())
    .slice(0, 5)

  // Get recent activities
  const recentActivities = [...data.activities]
    .sort((a, b) => new Date(b.date + " " + b.time).getTime() - new Date(a.date + " " + a.time).getTime())
    .slice(0, 5)

  contentContainer.innerHTML = `
    <div class="page-dashboard">
      <div class="row">
        <!-- Summary Cards -->
        <div class="col-lg-3 col-6">
          <div class="small-box bg-info">
            <div class="inner">
              <h3>${activeCustomers}</h3>
              <p>Active Customers</p>
            </div>
            <div class="icon">
              <i class="bi bi-people"></i>
            </div>
            <a href="#" class="small-box-footer" data-page="customers">
              More info <i class="bi bi-arrow-right-circle"></i>
            </a>
          </div>
        </div>
        <div class="col-lg-3 col-6">
          <div class="small-box bg-success">
            <div class="inner">
              <h3>${activeDeals}</h3>
              <p>Active Deals</p>
            </div>
            <div class="icon">
              <i class="bi bi-currency-dollar"></i>
            </div>
            <a href="#" class="small-box-footer" data-page="deals">
              More info <i class="bi bi-arrow-right-circle"></i>
            </a>
          </div>
        </div>
        <div class="col-lg-3 col-6">
          <div class="small-box bg-warning">
            <div class="inner">
              <h3>${newLeads}</h3>
              <p>New Leads</p>
            </div>
            <div class="icon">
              <i class="bi bi-funnel"></i>
            </div>
            <a href="#" class="small-box-footer" data-page="leads">
              More info <i class="bi bi-arrow-right-circle"></i>
            </a>
          </div>
        </div>
        <div class="col-lg-3 col-6">
          <div class="small-box bg-danger">
            <div class="inner">
              <h3>${pendingTasks}</h3>
              <p>Pending Tasks</p>
            </div>
            <div class="icon">
              <i class="bi bi-check2-square"></i>
            </div>
            <a href="#" class="small-box-footer" data-page="tasks">
              More info <i class="bi bi-arrow-right-circle"></i>
            </a>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-8">
          <!-- Sales Performance Chart -->
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Sales Performance</h3>
              <div class="card-tools">
                <button type="button" class="btn btn-tool" data-lte-toggle="card-collapse">
                  <i class="bi bi-minus"></i>
                </button>
              </div>
            </div>
            <div class="card-body">
              <canvas id="salesPerformanceChart" style="height: 300px;"></canvas>
            </div>
            <div class="card-footer">
              <div class="row">
                <div class="col-md-3 col-6">
                  <div class="text-center border-end">
                    <span class="text-success">
                      <i class="bi bi-caret-up-fill"></i> 17%
                    </span>
                    <h5 class="fw-bold mb-0">${formatCurrency(totalRevenue)}</h5>
                    <span class="text-uppercase">TOTAL REVENUE</span>
                  </div>
                </div>
                <div class="col-md-3 col-6">
                  <div class="text-center border-end">
                    <span class="text-info">
                      <i class="bi bi-caret-left-fill"></i> 0%
                    </span>
                    <h5 class="fw-bold mb-0">$10,390.90</h5>
                    <span class="text-uppercase">TOTAL COST</span>
                  </div>
                </div>
                <div class="col-md-3 col-6">
                  <div class="text-center border-end">
                    <span class="text-success">
                      <i class="bi bi-caret-up-fill"></i> 20%
                    </span>
                    <h5 class="fw-bold mb-0">$24,813.53</h5>
                    <span class="text-uppercase">TOTAL PROFIT</span>
                  </div>
                </div>
                <div class="col-md-3 col-6">
                  <div class="text-center">
                    <span class="text-danger">
                      <i class="bi bi-caret-down-fill"></i> 18%
                    </span>
                    <h5 class="fw-bold mb-0">1200</h5>
                    <span class="text-uppercase">GOAL COMPLETIONS</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Deal Pipeline Chart -->
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Deal Pipeline</h3>
              <div class="card-tools">
                <button type="button" class="btn btn-tool" data-lte-toggle="card-collapse">
                  <i class="bi bi-minus"></i>
                </button>
              </div>
            </div>
            <div class="card-body">
              <canvas id="dealPipelineChart" style="height: 300px;"></canvas>
            </div>
          </div>

          <!-- Recent Deals -->
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Recent Deals</h3>
              <div class="card-tools">
                <button type="button" class="btn btn-tool" data-lte-toggle="card-collapse">
                  <i class="bi bi-minus"></i>
                </button>
              </div>
            </div>
            <div class="card-body p-0">
              <div class="table-responsive">
                <table class="table table-striped">
                  <thead>
                    <tr>
                      <th>Deal</th>
                      <th>Customer</th>
                      <th>Status</th>
                      <th>Amount</th>
                    </tr>
                  </thead>
                  <tbody id="recent-deals-table">
                    ${recentDeals
                      .map((deal) => {
                        const customer = data.customers.find((c) => c.id === deal.customer)
                        return `
                        <tr>
                          <td>${deal.name}</td>
                          <td>${customer ? customer.name : "Unknown"}</td>
                          <td>
                            <span class="badge ${
                              deal.stage === "Closed Won"
                                ? "bg-success"
                                : deal.stage === "Closed Lost"
                                  ? "bg-danger"
                                  : deal.stage === "Negotiation"
                                    ? "bg-warning"
                                    : deal.stage === "Proposal"
                                      ? "bg-info"
                                      : "bg-primary"
                            }">${deal.stage}</span>
                          </td>
                          <td>${formatCurrency(deal.value)}</td>
                        </tr>
                      `
                      })
                      .join("")}
                  </tbody>
                </table>
              </div>
            </div>
            <div class="card-footer clearfix">
              <a href="#" class="btn btn-sm btn-primary float-start" data-page="deals">
                Place New Deal
              </a>
              <a href="#" class="btn btn-sm btn-secondary float-end" data-page="deals">
                View All Deals
              </a>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <!-- Lead Sources Chart -->
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Lead Sources</h3>
              <div class="card-tools">
                <button type="button" class="btn btn-tool" data-lte-toggle="card-collapse">
                  <i class="bi bi-minus"></i>
                </button>
              </div>
            </div>
            <div class="card-body">
              <canvas id="leadSourceChart" style="height: 300px;"></canvas>
            </div>
          </div>

          <!-- Recent Activities -->
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Recent Activity</h3>
              <div class="card-tools">
                <button type="button" class="btn btn-tool" data-lte-toggle="card-collapse">
                  <i class="bi bi-minus"></i>
                </button>
              </div>
            </div>
            <div class="card-body p-0">
              <ul class="list-group list-group-flush">
                ${recentActivities
                  .map((activity) => {
                    let relatedEntity = ""
                    if (activity.relatedTo.type === "customer") {
                      const customer = data.customers.find((c) => c.id === activity.relatedTo.id)
                      relatedEntity = customer ? customer.name : ""
                    } else if (activity.relatedTo.type === "lead") {
                      const lead = data.leads.find((l) => l.id === activity.relatedTo.id)
                      relatedEntity = lead ? lead.name : ""
                    }

                    return `
                    <li class="list-group-item">
                      <div class="d-flex w-100 justify-content-between">
                        <h5 class="mb-1">
                          <i class="bi ${
                            activity.type === "Call"
                              ? "bi-telephone"
                              : activity.type === "Email"
                                ? "bi-envelope"
                                : activity.type === "Meeting"
                                  ? "bi-calendar-event"
                                  : "bi-journal-text"
                          } me-2"></i>
                          ${activity.type}
                        </h5>
                        <small>${activity.date}, ${activity.time}</small>
                      </div>
                      <p class="mb-1">${activity.description}</p>
                      ${relatedEntity ? `<small class="text-muted">Related to: ${relatedEntity}</small>` : ""}
                    </li>
                  `
                  })
                  .join("")}
              </ul>
            </div>
            <div class="card-footer text-center">
              <a href="#" class="btn btn-sm btn-primary" data-page="activity-report">
                View All Activities
              </a>
            </div>
          </div>

          <!-- Upcoming Tasks -->
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Upcoming Tasks</h3>
              <div class="card-tools">
                <span title="3 New Tasks" class="badge bg-primary">3</span>
                <button type="button" class="btn btn-tool" data-lte-toggle="card-collapse">
                  <i class="bi bi-minus"></i>
                </button>
              </div>
            </div>
            <div class="card-body p-0">
              <ul class="list-group list-group-flush">
                ${data.tasks
                  .slice(0, 5)
                  .map(
                    (task) => `
                  <li class="list-group-item task-item">
                    <div class="d-flex align-items-center">
                      <input type="checkbox" class="me-2">
                      <span class="text">${task.title}</span>
                      <small class="badge ${
                        task.priority === "High" ? "bg-danger" : task.priority === "Medium" ? "bg-warning" : "bg-info"
                      } ms-auto">
                        <i class="bi bi-clock"></i> ${task.dueDate}
                      </small>
                    </div>
                  </li>
                `,
                  )
                  .join("")}
              </ul>
            </div>
            <div class="card-footer text-center">
              <a href="#" class="btn btn-sm btn-primary" data-page="tasks">
                View All Tasks
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  `

  // Initialize charts
  setTimeout(() => {
    initDashboardCharts()
  }, 100)
}

// Load customers page
function loadCustomers() {
  const data = loadDataFromLocalStorage()
  const contentContainer = document.getElementById("main-content")

  contentContainer.innerHTML = `
    <div class="page-customers">
      <div class="row mb-3">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Customer Management</h3>
              <div class="card-tools">
                <div class="input-group input-group-sm" style="width: 150px;">
                  <input type="text" name="table_search" class="form-control float-right" placeholder="Search" id="customer-search">
                  <div class="input-group-append">
                    <button type="submit" class="btn btn-default">
                      <i class="bi bi-search"></i>
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <div class="card-body">
              <div class="d-flex justify-content-between mb-3">
                <button class="btn btn-primary" id="add-customer-btn">
                  <i class="bi bi-plus-circle me-1"></i> Add Customer
                </button>
                <div class="btn-group">
                  <button type="button" class="btn btn-default dropdown-toggle" data-bs-toggle="dropdown">
                    Filter by Status
                  </button>
                  <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="#" data-filter="all">All</a></li>
                    <li><a class="dropdown-item" href="#" data-filter="active">Active</a></li>
                    <li><a class="dropdown-item" href="#" data-filter="inactive">Inactive</a></li>
                  </ul>
                </div>
              </div>
              
              <div class="table-responsive">
                <table class="table table-hover">
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Company</th>
                      <th>Email</th>
                      <th>Phone</th>
                      <th>Status</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody id="customers-table">
                    ${data.customers
                      .map(
                        (customer) => `
                      <tr>
                        <td>${customer.name}</td>
                        <td>${customer.company}</td>
                        <td>${customer.email}</td>
                        <td>${customer.phone}</td>
                        <td>
                          <span class="badge ${customer.status === "Active" ? "bg-success" : "bg-secondary"}">
                            ${customer.status}
                          </span>
                        </td>
                        <td>
                          <button class="btn btn-info btn-sm view-customer" data-id="${customer.id}">
                            <i class="bi bi-eye"></i>
                          </button>
                          <button class="btn btn-primary btn-sm edit-customer" data-id="${customer.id}">
                            <i class="bi bi-pencil"></i>
                          </button>
                          <button class="btn btn-danger btn-sm delete-customer" data-id="${customer.id}">
                            <i class="bi bi-trash"></i>
                          </button>
                        </td>
                      </tr>
                    `,
                      )
                      .join("")}
                  </tbody>
                </table>
              </div>
            </div>
            <div class="card-footer clearfix">
              <ul class="pagination pagination-sm m-0 float-end">
                <li class="page-item"><a class="page-link" href="#">«</a></li>
                <li class="page-item"><a class="page-link" href="#">1</a></li>
                <li class="page-item"><a class="page-link" href="#">2</a></li>
                <li class="page-item"><a class="page-link" href="#">3</a></li>
                <li class="page-item"><a class="page-link" href="#">»</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Customer Overview</h3>
            </div>
            <div class="card-body">
              <div class="row">
                <div class="col-md-3 col-sm-6">
                  <div class="info-box">
                    <span class="info-box-icon bg-info"><i class="bi bi-people"></i></span>
                    <div class="info-box-content">
                      <span class="info-box-text">Total Customers</span>
                      <span class="info-box-number">${data.customers.length}</span>
                    </div>
                  </div>
                </div>
                <div class="col-md-3 col-sm-6">
                  <div class="info-box">
                    <span class="info-box-icon bg-success"><i class="bi bi-check-circle"></i></span>
                    <div class="info-box-content">
                      <span class="info-box-text">Active Customers</span>
                      <span class="info-box-number">${data.customers.filter((c) => c.status === "Active").length}</span>
                    </div>
                  </div>
                </div>
                <div class="col-md-3 col-sm-6">
                  <div class="info-box">
                    <span class="info-box-icon bg-warning"><i class="bi bi-clock-history"></i></span>
                    <div class="info-box-content">
                      <span class="info-box-text">New This Month</span>
                      <span class="info-box-number">3</span>
                    </div>
                  </div>
                </div>
                <div class="col-md-3 col-sm-6">
                  <div class="info-box">
                    <span class="info-box-icon bg-danger"><i class="bi bi-x-circle"></i></span>
                    <div class="info-box-content">
                      <span class="info-box-text">Inactive Customers</span>
                      <span class="info-box-number">${data.customers.filter((c) => c.status === "Inactive").length}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `

  // Add event listeners for customer actions
  document.querySelectorAll(".view-customer").forEach((btn) => {
    btn.addEventListener("click", function () {
      const customerId = this.getAttribute("data-id")
      alert(`View customer with ID: ${customerId}`)
      // In a real app, you would show customer details here
    })
  })

  document.querySelectorAll(".edit-customer").forEach((btn) => {
    btn.addEventListener("click", function () {
      const customerId = this.getAttribute("data-id")
      alert(`Edit customer with ID: ${customerId}`)
      // In a real app, you would show edit form here
    })
  })

  document.querySelectorAll(".delete-customer").forEach((btn) => {
    btn.addEventListener("click", function () {
      const customerId = this.getAttribute("data-id")
      if (confirm("Are you sure you want to delete this customer?")) {
        alert(`Delete customer with ID: ${customerId}`)
        // In a real app, you would delete the customer here
      }
    })
  })

  // Add event listener for add customer button
  document.getElementById("add-customer-btn").addEventListener("click", () => {
    alert("Add new customer")
    // In a real app, you would show add form here
  })

  // Add event listeners for filter links
  document.querySelectorAll("[data-filter]").forEach((link) => {
    link.addEventListener("click", function (e) {
      e.preventDefault()
      const filter = this.getAttribute("data-filter")
      alert(`Filter customers by: ${filter}`)
      // In a real app, you would filter the customers here
    })
  })

  // Add event listener for search
  document.getElementById("customer-search").addEventListener("input", function () {
    const searchTerm = this.value.toLowerCase()
    const rows = document.querySelectorAll("#customers-table tr")

    rows.forEach((row) => {
      const text = row.textContent.toLowerCase()
      row.style.display = text.includes(searchTerm) ? "" : "none"
    })
  })
}

// Load leads page
function loadLeads() {
  const data = loadDataFromLocalStorage()
  const contentContainer = document.getElementById("main-content")

  contentContainer.innerHTML = `
    <div class="page-leads">
      <div class="row mb-3">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Lead Management</h3>
              <div class="card-tools">
                <div class="input-group input-group-sm" style="width: 150px;">
                  <input type="text" name="table_search" class="form-control float-right" placeholder="Search" id="lead-search">
                  <div class="input-group-append">
                    <button type="submit" class="btn btn-default">
                      <i class="bi bi-search"></i>
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <div class="card-body">
              <div class="d-flex justify-content-between mb-3">
                <div>
                  <button class="btn btn-primary me-2" id="add-lead-btn">
                    <i class="bi bi-plus-circle me-1"></i> Add Lead
                  </button>
                  <div class="btn-group">
                    <button type="button" class="btn btn-default">All</button>
                    <button type="button" class="btn btn-default">New</button>
                    <button type="button" class="btn btn-default">Contacted</button>
                    <button type="button" class="btn btn-default">Qualified</button>
                  </div>
                </div>
                <div class="btn-group">
                  <button type="button" class="btn btn-default dropdown-toggle" data-bs-toggle="dropdown">
                    Sort By
                  </button>
                  <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="#">Date (Newest)</a></li>
                    <li><a class="dropdown-item" href="#">Date (Oldest)</a></li>
                    <li><a class="dropdown-item" href="#">Name (A-Z)</a></li>
                    <li><a class="dropdown-item" href="#">Name (Z-A)</a></li>
                    <li><a class="dropdown-item" href="#">Score (High-Low)</a></li>
                  </ul>
                </div>
              </div>
              
              <div class="table-responsive">
                <table class="table table-hover">
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Company</th>
                      <th>Email</th>
                      <th>Phone</th>
                      <th>Source</th>
                      <th>Status</th>
                      <th>Score</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody id="leads-table">
                    ${data.leads
                      .map(
                        (lead) => `
                      <tr>
                        <td>${lead.name}</td>
                        <td>${lead.company}</td>
                        <td>${lead.email}</td>
                        <td>${lead.phone}</td>
                        <td>${lead.source}</td>
                        <td>
                          <span class="badge ${
                            lead.status === "New"
                              ? "bg-warning"
                              : lead.status === "Contacted"
                                ? "bg-info"
                                : lead.status === "Qualified"
                                  ? "bg-success"
                                  : lead.status === "Negotiation"
                                    ? "bg-primary"
                                    : "bg-secondary"
                          }">
                            ${lead.status}
                          </span>
                        </td>
                        <td>
                          <div class="progress lead-progress">
                            <div class="progress-bar ${
                              (lead.score || 0) > 75
                                ? "bg-success"
                                : (lead.score || 0) > 50
                                  ? "bg-info"
                                  : (lead.score || 0) > 25
                                    ? "bg-warning"
                                    : "bg-danger"
                            }" role="progressbar" style="width: ${lead.score || 0}%"></div>
                          </div>
                          <small>${lead.score || 0}%</small>
                        </td>
                        <td>
                          <button class="btn btn-info btn-sm view-lead" data-id="${lead.id}">
                            <i class="bi bi-eye"></i>
                          </button>
                          <button class="btn btn-primary btn-sm edit-lead" data-id="${lead.id}">
                            <i class="bi bi-pencil"></i>
                          </button>
                          <button class="btn btn-success btn-sm convert-lead" data-id="${lead.id}">
                            <i class="bi bi-person-check"></i>
                          </button>
                          <button class="btn btn-danger btn-sm delete-lead" data-id="${lead.id}">
                            <i class="bi bi-trash"></i>
                          </button>
                        </td>
                      </tr>
                    `,
                      )
                      .join("")}
                  </tbody>
                </table>
              </div>
            </div>
            <div class="card-footer clearfix">
              <ul class="pagination pagination-sm m-0 float-end">
                <li class="page-item"><a class="page-link" href="#">«</a></li>
                <li class="page-item"><a class="page-link" href="#">1</a></li>
                <li class="page-item"><a class="page-link" href="#">2</a></li>
                <li class="page-item"><a class="page-link" href="#">3</a></li>
                <li class="page-item"><a class="page-link" href="#">»</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Lead Overview</h3>
            </div>
            <div class="card-body">
              <div class="row">
                <div class="col-md-3 col-sm-6">
                  <div class="info-box">
                    <span class="info-box-icon bg-info"><i class="bi bi-funnel"></i></span>
                    <div class="info-box-content">
                      <span class="info-box-text">Total Leads</span>
                      <span class="info-box-number">${data.leads.length}</span>
                    </div>
                  </div>
                </div>
                <div class="col-md-3 col-sm-6">
                  <div class="info-box">
                    <span class="info-box-icon bg-warning"><i class="bi bi-star"></i></span>
                    <div class="info-box-content">
                      <span class="info-box-text">New Leads</span>
                      <span class="info-box-number">${data.leads.filter((l) => l.status === "New").length}</span>
                    </div>
                  </div>
                </div>
                <div class="col-md-3 col-sm-6">
                  <div class="info-box">
                    <span class="info-box-icon bg-success"><i class="bi bi-check-circle"></i></span>
                    <div class="info-box-content">
                      <span class="info-box-text">Qualified Leads</span>
                      <span class="info-box-number">${data.leads.filter((l) => l.status === "Qualified").length}</span>
                    </div>
                  </div>
                </div>
                <div class="col-md-3 col-sm-6">
                  <div class="info-box">
                    <span class="info-box-icon bg-danger"><i class="bi bi-currency-dollar"></i></span>
                    <div class="info-box-content">
                      <span class="info-box-text">Potential Value</span>
                      <span class="info-box-number">${formatCurrency(data.leads.reduce((sum, lead) => sum + (lead.estimatedValue || 0), 0))}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `

  // Add event listeners for lead actions
  document.querySelectorAll(".view-lead").forEach((btn) => {
    btn.addEventListener("click", function () {
      const leadId = this.getAttribute("data-id")
      alert(`View lead with ID: ${leadId}`)
      // In a real app, you would show lead details here
    })
  })

  document.querySelectorAll(".edit-lead").forEach((btn) => {
    btn.addEventListener("click", function () {
      const leadId = this.getAttribute("data-id")
      alert(`Edit lead with ID: ${leadId}`)
      // In a real app, you would show edit form here
    })
  })

  document.querySelectorAll(".convert-lead").forEach((btn) => {
    btn.addEventListener("click", function () {
      const leadId = this.getAttribute("data-id")
      alert(`Convert lead with ID: ${leadId} to customer`)
      // In a real app, you would show convert form here
    })
  })

  document.querySelectorAll(".delete-lead").forEach((btn) => {
    btn.addEventListener("click", function () {
      const leadId = this.getAttribute("data-id")
      if (confirm("Are you sure you want to delete this lead?")) {
        alert(`Delete lead with ID: ${leadId}`)
        // In a real app, you would delete the lead here
      }
    })
  })

  // Add event listener for add lead button
  document.getElementById("add-lead-btn").addEventListener("click", () => {
    alert("Add new lead")
    // In a real app, you would show add form here
  })

  // Add event listener for search
  document.getElementById("lead-search").addEventListener("input", function () {
    const searchTerm = this.value.toLowerCase()
    const rows = document.querySelectorAll("#leads-table tr")

    rows.forEach((row) => {
      const text = row.textContent.toLowerCase()
      row.style.display = text.includes(searchTerm) ? "" : "none"
    })
  })
}

// Load deals page
function loadDeals() {
  const data = loadDataFromLocalStorage()
  const contentContainer = document.getElementById("main-content")

  contentContainer.innerHTML = `
    <div class="page-deals">
      <div class="row mb-3">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Deal Pipeline</h3>
              <div class="card-tools">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-primary">All Deals</button>
                  <button type="button" class="btn btn-sm btn-default">My Deals</button>
                </div>
              </div>
            </div>
            <div class="card-body">
              <div class="kanban-container">
                <!-- Prospect Stage -->
                <div class="kanban-board">
                  <div class="kanban-board-header" style="background-color: #6c757d;">
                    <div class="kanban-title-board">Prospect</div>
                    <div class="kanban-title-button">
                      <span class="badge bg-light text-dark">0</span>
                    </div>
                  </div>
                  <div class="kanban-drag" id="prospect-stage">
                    <!-- Deals will be added here -->
                  </div>
                </div>

                <!-- Qualification Stage -->
                <div class="kanban-board">
                  <div class="kanban-board-header" style="background-color: #17a2b8;">
                    <div class="kanban-title-board">Qualification</div>
                    <div class="kanban-title-button">
                      <span class="badge bg-light text-dark">0</span>
                    </div>
                  </div>
                  <div class="kanban-drag" id="qualification-stage">
                    <!-- Deals will be added here -->
                  </div>
                </div>

                <!-- Proposal Stage -->
                <div class="kanban-board">
                  <div class="kanban-board-header" style="background-color: #ffc107;">
                    <div class="kanban-title-board">Proposal</div>
                    <div class="kanban-title-button">
                      <span class="badge bg-light text-dark" id="proposal-count">0</span>
                    </div>
                  </div>
                  <div class="kanban-drag" id="proposal-stage">
                    <!-- Deals will be added here -->
                  </div>
                </div>

                <!-- Negotiation Stage -->
                <div class="kanban-board">
                  <div class="kanban-board-header" style="background-color: #fd7e14;">
                    <div class="kanban-title-board">Negotiation</div>
                    <div class="kanban-title-button">
                      <span class="badge bg-light text-dark" id="negotiation-count">0</span>
                    </div>
                  </div>
                  <div class="kanban-drag" id="negotiation-stage">
                    <!-- Deals will be added here -->
                  </div>
                </div>

                <!-- Closed Won Stage -->
                <div class="kanban-board">
                  <div class="kanban-board-header" style="background-color: #28a745;">
                    <div class="kanban-title-board">Closed Won</div>
                    <div class="kanban-title-button">
                      <span class="badge bg-light text-dark" id="closed-won-count">0</span>
                    </div>
                  </div>
                  <div class="kanban-drag" id="closed-won-stage">
                    <!-- Deals will be added here -->
                  </div>
                </div>

                <!-- Closed Lost Stage -->
                <div class="kanban-board">
                  <div class="kanban-board-header" style="background-color: #dc3545;">
                    <div class="kanban-title-board">Closed Lost</div>
                    <div class="kanban-title-button">
                      <span class="badge bg-light text-dark" id="closed-lost-count">0</span>
                    </div>
                  </div>
                  <div class="kanban-drag" id="closed-lost-stage">
                    <!-- Deals will be added here -->
                  </div>
                </div>
              </div>
            </div>
            <div class="card-footer">
              <button class="btn btn-primary" id="add-deal-btn">
                <i class="bi bi-plus"></i> Add New Deal
              </button>
            </div>
          </div>
        </div>
      </div>
      
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Deal Overview</h3>
            </div>
            <div class="card-body">
              <div class="row">
                <div class="col-md-3 col-sm-6">
                  <div class="info-box">
                    <span class="info-box-icon bg-info"><i class="bi bi-currency-dollar"></i></span>
                    <div class="info-box-content">
                      <span class="info-box-text">Total Value</span>
                      <span class="info-box-number" id="total-deal-value">$0</span>
                    </div>
                  </div>
                </div>
                <div class="col-md-3 col-sm-6">
                  <div class="info-box">
                    <span class="info-box-icon bg-success"><i class="bi bi-check-circle"></i></span>
                    <div class="info-box-content">
                      <span class="info-box-text">Won Deals</span>
                      <span class="info-box-number" id="won-deals-count">0</span>
                    </div>
                  </div>
                </div>
                <div class="col-md-3 col-sm-6">
                  <div class="info-box">
                    <span class="info-box-icon bg-warning"><i class="bi bi-hourglass-split"></i></span>
                    <div class="info-box-content">
                      <span class="info-box-text">In Pipeline</span>
                      <span class="info-box-number" id="pipeline-deals-count">0</span>
                    </div>
                  </div>
                </div>
                <div class="col-md-3 col-sm-6">
                  <div class="info-box">
                    <span class="info-box-icon bg-danger"><i class="bi bi-x-circle"></i></span>
                    <div class="info-box-content">
                      <span class="info-box-text">Lost Deals</span>
                      <span class="info-box-number" id="lost-deals-count">0</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `

  // Populate deal boards
  const prospectDeals = data.deals.filter((deal) => deal.stage === "Prospect")
  const qualificationDeals = data.deals.filter((deal) => deal.stage === "Qualification")
  const proposalDeals = data.deals.filter((deal) => deal.stage === "Proposal")
  const negotiationDeals = data.deals.filter((deal) => deal.stage === "Negotiation")
  const closedWonDeals = data.deals.filter((deal) => deal.stage === "Closed Won")
  const closedLostDeals = data.deals.filter((deal) => deal.stage === "Closed Lost")

  // Update counts
  document.getElementById("proposal-count").textContent = proposalDeals.length
  document.getElementById("negotiation-count").textContent = negotiationDeals.length
  document.getElementById("closed-won-count").textContent = closedWonDeals.length
  document.getElementById("closed-lost-count").textContent = closedLostDeals.length

  // Update overview stats
  document.getElementById("total-deal-value").textContent = formatCurrency(
    data.deals.reduce((sum, deal) => sum + deal.value, 0),
  )
  document.getElementById("won-deals-count").textContent = closedWonDeals.length
  document.getElementById("pipeline-deals-count").textContent = proposalDeals.length + negotiationDeals.length
  document.getElementById("lost-deals-count").textContent = closedLostDeals.length

  // Populate deal cards
  function populateDeals(deals, containerId) {
    const container = document.getElementById(containerId)
    if (!container) return

    deals.forEach((deal) => {
      const customer = data.customers.find((c) => c.id === deal.customer)
      const dealCard = document.createElement("div")
      dealCard.className = "kanban-item deal-card"
      dealCard.setAttribute("data-id", deal.id)

      dealCard.innerHTML = `
        <div class="d-flex justify-content-between align-items-center mb-2">
          <h5 class="mb-0">${deal.name}</h5>
          <span class="badge bg-primary">${formatCurrency(deal.value)}</span>
        </div>
        <p class="mb-1">${customer ? customer.name : "Unknown"}</p>
        <div class="d-flex justify-content-between align-items-center">
          <small class="text-muted">Added: ${deal.created}</small>
          <button class="btn btn-xs btn-info view-deal" data-id="${deal.id}">
            <i class="bi bi-eye"></i>
          </button>
        </div>
      `

      container.appendChild(dealCard)

      // Add event listener to view button
      dealCard.querySelector(".view-deal").addEventListener("click", function (e) {
        e.stopPropagation()
        const dealId = this.getAttribute("data-id")
        alert(`View deal ${dealId}`)
      })
    })
  }

  // Populate all deal boards
  populateDeals(prospectDeals, "prospect-stage")
  populateDeals(qualificationDeals, "qualification-stage")
  populateDeals(proposalDeals, "proposal-stage")
  populateDeals(negotiationDeals, "negotiation-stage")
  populateDeals(closedWonDeals, "closed-won-stage")
  populateDeals(closedLostDeals, "closed-lost-stage")

  // Add event listener for add deal button
  document.getElementById("add-deal-btn").addEventListener("click", () => {
    alert("Add new deal")
    // In a real app, you would show add form here
  })
}

// Load tasks page
function loadTasks() {
  const data = loadDataFromLocalStorage()
  const contentContainer = document.getElementById("main-content")

  contentContainer.innerHTML = `
    <div class="page-tasks">
      <div class="row mb-3">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Task Management</h3>
              <div class="card-tools">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-primary">All Tasks</button>
                  <button type="button" class="btn btn-sm btn-default">My Tasks</button>
                  <button type="button" class="btn btn-sm btn-default">Completed</button>
                </div>
              </div>
            </div>
            <div class="card-body">
              <div class="row mb-3">
                <div class="col-md-6">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search tasks..." id="task-search">
                    <button class="btn btn-outline-secondary" type="button">
                      <i class="bi bi-search"></i>
                    </button>
                  </div>
                </div>
                <div class="col-md-6 text-end">
                  <div class="btn-group">
                    <button type="button" class="btn btn-default">
                      <i class="bi bi-filter"></i> Filter
                    </button>
                    <button type="button" class="btn btn-default">
                      <i class="bi bi-sort-down"></i> Sort
                    </button>
                  </div>
                </div>
              </div>

              <div class="table-responsive">
                <table class="table table-hover">
                  <thead>
                    <tr>
                      <th style="width: 5%"></th>
                      <th style="width: 35%">Task</th>
                      <th style="width: 15%">Assigned To</th>
                      <th style="width: 15%">Related To</th>
                      <th style="width: 10%">Priority</th>
                      <th style="width: 10%">Due Date</th>
                      <th style="width: 10%">Actions</th>
                    </tr>
                  </thead>
                  <tbody id="tasks-table">
                    ${data.tasks
                      .map((task) => {
                        // Get related entity
                        let relatedTo = ""
                        let relatedLink = "#"
                        if (task.relatedTo) {
                          if (task.relatedTo.type === "customer") {
                            const customer = data.customers.find((c) => c.id === task.relatedTo.id)
                            if (customer) {
                              relatedTo = customer.name
                              relatedLink = "#"
                            }
                          } else if (task.relatedTo.type === "lead") {
                            const lead = data.leads.find((l) => l.id === task.relatedTo.id)
                            if (lead) {
                              relatedTo = lead.name
                              relatedLink = "#"
                            }
                          }
                        }

                        // Get assigned user
                        const assignedUser = data.users.find((u) => u.id === task.assignedTo)

                        return `
                        <tr class="task-item">
                          <td>
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" ${task.status === "Completed" ? "checked" : ""}>
                            </div>
                          </td>
                          <td>
                            <a href="#" class="task-title">${task.title}</a>
                            <p class="text-muted mb-0 small">${task.description}</p>
                          </td>
                          <td>
                            <img src="img/profile.jpg" class="img-circle me-2" alt="User" style="width: 32px; height: 32px;">
                            ${assignedUser ? assignedUser.name : "Unassigned"}
                          </td>
                          <td>
                            <a href="${relatedLink}">${relatedTo || "N/A"}</a>
                          </td>
                          <td>
                            <span class="badge ${
                              task.priority === "High"
                                ? "bg-danger"
                                : task.priority === "Medium"
                                  ? "bg-warning"
                                  : "bg-info"
                            }">${task.priority}</span>
                          </td>
                          <td>${task.dueDate}</td>
                          <td>
                            <div class="btn-group">
                              <button class="btn btn-sm btn-info view-task" data-id="${task.id}">
                                <i class="bi bi-eye"></i>
                              </button>
                              <button class="btn btn-sm btn-primary edit-task" data-id="${task.id}">
                                <i class="bi bi-pencil"></i>
                              </button>
                              <button class="btn btn-sm btn-danger delete-task" data-id="${task.id}">
                                <i class="bi bi-trash"></i>
                              </button>
                            </div>
                          </td>
                        </tr>
                      `
                      })
                      .join("")}
                  </tbody>
                </table>
              </div>
            </div>
            <div class="card-footer clearfix">
              <ul class="pagination pagination-sm m-0 float-end">
                <li class="page-item"><a class="page-link" href="#">«</a></li>
                <li class="page-item"><a class="page-link" href="#">1</a></li>
                <li class="page-item"><a class="page-link" href="#">2</a></li>
                <li class="page-item"><a class="page-link" href="#">3</a></li>
                <li class="page-item"><a class="page-link" href="#">»</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      
      <div class="row">
        <div class="col-12 mt-3">
          <button class="btn btn-primary" id="add-task-btn">
            <i class="bi bi-plus"></i> Add New Task
          </button>
        </div>
      </div>
    </div>
  `

  // Add event listeners for task actions
  document.querySelectorAll(".view-task").forEach((btn) => {
    btn.addEventListener("click", function () {
      const taskId = this.getAttribute("data-id")
      alert(`View task with ID: ${taskId}`)
    })
  })

  document.querySelectorAll(".edit-task").forEach((btn) => {
    btn.addEventListener("click", function () {
      const taskId = this.getAttribute("data-id")
      alert(`Edit task with ID: ${taskId}`)
    })
  })

  document.querySelectorAll(".delete-task").forEach((btn) => {
    btn.addEventListener("click", function () {
      const taskId = this.getAttribute("data-id")
      if (confirm("Are you sure you want to delete this task?")) {
        alert(`Delete task with ID: ${taskId}`)
      }
    })
  })

  // Add event listener for add task button
  document.getElementById("add-task-btn").addEventListener("click", () => {
    alert("Add new task")
  })

  // Add event listener for search
  document.getElementById("task-search").addEventListener("input", function () {
    const searchTerm = this.value.toLowerCase()
    const rows = document.querySelectorAll("#tasks-table tr")

    rows.forEach((row) => {
      const text = row.textContent.toLowerCase()
      row.style.display = text.includes(searchTerm) ? "" : "none"
    })
  })
}

// Load sales report page
function loadSalesReport() {
  const data = loadDataFromLocalStorage()
  const contentContainer = document.getElementById("main-content")

  contentContainer.innerHTML = `
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Sales Report</h3>
            <div class="card-tools">
              <div class="btn-group">
                <button type="button" class="btn btn-sm btn-primary">This Month</button>
                <button type="button" class="btn btn-sm btn-default">This Quarter</button>
                <button type="button" class="btn btn-sm btn-default">This Year</button>
                <button type="button" class="btn btn-sm btn-default">Custom</button>
              </div>
            </div>
          </div>
          <div class="card-body">
            <div class="row">
              <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box">
                  <span class="info-box-icon bg-info"><i class="bi bi-cash-stack"></i></span>
                  <div class="info-box-content">
                    <span class="info-box-text">Total Revenue</span>
                    <span class="info-box-number">${formatCurrency(
                      data.deals.filter((d) => d.stage === "Closed Won").reduce((sum, deal) => sum + deal.value, 0),
                    )}</span>
                  </div>
                </div>
              </div>
              <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box">
                  <span class="info-box-icon bg-success"><i class="bi bi-check-circle"></i></span>
                  <div class="info-box-content">
                    <span class="info-box-text">Deals Won</span>
                    <span class="info-box-number">${data.deals.filter((d) => d.stage === "Closed Won").length}</span>
                  </div>
                </div>
              </div>
              <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box">
                  <span class="info-box-icon bg-warning"><i class="bi bi-hourglass-split"></i></span>
                  <div class="info-box-content">
                    <span class="info-box-text">Deals in Pipeline</span>
                    <span class="info-box-number">${
                      data.deals.filter((d) => ["Proposal", "Negotiation"].includes(d.stage)).length
                    }</span>
                  </div>
                </div>
              </div>
              <div class="col-md-3 col-sm-6 col-12">
                <div class="info-box">
                  <span class="info-box-icon bg-danger"><i class="bi bi-x-circle"></i></span>
                  <div class="info-box-content">
                    <span class="info-box-text">Deals Lost</span>
                    <span class="info-box-number">${data.deals.filter((d) => d.stage === "Closed Lost").length}</span>
                  </div>
                </div>
              </div>
            </div>

            <div class="row mt-4">
              <div class="col-md-8">
                <div class="card">
                  <div class="card-header">
                    <h3 class="card-title">Monthly Revenue</h3>
                  </div>
                  <div class="card-body">
                    <canvas id="revenueChart" style="min-height: 300px; height: 300px; max-height: 300px; max-width: 100%;"></canvas>
                  </div>
                </div>
              </div>
              <div class="col-md-4">
                <div class="card">
                  <div class="card-header">
                    <h3 class="card-title">Deal Status</h3>
                  </div>
                  <div class="card-body">
                    <canvas id="dealStatusChart" style="min-height: 300px; height: 300px; max-height: 300px; max-width: 100%;"></canvas>
                  </div>
                </div>
              </div>
            </div>

            <div class="row mt-4">
              <div class="col-md-12">
                <div class="card">
                  <div class="card-header">
                    <h3 class="card-title">Top Performing Products</h3>
                  </div>
                  <div class="card-body table-responsive p-0">
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th>Product</th>
                          <th>Revenue</th>
                          <th>Deals</th>
                          <th>Avg. Deal Size</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>Enterprise Software Package</td>
                          <td>$15,000</td>
                          <td>3</td>
                          <td>$5,000</td>
                        </tr>
                        <tr>
                          <td>Cloud Migration</td>
                          <td>$12,000</td>
                          <td>2</td>
                          <td>$6,000</td>
                        </tr>
                        <tr>
                          <td>Support Contract</td>
                          <td>$8,200</td>
                          <td>4</td>
                          <td>$2,050</td>
                        </tr>
                        <tr>
                          <td>Hardware Upgrade</td>
                          <td>$7,200</td>
                          <td>2</td>
                          <td>$3,600</td>
                        </tr>
                        <tr>
                          <td>IT Consulting</td>
                          <td>$2,800</td>
                          <td>1</td>
                          <td>$2,800</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="card-footer">
            <button type="button" class="btn btn-primary">
              <i class="bi bi-download"></i> Export Report
            </button>
            <button type="button" class="btn btn-default ms-2">
              <i class="bi bi-printer"></i> Print
            </button>
          </div>
        </div>
      </div>
    </div>
  `

  // Initialize charts
  setTimeout(() => {
    initSalesReportCharts()
  }, 100)
}

// Load more pages as needed...

// Dummy functions to satisfy the calls. In a real application, these would load actual content.
function loadCalendar() {
  const contentContainer = document.getElementById("main-content")
  contentContainer.innerHTML = `<h2>Calendar Page</h2><p>This is the calendar page content.</p>`
}

function loadActivityReport() {
  const contentContainer = document.getElementById("main-content")
  contentContainer.innerHTML = `<h2>Activity Report Page</h2><p>This is the activity report page content.</p>`
}

function loadSettings() {
  const contentContainer = document.getElementById("main-content")
  contentContainer.innerHTML = `<h2>Settings Page</h2><p>This is the settings page content.</p>`
}

function loadProfile() {
  const contentContainer = document.getElementById("main-content")
  contentContainer.innerHTML = `<h2>Profile Page</h2><p>This is the profile page content.</p>`
}

function loadSupport() {
  const contentContainer = document.getElementById("main-content")
  contentContainer.innerHTML = `<h2>Support Page</h2><p>This is the support page content.</p>`
}

function initializeData() {
  // Dummy data initialization
  const data = {
    customers: [
      {
        id: "1",
        name: "John Doe",
        company: "Acme Corp",
        email: "john.doe@example.com",
        phone: "123-456-7890",
        status: "Active",
      },
      {
        id: "2",
        name: "Jane Smith",
        company: "Beta Inc",
        email: "jane.smith@example.com",
        phone: "987-654-3210",
        status: "Inactive",
      },
    ],
    leads: [
      {
        id: "101",
        name: "Alice Brown",
        company: "Gamma Co",
        email: "alice.brown@example.com",
        phone: "555-123-4567",
        source: "Web",
        status: "New",
        score: 60,
        estimatedValue: 5000,
      },
      {
        id: "102",
        name: "Bob Johnson",
        company: "Delta Ltd",
        email: "bob.johnson@example.com",
        phone: "555-987-6543",
        source: "Referral",
        status: "Contacted",
        score: 80,
        estimatedValue: 7500,
      },
    ],
    deals: [
      { id: "201", name: "Acme - Beta Deal", customer: "1", stage: "Proposal", value: 10000, created: "2024-01-15" },
      {
        id: "202",
        name: "Gamma - Delta Project",
        customer: "2",
        stage: "Negotiation",
        value: 15000,
        created: "2024-02-20",
      },
    ],
    tasks: [
      {
        id: "301",
        title: "Follow up with Acme",
        assignedTo: "1",
        relatedTo: { type: "customer", id: "1" },
        priority: "High",
        dueDate: "2024-03-10",
        status: "Pending",
        description: "Send a follow-up email to discuss the proposal.",
      },
      {
        id: "302",
        title: "Prepare presentation for Delta",
        assignedTo: "2",
        relatedTo: { type: "lead", id: "102" },
        priority: "Medium",
        dueDate: "2024-03-15",
        status: "In Progress",
        description: "Create a compelling presentation for the upcoming meeting.",
      },
    ],
    activities: [
      {
        id: "401",
        type: "Call",
        date: "2024-03-01",
        time: "10:00",
        description: "Discussed project requirements",
        relatedTo: { type: "customer", id: "1" },
      },
      {
        id: "402",
        type: "Email",
        date: "2024-03-05",
        time: "14:30",
        description: "Sent proposal document",
        relatedTo: { type: "lead", id: "101" },
      },
    ],
    users: [
      { id: "1", name: "Alice Smith" },
      { id: "2", name: "Bob Johnson" },
    ],
  }
  localStorage.setItem("crmData", JSON.stringify(data))
  return data
}

function loadDataFromLocalStorage() {
  const storedData = localStorage.getItem("crmData")
  return storedData
    ? JSON.parse(storedData)
    : { customers: [], leads: [], deals: [], tasks: [], activities: [], users: [] }
}

function initDashboardCharts() {
  // Dummy chart initialization
  console.log("Initializing dashboard charts")
}

function initSalesReportCharts() {
  // Dummy chart initialization
  console.log("Initializing sales report charts")
}

// Initialize the app when the DOM is fully loaded
document.addEventListener("DOMContentLoaded", () => {
  // Initialize data
  initializeData()

  // Load dashboard by default
  loadPage("dashboard")
})

