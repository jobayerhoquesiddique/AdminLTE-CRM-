import Link from "next/link"

export default function NewCustomer() {
  return (
    <div className="row">
      <div className="col-md-12">
        <div className="card card-primary">
          <div className="card-header">
            <h3 className="card-title">Add New Customer</h3>
          </div>
          <form>
            <div className="card-body">
              <div className="row">
                <div className="col-md-6">
                  <div className="form-group mb-3">
                    <label htmlFor="name">Name</label>
                    <input type="text" className="form-control" id="name" placeholder="Enter name" />
                  </div>
                  <div className="form-group mb-3">
                    <label htmlFor="company">Company</label>
                    <input type="text" className="form-control" id="company" placeholder="Enter company name" />
                  </div>
                  <div className="form-group mb-3">
                    <label htmlFor="email">Email</label>
                    <input type="email" className="form-control" id="email" placeholder="Enter email" />
                  </div>
                  <div className="form-group mb-3">
                    <label htmlFor="phone">Phone</label>
                    <input type="text" className="form-control" id="phone" placeholder="Enter phone number" />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="form-group mb-3">
                    <label htmlFor="address">Address</label>
                    <textarea className="form-control" id="address" rows={3} placeholder="Enter address"></textarea>
                  </div>
                  <div className="form-group mb-3">
                    <label htmlFor="status">Status</label>
                    <select className="form-control" id="status">
                      <option>Active</option>
                      <option>Inactive</option>
                      <option>Lead</option>
                    </select>
                  </div>
                  <div className="form-group mb-3">
                    <label htmlFor="notes">Notes</label>
                    <textarea className="form-control" id="notes" rows={3} placeholder="Enter notes"></textarea>
                  </div>
                </div>
              </div>
            </div>
            <div className="card-footer">
              <button type="submit" className="btn btn-primary">
                Submit
              </button>
              <Link href="/customers" className="btn btn-default float-end">
                Cancel
              </Link>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}

