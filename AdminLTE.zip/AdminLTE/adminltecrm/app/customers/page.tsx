import Link from "next/link"

export default function Customers() {
  return (
    <div className="row">
      <div className="col-12">
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Customer List</h3>
            <div className="card-tools">
              <div className="input-group input-group-sm" style={{ width: "150px" }}>
                <input type="text" name="table_search" className="form-control float-right" placeholder="Search" />
                <div className="input-group-append">
                  <button type="submit" className="btn btn-default">
                    <i className="bi bi-search"></i>
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div className="card-body table-responsive p-0">
            <table className="table table-hover text-nowrap">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Name</th>
                  <th>Company</th>
                  <th>Email</th>
                  <th>Phone</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>1</td>
                  <td>John Smith</td>
                  <td>Acme Inc.</td>
                  <td>john@acme.com</td>
                  <td>(123) 456-7890</td>
                  <td>
                    <span className="badge bg-success">Active</span>
                  </td>
                  <td>
                    <Link href="/customers/1" className="btn btn-info btn-sm me-1">
                      <i className="bi bi-eye"></i>
                    </Link>
                    <Link href="/customers/edit/1" className="btn btn-primary btn-sm me-1">
                      <i className="bi bi-pencil"></i>
                    </Link>
                    <button className="btn btn-danger btn-sm">
                      <i className="bi bi-trash"></i>
                    </button>
                  </td>
                </tr>
                <tr>
                  <td>2</td>
                  <td>Sarah Johnson</td>
                  <td>TechGiant Corp</td>
                  <td>sarah@techgiant.com</td>
                  <td>(234) 567-8901</td>
                  <td>
                    <span className="badge bg-success">Active</span>
                  </td>
                  <td>
                    <Link href="/customers/2" className="btn btn-info btn-sm me-1">
                      <i className="bi bi-eye"></i>
                    </Link>
                    <Link href="/customers/edit/2" className="btn btn-primary btn-sm me-1">
                      <i className="bi bi-pencil"></i>
                    </Link>
                    <button className="btn btn-danger btn-sm">
                      <i className="bi bi-trash"></i>
                    </button>
                  </td>
                </tr>
                <tr>
                  <td>3</td>
                  <td>Michael Brown</td>
                  <td>Startup Solutions</td>
                  <td>michael@startup.com</td>
                  <td>(345) 678-9012</td>
                  <td>
                    <span className="badge bg-warning">Inactive</span>
                  </td>
                  <td>
                    <Link href="/customers/3" className="btn btn-info btn-sm me-1">
                      <i className="bi bi-eye"></i>
                    </Link>
                    <Link href="/customers/edit/3" className="btn btn-primary btn-sm me-1">
                      <i className="bi bi-pencil"></i>
                    </Link>
                    <button className="btn btn-danger btn-sm">
                      <i className="bi bi-trash"></i>
                    </button>
                  </td>
                </tr>
                <tr>
                  <td>4</td>
                  <td>Emily Davis</td>
                  <td>Global Enterprises</td>
                  <td>emily@global.com</td>
                  <td>(456) 789-0123</td>
                  <td>
                    <span className="badge bg-success">Active</span>
                  </td>
                  <td>
                    <Link href="/customers/4" className="btn btn-info btn-sm me-1">
                      <i className="bi bi-eye"></i>
                    </Link>
                    <Link href="/customers/edit/4" className="btn btn-primary btn-sm me-1">
                      <i className="bi bi-pencil"></i>
                    </Link>
                    <button className="btn btn-danger btn-sm">
                      <i className="bi bi-trash"></i>
                    </button>
                  </td>
                </tr>
                <tr>
                  <td>5</td>
                  <td>Robert Wilson</td>
                  <td>Local Business LLC</td>
                  <td>robert@local.com</td>
                  <td>(567) 890-1234</td>
                  <td>
                    <span className="badge bg-danger">Inactive</span>
                  </td>
                  <td>
                    <Link href="/customers/5" className="btn btn-info btn-sm me-1">
                      <i className="bi bi-eye"></i>
                    </Link>
                    <Link href="/customers/edit/5" className="btn btn-primary btn-sm me-1">
                      <i className="bi bi-pencil"></i>
                    </Link>
                    <button className="btn btn-danger btn-sm">
                      <i className="bi bi-trash"></i>
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <div className="card-footer clearfix">
            <ul className="pagination pagination-sm m-0 float-end">
              <li className="page-item">
                <a className="page-link" href="#">
                  «
                </a>
              </li>
              <li className="page-item">
                <a className="page-link" href="#">
                  1
                </a>
              </li>
              <li className="page-item">
                <a className="page-link" href="#">
                  2
                </a>
              </li>
              <li className="page-item">
                <a className="page-link" href="#">
                  3
                </a>
              </li>
              <li className="page-item">
                <a className="page-link" href="#">
                  »
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div className="col-12 mt-3">
        <Link href="/customers/new" className="btn btn-primary">
          <i className="bi bi-plus"></i> Add New Customer
        </Link>
      </div>
    </div>
  )
}

