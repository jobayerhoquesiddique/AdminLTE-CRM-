export default function Documentation() {
  return (
    <div className="row">
      <div className="col-md-3">
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Documentation</h3>
          </div>
          <div className="card-body p-0">
            <ul className="nav nav-pills flex-column">
              <li className="nav-item">
                <a href="#getting-started" className="nav-link active">
                  <i className="bi bi-rocket me-2"></i> Getting Started
                </a>
              </li>
              <li className="nav-item">
                <a href="#customers" className="nav-link">
                  <i className="bi bi-people me-2"></i> Customers
                </a>
              </li>
              <li className="nav-item">
                <a href="#leads" className="nav-link">
                  <i className="bi bi-funnel me-2"></i> Leads
                </a>
              </li>
              <li className="nav-item">
                <a href="#deals" className="nav-link">
                  <i className="bi bi-currency-dollar me-2"></i> Deals
                </a>
              </li>
              <li className="nav-item">
                <a href="#tasks" className="nav-link">
                  <i className="bi bi-check2-square me-2"></i> Tasks
                </a>
              </li>
              <li className="nav-item">
                <a href="#calendar" className="nav-link">
                  <i className="bi bi-calendar-week me-2"></i> Calendar
                </a>
              </li>
              <li className="nav-item">
                <a href="#reports" className="nav-link">
                  <i className="bi bi-bar-chart me-2"></i> Reports
                </a>
              </li>
              <li className="nav-item">
                <a href="#settings" className="nav-link">
                  <i className="bi bi-gear me-2"></i> Settings
                </a>
              </li>
              <li className="nav-item">
                <a href="#api" className="nav-link">
                  <i className="bi bi-code-slash me-2"></i> API Documentation
                </a>
              </li>
              <li className="nav-item">
                <a href="#faq" className="nav-link">
                  <i className="bi bi-question-circle me-2"></i> FAQ
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div className="col-md-9">
        <div className="card">
          <div className="card-body">
            <section id="getting-started" className="mb-5">
              <h2>Getting Started</h2>
              <p>
                Welcome to the AdminLTE CRM documentation. This guide will help you get started with our Customer
                Relationship Management system and make the most of its features.
              </p>
              <div className="alert alert-info">
                <i className="bi bi-info-circle me-2"></i> If you're new to the system, we recommend starting with the
                Dashboard overview and then exploring the Customers section.
              </div>

              <h4 className="mt-4">Dashboard Overview</h4>
              <p>The Dashboard provides a quick overview of your CRM data, including:</p>
              <ul>
                <li>Key performance metrics</li>
                <li>Recent activities</li>
                <li>Upcoming tasks and events</li>
                <li>Sales pipeline visualization</li>
              </ul>

              <h4 className="mt-4">Navigation</h4>
              <p>
                The main navigation is located on the left sidebar. You can collapse it by clicking the toggle button in
                the top header. The sidebar includes links to all major sections of the CRM:
              </p>
              <ul>
                <li>Dashboard - Overview of your CRM data</li>
                <li>Customers - Manage your customer database</li>
                <li>Leads - Track and convert potential customers</li>
                <li>Deals - Manage your sales pipeline</li>
                <li>Tasks - Track and manage activities</li>
                <li>Calendar - Schedule and manage events</li>
                <li>Reports - Generate and view reports</li>
                <li>Settings - Configure your CRM</li>
              </ul>
            </section>

            <section id="customers" className="mb-5">
              <h2>Customers</h2>
              <p>
                The Customers section allows you to manage your customer database. You can add, edit, and delete
                customer records, as well as view detailed information about each customer.
              </p>

              <h4 className="mt-4">Adding a New Customer</h4>
              <p>
                To add a new customer, click the "Add New Customer" button on the Customers page. Fill in the required
                information and click "Submit" to create the customer record.
              </p>

              <h4 className="mt-4">Customer Details</h4>
              <p>The Customer Details page provides comprehensive information about a customer, including:</p>
              <ul>
                <li>Contact information</li>
                <li>Company details</li>
                <li>Associated deals</li>
                <li>Activity history</li>
                <li>Notes and attachments</li>
              </ul>

              <h4 className="mt-4">Managing Customers</h4>
              <p>You can perform various actions on customer records:</p>
              <ul>
                <li>Edit customer information</li>
                <li>Delete customer records</li>
                <li>Add notes and attachments</li>
                <li>Create tasks and events related to the customer</li>
                <li>Create deals associated with the customer</li>
              </ul>
            </section>

            <div className="alert alert-warning mt-4">
              <i className="bi bi-exclamation-triangle me-2"></i> This documentation is a work in progress. More
              sections will be added soon.
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

