"use client"

import { useState, useEffect, useMemo, useCallback } from "react"
import Link from "next/link"
import { useCrm } from "@/lib/context/CrmContext"
import { DataGrid } from "@/components/ui/data-grid"
import { useOptimizedState } from "@/lib/hooks/useOptimizedState"

export default function Leads() {
  const { state, deleteLead } = useCrm()
  const { leads, isLoading } = state

  // Optimized state management
  const [filterStatus, setFilterStatus] = useOptimizedState<string>("all")
  const [sortField, setSortField] = useOptimizedState<string>("created")
  const [sortDirection, setSortDirection] = useOptimizedState<"asc" | "desc">("desc")
  const [showDeleteModal, setShowDeleteModal] = useState(false)
  const [leadToDelete, setLeadToDelete] = useState<string | null>(null)
  const [filteredData, setFilteredData] = useState<any[]>([])

  // Handle delete click
  const handleDeleteClick = useCallback((id: string) => {
    setLeadToDelete(id)
    setShowDeleteModal(true)
  }, [])

  // Confirm delete
  const confirmDelete = useCallback(() => {
    if (leadToDelete) {
      deleteLead(leadToDelete)
      setShowDeleteModal(false)
      setLeadToDelete(null)
    }
  }, [leadToDelete, deleteLead])

  // Define columns for the data grid
  const columns = useMemo(
    () => [
      {
        key: "name",
        header: "Name",
        sortable: true,
        filterable: true,
        render: (lead: any) => (
          <Link href={`/leads/${lead.id}`} className="text-blue-600 hover:underline">
            {lead.name}
          </Link>
        ),
      },
      {
        key: "company",
        header: "Company",
        sortable: true,
        filterable: true,
      },
      {
        key: "email",
        header: "Email",
        sortable: true,
        filterable: true,
      },
      {
        key: "phone",
        header: "Phone",
        sortable: true,
        filterable: true,
      },
      {
        key: "source",
        header: "Source",
        sortable: true,
        filterable: true,
      },
      {
        key: "status",
        header: "Status",
        sortable: true,
        filterable: true,
        render: (lead: any) => (
          <span
            className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
              lead.status === "New"
                ? "bg-yellow-100 text-yellow-800"
                : lead.status === "Contacted"
                  ? "bg-blue-100 text-blue-800"
                  : lead.status === "Qualified"
                    ? "bg-green-100 text-green-800"
                    : lead.status === "Proposal"
                      ? "bg-purple-100 text-purple-800"
                      : lead.status === "Unqualified"
                        ? "bg-red-100 text-red-800"
                        : "bg-gray-100 text-gray-800"
            }`}
          >
            {lead.status}
          </span>
        ),
      },
      {
        key: "score",
        header: "Score",
        sortable: true,
        render: (lead: any) => (
          <div>
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div
                className={`h-2.5 rounded-full ${
                  (lead.score || 0) > 75
                    ? "bg-green-600"
                    : (lead.score || 0) > 50
                      ? "bg-blue-600"
                      : (lead.score || 0) > 25
                        ? "bg-yellow-500"
                        : "bg-red-600"
                }`}
                style={{ width: `${lead.score || 0}%` }}
              ></div>
            </div>
            <span className="text-xs text-gray-500 mt-1">{lead.score || 0}%</span>
          </div>
        ),
      },
      {
        key: "created",
        header: "Created",
        sortable: true,
      },
      {
        key: "actions",
        header: "Actions",
        render: (lead: any) => (
          <div className="flex space-x-1">
            <Link href={`/leads/${lead.id}`} className="btn btn-info btn-sm">
              <i className="bi bi-eye"></i>
            </Link>
            <Link href={`/leads/edit/${lead.id}`} className="btn btn-primary btn-sm">
              <i className="bi bi-pencil"></i>
            </Link>
            <button className="btn btn-success btn-sm">
              <i className="bi bi-person-check"></i>
            </button>
            <button className="btn btn-danger btn-sm" onClick={() => handleDeleteClick(lead.id)}>
              <i className="bi bi-trash"></i>
            </button>
          </div>
        ),
      },
    ],
    [handleDeleteClick],
  )

  // Custom toolbar for the data grid
  const toolbar = useMemo(
    () => (
      <div className="flex space-x-2">
        <Link href="/leads/new" className="btn btn-primary">
          <i className="bi bi-plus"></i> New Lead
        </Link>
        <div className="btn-group">
          <button
            type="button"
            className={`btn ${filterStatus[0] === "all" ? "btn-primary" : "btn-default"}`}
            onClick={() => setFilterStatus("all")}
          >
            All
          </button>
          <button
            type="button"
            className={`btn ${filterStatus[0] === "new" ? "btn-primary" : "btn-default"}`}
            onClick={() => setFilterStatus("new")}
          >
            New
          </button>
          <button
            type="button"
            className={`btn ${filterStatus[0] === "contacted" ? "btn-primary" : "btn-default"}`}
            onClick={() => setFilterStatus("contacted")}
          >
            Contacted
          </button>
          <button
            type="button"
            className={`btn ${filterStatus[0] === "qualified" ? "btn-primary" : "btn-default"}`}
            onClick={() => setFilterStatus("qualified")}
          >
            Qualified
          </button>
        </div>
      </div>
    ),
    [filterStatus, setFilterStatus],
  )

  // Filter leads based on status
  useEffect(() => {
    const filterLeads = () => {
      let filtered = [...leads]

      if (filterStatus[0] !== "all") {
        filtered = filtered.filter((lead) => lead.status.toLowerCase() === filterStatus[0].toLowerCase())
      }

      setFilteredData(filtered)
    }

    filterLeads()
  }, [leads, filterStatus])

  return (
    <div className="row">
      <div className="col-12">
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Lead Management</h3>
          </div>
          <div className="card-body">
            <DataGrid
              data={filteredData}
              columns={columns}
              keyExtractor={(item) => item.id}
              loading={isLoading}
              searchable={true}
              pagination={true}
              pageSize={10}
              defaultSortKey={sortField[0]}
              defaultSortDirection={sortDirection[0]}
              onDataChange={(data) => {
                // Handle data changes if needed
              }}
              toolbar={toolbar}
              emptyMessage={
                <div className="text-center py-8">
                  <svg
                    className="mx-auto h-12 w-12 text-gray-400"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1}
                      d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"
                    />
                  </svg>
                  <p className="mt-2 text-sm text-gray-500">No leads found matching your criteria</p>
                  <Link href="/leads/new" className="mt-3 btn btn-primary">
                    <i className="bi bi-plus"></i> Add New Lead
                  </Link>
                </div>
              }
            />
          </div>
        </div>
      </div>

      {showDeleteModal && (
        <div className="modal fade show" style={{ display: "block", backgroundColor: "rgba(0,0,0,0.5)" }}>
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Delete Lead</h5>
                <button type="button" className="btn-close" onClick={() => setShowDeleteModal(false)}></button>
              </div>
              <div className="modal-body">
                <p>Are you sure you want to delete this lead?</p>
                <p className="text-danger">This action cannot be undone.</p>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowDeleteModal(false)}>
                  Cancel
                </button>
                <button type="button" className="btn btn-danger" onClick={confirmDelete}>
                  Delete Lead
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

