import Link from "next/link"

export default function Tasks() {
  return (
    <div className="row">
      <div className="col-md-12">
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Task Management</h3>
            <div className="card-tools">
              <div className="btn-group">
                <button type="button" className="btn btn-sm btn-primary">
                  All Tasks
                </button>
                <button type="button" className="btn btn-sm btn-default">
                  My Tasks
                </button>
                <button type="button" className="btn btn-sm btn-default">
                  Completed
                </button>
              </div>
            </div>
          </div>
          <div className="card-body">
            <div className="row mb-3">
              <div className="col-md-6">
                <div className="input-group">
                  <input type="text" className="form-control" placeholder="Search tasks..." />
                  <button className="btn btn-outline-secondary" type="button">
                    <i className="bi bi-search"></i>
                  </button>
                </div>
              </div>
              <div className="col-md-6 text-end">
                <div className="btn-group">
                  <button type="button" className="btn btn-default">
                    <i className="bi bi-filter"></i> Filter
                  </button>
                  <button type="button" className="btn btn-default">
                    <i className="bi bi-sort-down"></i> Sort
                  </button>
                </div>
              </div>
            </div>

            <div className="table-responsive">
              <table className="table table-hover">
                <thead>
                  <tr>
                    <th style={{ width: "5%" }}></th>
                    <th style={{ width: "35%" }}>Task</th>
                    <th style={{ width: "15%" }}>Assigned To</th>
                    <th style={{ width: "15%" }}>Related To</th>
                    <th style={{ width: "10%" }}>Priority</th>
                    <th style={{ width: "10%" }}>Due Date</th>
                    <th style={{ width: "10%" }}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>
                      <div className="form-check">
                        <input className="form-check-input" type="checkbox" />
                      </div>
                    </td>
                    <td>
                      <Link href="/tasks/1">Call John about proposal</Link>
                      <p className="text-muted mb-0 small">Follow up on the enterprise software package proposal</p>
                    </td>
                    <td>
                      <img
                        src="/placeholder.svg?height=32&width=32"
                        className="img-circle me-2"
                        alt="User"
                        style={{ width: "32px", height: "32px" }}
                      />
                      Sarah Johnson
                    </td>
                    <td>
                      <Link href="/customers/1">Acme Inc.</Link>
                    </td>
                    <td>
                      <span className="badge bg-danger">High</span>
                    </td>
                    <td>Today</td>
                    <td>
                      <div className="btn-group">
                        <button className="btn btn-sm btn-info">
                          <i className="bi bi-eye"></i>
                        </button>
                        <button className="btn btn-sm btn-primary">
                          <i className="bi bi-pencil"></i>
                        </button>
                        <button className="btn btn-sm btn-danger">
                          <i className="bi bi-trash"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <div className="form-check">
                        <input className="form-check-input" type="checkbox" />
                      </div>
                    </td>
                    <td>
                      <Link href="/tasks/2">Prepare presentation for client</Link>
                      <p className="text-muted mb-0 small">Create slides for the upcoming client meeting</p>
                    </td>
                    <td>
                      <img
                        src="/placeholder.svg?height=32&width=32"
                        className="img-circle me-2"
                        alt="User"
                        style={{ width: "32px", height: "32px" }}
                      />
                      John Doe
                    </td>
                    <td>
                      <Link href="/customers/2">TechGiant Corp</Link>
                    </td>
                    <td>
                      <span className="badge bg-info">Medium</span>
                    </td>
                    <td>Tomorrow</td>
                    <td>
                      <div className="btn-group">
                        <button className="btn btn-sm btn-info">
                          <i className="bi bi-eye"></i>
                        </button>
                        <button className="btn btn-sm btn-primary">
                          <i className="bi bi-pencil"></i>
                        </button>
                        <button className="btn btn-sm btn-danger">
                          <i className="bi bi-trash"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <div className="form-check">
                        <input className="form-check-input" type="checkbox" />
                      </div>
                    </td>
                    <td>
                      <Link href="/tasks/3">Send follow-up email to leads</Link>
                      <p className="text-muted mb-0 small">Send email to all leads from the trade show</p>
                    </td>
                    <td>
                      <img
                        src="/placeholder.svg?height=32&width=32"
                        className="img-circle me-2"
                        alt="User"
                        style={{ width: "32px", height: "32px" }}
                      />
                      Emily Davis
                    </td>
                    <td>
                      <Link href="/leads">Multiple Leads</Link>
                    </td>
                    <td>
                      <span className="badge bg-warning">Medium</span>
                    </td>
                    <td>Mar 20, 2023</td>
                    <td>
                      <div className="btn-group">
                        <button className="btn btn-sm btn-info">
                          <i className="bi bi-eye"></i>
                        </button>
                        <button className="btn btn-sm btn-primary">
                          <i className="bi bi-pencil"></i>
                        </button>
                        <button className="btn btn-sm btn-danger">
                          <i className="bi bi-trash"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <div className="form-check">
                        <input className="form-check-input" type="checkbox" />
                      </div>
                    </td>
                    <td>
                      <Link href="/tasks/4">Update sales forecast</Link>
                      <p className="text-muted mb-0 small">Review and update Q2 sales forecast</p>
                    </td>
                    <td>
                      <img
                        src="/placeholder.svg?height=32&width=32"
                        className="img-circle me-2"
                        alt="User"
                        style={{ width: "32px", height: "32px" }}
                      />
                      Michael Brown
                    </td>
                    <td>
                      <Link href="/reports/sales">Sales Report</Link>
                    </td>
                    <td>
                      <span className="badge bg-success">Low</span>
                    </td>
                    <td>Mar 22, 2023</td>
                    <td>
                      <div className="btn-group">
                        <button className="btn btn-sm btn-info">
                          <i className="bi bi-eye"></i>
                        </button>
                        <button className="btn btn-sm btn-primary">
                          <i className="bi bi-pencil"></i>
                        </button>
                        <button className="btn btn-sm btn-danger">
                          <i className="bi bi-trash"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <div className="form-check">
                        <input className="form-check-input" type="checkbox" />
                      </div>
                    </td>
                    <td>
                      <Link href="/tasks/5">Schedule team meeting</Link>
                      <p className="text-muted mb-0 small">Organize monthly sales team meeting</p>
                    </td>
                    <td>
                      <img
                        src="/placeholder.svg?height=32&width=32"
                        className="img-circle me-2"
                        alt="User"
                        style={{ width: "32px", height: "32px" }}
                      />
                      Robert Wilson
                    </td>
                    <td>
                      <Link href="/calendar">Team Calendar</Link>
                    </td>
                    <td>
                      <span className="badge bg-primary">Medium</span>
                    </td>
                    <td>Mar 25, 2023</td>
                    <td>
                      <div className="btn-group">
                        <button className="btn btn-sm btn-info">
                          <i className="bi bi-eye"></i>
                        </button>
                        <button className="btn btn-sm btn-primary">
                          <i className="bi bi-pencil"></i>
                        </button>
                        <button className="btn btn-sm btn-danger">
                          <i className="bi bi-trash"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <div className="card-footer clearfix">
            <ul className="pagination pagination-sm m-0 float-end">
              <li className="page-item">
                <a className="page-link" href="#">
                  «
                </a>
              </li>
              <li className="page-item">
                <a className="page-link" href="#">
                  1
                </a>
              </li>
              <li className="page-item">
                <a className="page-link" href="#">
                  2
                </a>
              </li>
              <li className="page-item">
                <a className="page-link" href="#">
                  3
                </a>
              </li>
              <li className="page-item">
                <a className="page-link" href="#">
                  »
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div className="col-12 mt-3">
        <Link href="/tasks/new" className="btn btn-primary">
          <i className="bi bi-plus"></i> Add New Task
        </Link>
      </div>
    </div>
  )
}

