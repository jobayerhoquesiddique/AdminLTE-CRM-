"use client"

import { useEffect } from "react"
import Link from "next/link"

export default function Deals() {
  useEffect(() => {
    // Initialize drag and drop functionality for kanban boards
    const initKanban = async () => {
      try {
        // This is a simple implementation - in a real app, you'd use a proper library
        const kanbanItems = document.querySelectorAll(".kanban-item")
        const kanbanDrags = document.querySelectorAll(".kanban-drag")

        kanbanItems.forEach((item) => {
          item.setAttribute("draggable", "true")

          item.addEventListener("dragstart", (e) => {
            e.dataTransfer?.setData("text/plain", item.id)
            setTimeout(() => {
              item.classList.add("dragging")
            }, 0)
          })

          item.addEventListener("dragend", () => {
            item.classList.remove("dragging")
          })
        })

        kanbanDrags.forEach((container) => {
          container.addEventListener("dragover", (e) => {
            e.preventDefault()
            container.classList.add("drag-over")
          })

          container.addEventListener("dragleave", () => {
            container.classList.remove("drag-over")
          })

          container.addEventListener("drop", (e) => {
            e.preventDefault()
            container.classList.remove("drag-over")
            const id = e.dataTransfer?.getData("text/plain")
            if (id) {
              const draggableElement = document.getElementById(id)
              if (draggableElement) {
                container.appendChild(draggableElement)
              }
            }
          })
        })
      } catch (error) {
        console.error("Error initializing kanban:", error)
      }
    }

    initKanban()
  }, [])

  return (
    <div className="row">
      <div className="col-12">
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Deal Pipeline</h3>
            <div className="card-tools">
              <div className="btn-group">
                <button type="button" className="btn btn-sm btn-primary">
                  All Deals
                </button>
                <button type="button" className="btn btn-sm btn-default">
                  My Deals
                </button>
              </div>
            </div>
          </div>
          <div className="card-body">
            <div className="kanban-container">
              {/* Prospect Stage */}
              <div className="kanban-board">
                <div className="kanban-board-header" style={{ backgroundColor: "#6c757d" }}>
                  <div className="kanban-title-board">Prospect</div>
                  <div className="kanban-title-button">
                    <span className="badge bg-light text-dark">3</span>
                  </div>
                </div>
                <div className="kanban-drag">
                  <div className="kanban-item" id="deal-1">
                    <div className="d-flex justify-content-between align-items-center mb-2">
                      <h5 className="mb-0">Website Redesign</h5>
                      <span className="badge bg-primary">$5,000</span>
                    </div>
                    <p className="mb-1">Future Tech</p>
                    <div className="d-flex justify-content-between align-items-center">
                      <small className="text-muted">Added: Mar 15, 2023</small>
                      <Link href="/deals/1" className="btn btn-xs btn-info">
                        <i className="bi bi-eye"></i>
                      </Link>
                    </div>
                  </div>
                  <div className="kanban-item" id="deal-2">
                    <div className="d-flex justify-content-between align-items-center mb-2">
                      <h5 className="mb-0">IT Consulting</h5>
                      <span className="badge bg-primary">$3,500</span>
                    </div>
                    <p className="mb-1">Innovative Solutions</p>
                    <div className="d-flex justify-content-between align-items-center">
                      <small className="text-muted">Added: Mar 10, 2023</small>
                      <Link href="/deals/2" className="btn btn-xs btn-info">
                        <i className="bi bi-eye"></i>
                      </Link>
                    </div>
                  </div>
                  <div className="kanban-item" id="deal-3">
                    <div className="d-flex justify-content-between align-items-center mb-2">
                      <h5 className="mb-0">Security Audit</h5>
                      <span className="badge bg-primary">$7,500</span>
                    </div>
                    <p className="mb-1">Global Systems</p>
                    <div className="d-flex justify-content-between align-items-center">
                      <small className="text-muted">Added: Mar 5, 2023</small>
                      <Link href="/deals/3" className="btn btn-xs btn-info">
                        <i className="bi bi-eye"></i>
                      </Link>
                    </div>
                  </div>
                </div>
              </div>

              {/* Qualification Stage */}
              <div className="kanban-board">
                <div className="kanban-board-header" style={{ backgroundColor: "#17a2b8" }}>
                  <div className="kanban-title-board">Qualification</div>
                  <div className="kanban-title-button">
                    <span className="badge bg-light text-dark">2</span>
                  </div>
                </div>
                <div className="kanban-drag">
                  <div className="kanban-item" id="deal-4">
                    <div className="d-flex justify-content-between align-items-center mb-2">
                      <h5 className="mb-0">Cloud Migration</h5>
                      <span className="badge bg-primary">$12,000</span>
                    </div>
                    <p className="mb-1">Eastern Enterprises</p>
                    <div className="d-flex justify-content-between align-items-center">
                      <small className="text-muted">Added: Feb 28, 2023</small>
                      <Link href="/deals/4" className="btn btn-xs btn-info">
                        <i className="bi bi-eye"></i>
                      </Link>
                    </div>
                  </div>
                  <div className="kanban-item" id="deal-5">
                    <div className="d-flex justify-content-between align-items-center mb-2">
                      <h5 className="mb-0">Software License</h5>
                      <span className="badge bg-primary">$8,000</span>
                    </div>
                    <p className="mb-1">Modern Solutions</p>
                    <div className="d-flex justify-content-between align-items-center">
                      <small className="text-muted">Added: Feb 25, 2023</small>
                      <Link href="/deals/5" className="btn btn-xs btn-info">
                        <i className="bi bi-eye"></i>
                      </Link>
                    </div>
                  </div>
                </div>
              </div>

              {/* Proposal Stage */}
              <div className="kanban-board">
                <div className="kanban-board-header" style={{ backgroundColor: "#ffc107" }}>
                  <div className="kanban-title-board">Proposal</div>
                  <div className="kanban-title-button">
                    <span className="badge bg-light text-dark">2</span>
                  </div>
                </div>
                <div className="kanban-drag">
                  <div className="kanban-item" id="deal-6">
                    <div className="d-flex justify-content-between align-items-center mb-2">
                      <h5 className="mb-0">Network Upgrade</h5>
                      <span className="badge bg-primary">$15,000</span>
                    </div>
                    <p className="mb-1">Acme Inc.</p>
                    <div className="d-flex justify-content-between align-items-center">
                      <small className="text-muted">Added: Feb 20, 2023</small>
                      <Link href="/deals/6" className="btn btn-xs btn-info">
                        <i className="bi bi-eye"></i>
                      </Link>
                    </div>
                  </div>
                  <div className="kanban-item" id="deal-7">
                    <div className="d-flex justify-content-between align-items-center mb-2">
                      <h5 className="mb-0">Data Analytics</h5>
                      <span className="badge bg-primary">$9,500</span>
                    </div>
                    <p className="mb-1">TechGiant Corp</p>
                    <div className="d-flex justify-content-between align-items-center">
                      <small className="text-muted">Added: Feb 15, 2023</small>
                      <Link href="/deals/7" className="btn btn-xs btn-info">
                        <i className="bi bi-eye"></i>
                      </Link>
                    </div>
                  </div>
                </div>
              </div>

              {/* Negotiation Stage */}
              <div className="kanban-board">
                <div className="kanban-board-header" style={{ backgroundColor: "#fd7e14" }}>
                  <div className="kanban-title-board">Negotiation</div>
                  <div className="kanban-title-button">
                    <span className="badge bg-light text-dark">1</span>
                  </div>
                </div>
                <div className="kanban-drag">
                  <div className="kanban-item" id="deal-8">
                    <div className="d-flex justify-content-between align-items-center mb-2">
                      <h5 className="mb-0">Support Contract</h5>
                      <span className="badge bg-primary">$20,000</span>
                    </div>
                    <p className="mb-1">Startup Solutions</p>
                    <div className="d-flex justify-content-between align-items-center">
                      <small className="text-muted">Added: Feb 10, 2023</small>
                      <Link href="/deals/8" className="btn btn-xs btn-info">
                        <i className="bi bi-eye"></i>
                      </Link>
                    </div>
                  </div>
                </div>
              </div>

              {/* Closed Won Stage */}
              <div className="kanban-board">
                <div className="kanban-board-header" style={{ backgroundColor: "#28a745" }}>
                  <div className="kanban-title-board">Closed Won</div>
                  <div className="kanban-title-button">
                    <span className="badge bg-light text-dark">2</span>
                  </div>
                </div>
                <div className="kanban-drag">
                  <div className="kanban-item" id="deal-9">
                    <div className="d-flex justify-content-between align-items-center mb-2">
                      <h5 className="mb-0">Hardware Upgrade</h5>
                      <span className="badge bg-success">$7,200</span>
                    </div>
                    <p className="mb-1">Local Business LLC</p>
                    <div className="d-flex justify-content-between align-items-center">
                      <small className="text-muted">Closed: Feb 5, 2023</small>
                      <Link href="/deals/9" className="btn btn-xs btn-info">
                        <i className="bi bi-eye"></i>
                      </Link>
                    </div>
                  </div>
                  <div className="kanban-item" id="deal-10">
                    <div className="d-flex justify-content-between align-items-center mb-2">
                      <h5 className="mb-0">Software Package</h5>
                      <span className="badge bg-success">$15,000</span>
                    </div>
                    <p className="mb-1">Acme Inc.</p>
                    <div className="d-flex justify-content-between align-items-center">
                      <small className="text-muted">Closed: Jan 30, 2023</small>
                      <Link href="/deals/10" className="btn btn-xs btn-info">
                        <i className="bi bi-eye"></i>
                      </Link>
                    </div>
                  </div>
                </div>
              </div>

              {/* Closed Lost Stage */}
              <div className="kanban-board">
                <div className="kanban-board-header" style={{ backgroundColor: "#dc3545" }}>
                  <div className="kanban-title-board">Closed Lost</div>
                  <div className="kanban-title-button">
                    <span className="badge bg-light text-dark">1</span>
                  </div>
                </div>
                <div className="kanban-drag">
                  <div className="kanban-item" id="deal-11">
                    <div className="d-flex justify-content-between align-items-center mb-2">
                      <h5 className="mb-0">Support Contract</h5>
                      <span className="badge bg-danger">$5,000</span>
                    </div>
                    <p className="mb-1">Global Enterprises</p>
                    <div className="d-flex justify-content-between align-items-center">
                      <small className="text-muted">Lost: Jan 25, 2023</small>
                      <Link href="/deals/11" className="btn btn-xs btn-info">
                        <i className="bi bi-eye"></i>
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="card-footer">
            <Link href="/deals/new" className="btn btn-primary">
              <i className="bi bi-plus"></i> Add New Deal
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}

