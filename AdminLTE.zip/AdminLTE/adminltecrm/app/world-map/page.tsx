"use client"

// Import the custom hook for map libraries
import { useMapLibraries } from "@/lib/hooks/useMapLibraries"
import { useState, useRef, useEffect } from "react"
import { useCrm } from "@/lib/context/CrmContext"
import { LoadingSpinner } from "@/components/ui/loading-spinner"

export default function WorldMap() {
  const { state } = useCrm()
  const { customers, isLoading } = state
  const [mapLoaded, setMapLoaded] = useState(false)
  const mapRef = useRef<HTMLDivElement>(null)
  const [selectedRegion, setSelectedRegion] = useState<string | null>(null)
  const [regionData, setRegionData] = useState<any[]>([])
  const [mapView, setMapView] = useState<"customers" | "sales" | "leads">("customers")

  // Use the custom hook to load map libraries
  const { allLibrariesLoaded, error } = useMapLibraries()

  // Sample data for regions
  const regions = {
    "North America": { customers: 45, sales: 1250000, leads: 120 },
    "South America": { customers: 18, sales: 450000, leads: 65 },
    Europe: { customers: 38, sales: 980000, leads: 95 },
    Africa: { customers: 12, sales: 320000, leads: 40 },
    Asia: { customers: 52, sales: 1450000, leads: 135 },
    Oceania: { customers: 15, sales: 380000, leads: 30 },
  }

  // Initialize map when libraries are loaded
  useEffect(() => {
    if (allLibrariesLoaded && mapRef.current && !mapLoaded && !isLoading) {
      initializeMap()
    }
  }, [allLibrariesLoaded, mapLoaded, isLoading])

  // Update map when view changes
  useEffect(() => {
    if (mapLoaded && mapRef.current) {
      // Destroy previous map
      if (typeof window !== "undefined" && window.jQuery) {
        window.jQuery(mapRef.current).empty()
      }
      setMapLoaded(false)

      if (allLibrariesLoaded) {
        initializeMap()
      }
    }
  }, [mapView, allLibrariesLoaded])

  // Function to initialize the map
  const initializeMap = () => {
    if (!mapRef.current || !window.jQuery) return

    const $ = window.jQuery

    // Prepare data based on view
    const mapData: Record<string, number> = {}

    // Sample country codes and values
    const countryCodes: Record<string, number> = {
      US: 100,
      CA: 50,
      MX: 30, // North America
      BR: 70,
      AR: 40,
      CO: 30, // South America
      GB: 60,
      DE: 80,
      FR: 70,
      IT: 50,
      ES: 45, // Europe
      ZA: 35,
      NG: 25,
      EG: 30, // Africa
      CN: 120,
      IN: 90,
      JP: 70,
      KR: 50, // Asia
      AU: 65,
      NZ: 30, // Oceania
    }

    // Adjust values based on selected view
    Object.entries(countryCodes).forEach(([code, value]) => {
      if (mapView === "customers") {
        mapData[code] = value
      } else if (mapView === "sales") {
        mapData[code] = value * 10000
      } else if (mapView === "leads") {
        mapData[code] = Math.round(value * 1.5)
      }
    })

    try {
      // Initialize the map
      $(mapRef.current).vectorMap({
        map: "world_mill",
        backgroundColor: "transparent",
        zoomOnScroll: true,
        regionStyle: {
          initial: {
            fill: "#e4e4e4",
            "fill-opacity": 0.9,
            stroke: "none",
            "stroke-width": 0,
            "stroke-opacity": 0,
          },
          hover: {
            "fill-opacity": 0.8,
            cursor: "pointer",
          },
          selected: {
            fill: "#0d6efd",
          },
          selectedHover: {},
        },
        series: {
          regions: [
            {
              values: mapData,
              scale: ["#C8EEFF", "#0071A4"],
              normalizeFunction: "polynomial",
            },
          ],
        },
        onRegionTipShow: (e: any, el: any, code: string) => {
          if (!el || !code) return

          // Get region name
          const regionName = el.html()

          // Display tooltip based on view
          if (mapView === "customers") {
            el.html(`${regionName}: ${mapData[code] || 0} customers`)
          } else if (mapView === "sales") {
            el.html(`${regionName}: $${(mapData[code] || 0).toLocaleString()} sales`)
          } else if (mapView === "leads") {
            el.html(`${regionName}: ${mapData[code] || 0} leads`)
          }
        },
        onRegionClick: (e: any, code: string) => {
          if (!code) return

          // Find which major region this country belongs to
          let majorRegion = ""
          if (["US", "CA", "MX"].includes(code)) majorRegion = "North America"
          else if (["BR", "AR", "CO", "CL", "PE", "VE"].includes(code)) majorRegion = "South America"
          else if (
            [
              "GB",
              "DE",
              "FR",
              "IT",
              "ES",
              "PT",
              "NL",
              "BE",
              "CH",
              "AT",
              "SE",
              "NO",
              "DK",
              "FI",
              "PL",
              "RO",
              "GR",
            ].includes(code)
          )
            majorRegion = "Europe"
          else if (["ZA", "NG", "EG", "DZ", "MA", "KE", "ET", "GH", "TZ"].includes(code)) majorRegion = "Africa"
          else if (
            ["CN", "IN", "JP", "KR", "ID", "PH", "VN", "TH", "MY", "SG", "SA", "AE", "IL", "TR", "RU"].includes(code)
          )
            majorRegion = "Asia"
          else if (["AU", "NZ", "PG", "FJ"].includes(code)) majorRegion = "Oceania"
          else majorRegion = "Other"

          setSelectedRegion(majorRegion)

          // Generate sample data for the region
          const sampleData = []
          for (let i = 0; i < 5; i++) {
            sampleData.push({
              id: `cust-${majorRegion}-${i}`,
              name: `${majorRegion} Customer ${i + 1}`,
              email: `customer${i + 1}@${majorRegion.toLowerCase().replace(" ", "")}.com`,
              phone: `+1-555-${Math.floor(1000 + Math.random() * 9000)}`,
              company: `${majorRegion} Corp ${i + 1}`,
              status: Math.random() > 0.3 ? "Active" : "Inactive",
              value: Math.floor(10000 + Math.random() * 90000),
            })
          }
          setRegionData(sampleData)
        },
      })

      setMapLoaded(true)
    } catch (mapError) {
      console.error("Error initializing jVectorMap:", mapError)
    }
  }

  if (isLoading) {
    return <LoadingSpinner />
  }

  if (error) {
    return (
      <div className="alert alert-danger">
        <h4 className="alert-heading">Error Loading Map</h4>
        <p>{error}</p>
        <hr />
        <p className="mb-0">Please refresh the page or try again later.</p>
      </div>
    )
  }

  return (
    <div className="row">
      <div className="col-md-12">
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Global Distribution</h3>
            <div className="card-tools">
              <div className="btn-group">
                <button
                  type="button"
                  className={`btn btn-sm ${mapView === "customers" ? "btn-primary" : "btn-default"}`}
                  onClick={() => setMapView("customers")}
                >
                  Customers
                </button>
                <button
                  type="button"
                  className={`btn btn-sm ${mapView === "sales" ? "btn-primary" : "btn-default"}`}
                  onClick={() => setMapView("sales")}
                >
                  Sales
                </button>
                <button
                  type="button"
                  className={`btn btn-sm ${mapView === "leads" ? "btn-primary" : "btn-default"}`}
                  onClick={() => setMapView("leads")}
                >
                  Leads
                </button>
              </div>
            </div>
          </div>
          <div className="card-body">
            <div className="row mb-4">
              <div className="col-md-3 col-sm-6 col-12">
                <div className="info-box">
                  <span className="info-box-icon bg-info">
                    <i className="bi bi-globe"></i>
                  </span>
                  <div className="info-box-content">
                    <span className="info-box-text">Total Countries</span>
                    <span className="info-box-number">42</span>
                  </div>
                </div>
              </div>
              <div className="col-md-3 col-sm-6 col-12">
                <div className="info-box">
                  <span className="info-box-icon bg-success">
                    <i className="bi bi-people"></i>
                  </span>
                  <div className="info-box-content">
                    <span className="info-box-text">Global Customers</span>
                    <span className="info-box-number">{customers.length}</span>
                  </div>
                </div>
              </div>
              <div className="col-md-3 col-sm-6 col-12">
                <div className="info-box">
                  <span className="info-box-icon bg-warning">
                    <i className="bi bi-currency-dollar"></i>
                  </span>
                  <div className="info-box-content">
                    <span className="info-box-text">Global Revenue</span>
                    <span className="info-box-number">$4,830,000</span>
                  </div>
                </div>
              </div>
              <div className="col-md-3 col-sm-6 col-12">
                <div className="info-box">
                  <span className="info-box-icon bg-danger">
                    <i className="bi bi-building"></i>
                  </span>
                  <div className="info-box-content">
                    <span className="info-box-text">Regional Offices</span>
                    <span className="info-box-number">6</span>
                  </div>
                </div>
              </div>
            </div>

            {!allLibrariesLoaded || !mapLoaded ? (
              <div className="d-flex justify-content-center align-items-center" style={{ height: "500px" }}>
                <div className="spinner-border text-primary" role="status">
                  <span className="visually-hidden">Loading...</span>
                </div>
              </div>
            ) : (
              <div ref={mapRef} style={{ height: "500px", width: "100%" }}></div>
            )}
          </div>
        </div>
      </div>

      {selectedRegion && (
        <div className="col-md-12 mt-3">
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">{selectedRegion} Details</h3>
              <div className="card-tools">
                <button type="button" className="btn btn-tool" onClick={() => setSelectedRegion(null)}>
                  <i className="bi bi-x"></i>
                </button>
              </div>
            </div>
            <div className="card-body">
              <div className="row mb-4">
                <div className="col-md-4">
                  <div className="small-box bg-info">
                    <div className="inner">
                      <h3>{regions[selectedRegion as keyof typeof regions]?.customers || 0}</h3>
                      <p>Customers</p>
                    </div>
                    <div className="icon">
                      <i className="bi bi-people"></i>
                    </div>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="small-box bg-success">
                    <div className="inner">
                      <h3>${(regions[selectedRegion as keyof typeof regions]?.sales || 0).toLocaleString()}</h3>
                      <p>Revenue</p>
                    </div>
                    <div className="icon">
                      <i className="bi bi-currency-dollar"></i>
                    </div>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="small-box bg-warning">
                    <div className="inner">
                      <h3>{regions[selectedRegion as keyof typeof regions]?.leads || 0}</h3>
                      <p>Leads</p>
                    </div>
                    <div className="icon">
                      <i className="bi bi-funnel"></i>
                    </div>
                  </div>
                </div>
              </div>

              <h5>Top Customers in {selectedRegion}</h5>
              <div className="table-responsive">
                <table className="table table-striped">
                  <thead>
                    <tr>
                      <th>Customer</th>
                      <th>Email</th>
                      <th>Phone</th>
                      <th>Company</th>
                      <th>Status</th>
                      <th>Value</th>
                    </tr>
                  </thead>
                  <tbody>
                    {regionData.map((customer) => (
                      <tr key={customer.id}>
                        <td>{customer.name}</td>
                        <td>{customer.email}</td>
                        <td>{customer.phone}</td>
                        <td>{customer.company}</td>
                        <td>
                          <span className={`badge ${customer.status === "Active" ? "bg-success" : "bg-secondary"}`}>
                            {customer.status}
                          </span>
                        </td>
                        <td>${customer.value.toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
            <div className="card-footer">
              <button className="btn btn-primary">
                <i className="bi bi-download me-1"></i> Export {selectedRegion} Report
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

