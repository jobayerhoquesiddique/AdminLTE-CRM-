"use client"

import type React from "react"

import { useState } from "react"
import { useCrm } from "@/lib/context/CrmContext"
import { LoadingSpinner } from "@/components/ui/loading-spinner"

// Add proper type definitions for products
interface Product {
  id: string
  name: string
  sku: string
  category: string
  price: number
  cost: number
  description: string
  inStock: number
  status: string
  created: string
  lastUpdated: string
}

export default function Products() {
  const { state, dispatch, generateId } = useCrm()
  const { products, isLoading } = state
  const [showAddModal, setShowAddModal] = useState(false)
  const [showEditModal, setShowEditModal] = useState(false)
  const [showDeleteModal, setShowDeleteModal] = useState(false)
  const [selectedProduct, setSelectedProduct] = useState<any>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [filterCategory, setFilterCategory] = useState("All")
  const [sortField, setSortField] = useState("name")
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc")
  const [newProduct, setNewProduct] = useState({
    name: "",
    sku: "",
    category: "Software",
    price: 0,
    cost: 0,
    description: "",
    inStock: 0,
    status: "Active",
  })

  // Get unique categories
  const categories = ["All", ...new Set(products.map((product) => product.category))]

  // Filter and sort products
  const filteredProducts = products
    .filter((product) => {
      const matchesSearch =
        product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.description.toLowerCase().includes(searchTerm.toLowerCase())
      const matchesCategory = filterCategory === "All" || product.category === filterCategory
      return matchesSearch && matchesCategory
    })
    .sort((a, b) => {
      const fieldA = a[sortField as keyof typeof a]
      const fieldB = b[sortField as keyof typeof b]

      if (typeof fieldA === "string" && typeof fieldB === "string") {
        return sortDirection === "asc" ? fieldA.localeCompare(fieldB) : fieldB.localeCompare(fieldA)
      } else {
        return sortDirection === "asc"
          ? (fieldA as number) - (fieldB as number)
          : (fieldB as number) - (fieldA as number)
      }
    })

  // Update the handleSort function to handle different field types
  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc")
    } else {
      setSortField(field)
      setSortDirection("asc")
    }
  }

  // Update the handleInputChange function to properly handle different input types
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target

    // Handle numeric inputs properly
    let parsedValue: string | number = value
    if (type === "number") {
      parsedValue = value === "" ? 0 : Number.parseFloat(value)
    }

    if (showEditModal && selectedProduct) {
      setSelectedProduct({
        ...selectedProduct,
        [name]: parsedValue,
      })
    } else {
      setNewProduct({
        ...newProduct,
        [name]: parsedValue,
      })
    }
  }

  const handleAddProduct = (e: React.FormEvent) => {
    e.preventDefault()
    const product = {
      id: generateId(),
      ...newProduct,
      created: new Date().toISOString().split("T")[0],
      lastUpdated: new Date().toISOString().split("T")[0],
    }
    dispatch({ type: "ADD_PRODUCT", payload: product })
    setNewProduct({
      name: "",
      sku: "",
      category: "Software",
      price: 0,
      cost: 0,
      description: "",
      inStock: 0,
      status: "Active",
    })
    setShowAddModal(false)
  }

  const handleEditProduct = (e: React.FormEvent) => {
    e.preventDefault()
    if (selectedProduct) {
      const updatedProduct = {
        ...selectedProduct,
        lastUpdated: new Date().toISOString().split("T")[0],
      }
      dispatch({ type: "UPDATE_PRODUCT", payload: updatedProduct })
      setShowEditModal(false)
    }
  }

  const handleDeleteProduct = () => {
    if (selectedProduct) {
      dispatch({ type: "DELETE_PRODUCT", payload: selectedProduct.id })
      setShowDeleteModal(false)
    }
  }

  if (isLoading) {
    return <LoadingSpinner />
  }

  return (
    <div className="row">
      <div className="col-12">
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Products</h3>
            <div className="card-tools">
              <div className="input-group input-group-sm" style={{ width: "150px" }}>
                <input
                  type="text"
                  name="table_search"
                  className="form-control float-right"
                  placeholder="Search"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                <div className="input-group-append">
                  <button type="submit" className="btn btn-default">
                    <i className="bi bi-search"></i>
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div className="card-body">
            <div className="d-flex justify-content-between mb-3">
              <div>
                <button className="btn btn-primary me-2" onClick={() => setShowAddModal(true)}>
                  <i className="bi bi-plus-circle me-1"></i> Add Product
                </button>
                <div className="btn-group me-2">
                  <button type="button" className="btn btn-default dropdown-toggle" data-bs-toggle="dropdown">
                    Category: {filterCategory}
                  </button>
                  <ul className="dropdown-menu">
                    {categories.map((category) => (
                      <li key={category}>
                        <a
                          className="dropdown-item"
                          href="#"
                          onClick={(e) => {
                            e.preventDefault()
                            setFilterCategory(category)
                          }}
                        >
                          {category}
                        </a>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
              <div>
                <button className="btn btn-outline-success me-2">
                  <i className="bi bi-file-earmark-excel me-1"></i> Export
                </button>
                <button className="btn btn-outline-primary">
                  <i className="bi bi-printer me-1"></i> Print
                </button>
              </div>
            </div>

            <div className="table-responsive">
              <table className="table table-hover text-nowrap">
                <thead>
                  <tr>
                    <th style={{ cursor: "pointer" }} onClick={() => handleSort("name")}>
                      Product Name
                      {sortField === "name" && (
                        <i className={`bi bi-arrow-${sortDirection === "asc" ? "up" : "down"} ms-1`}></i>
                      )}
                    </th>
                    <th style={{ cursor: "pointer" }} onClick={() => handleSort("sku")}>
                      SKU
                      {sortField === "sku" && (
                        <i className={`bi bi-arrow-${sortDirection === "asc" ? "up" : "down"} ms-1`}></i>
                      )}
                    </th>
                    <th style={{ cursor: "pointer" }} onClick={() => handleSort("category")}>
                      Category
                      {sortField === "category" && (
                        <i className={`bi bi-arrow-${sortDirection === "asc" ? "up" : "down"} ms-1`}></i>
                      )}
                    </th>
                    <th style={{ cursor: "pointer" }} onClick={() => handleSort("price")}>
                      Price
                      {sortField === "price" && (
                        <i className={`bi bi-arrow-${sortDirection === "asc" ? "up" : "down"} ms-1`}></i>
                      )}
                    </th>
                    <th style={{ cursor: "pointer" }} onClick={() => handleSort("inStock")}>
                      In Stock
                      {sortField === "inStock" && (
                        <i className={`bi bi-arrow-${sortDirection === "asc" ? "up" : "down"} ms-1`}></i>
                      )}
                    </th>
                    <th style={{ cursor: "pointer" }} onClick={() => handleSort("status")}>
                      Status
                      {sortField === "status" && (
                        <i className={`bi bi-arrow-${sortDirection === "asc" ? "up" : "down"} ms-1`}></i>
                      )}
                    </th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredProducts.map((product) => (
                    <tr key={product.id}>
                      <td>{product.name}</td>
                      <td>{product.sku}</td>
                      <td>{product.category}</td>
                      <td>${product.price.toLocaleString()}</td>
                      <td>{product.inStock}</td>
                      <td>
                        <span className={`badge ${product.status === "Active" ? "bg-success" : "bg-secondary"}`}>
                          {product.status}
                        </span>
                      </td>
                      <td>
                        <button
                          className="btn btn-info btn-sm me-1"
                          onClick={() => {
                            setSelectedProduct(product)
                            setShowEditModal(true)
                          }}
                        >
                          <i className="bi bi-eye"></i>
                        </button>
                        <button
                          className="btn btn-primary btn-sm me-1"
                          onClick={() => {
                            setSelectedProduct(product)
                            setShowEditModal(true)
                          }}
                        >
                          <i className="bi bi-pencil"></i>
                        </button>
                        <button
                          className="btn btn-danger btn-sm"
                          onClick={() => {
                            setSelectedProduct(product)
                            setShowDeleteModal(true)
                          }}
                        >
                          <i className="bi bi-trash"></i>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          <div className="card-footer clearfix">
            <ul className="pagination pagination-sm m-0 float-end">
              <li className="page-item">
                <a className="page-link" href="#">
                  «
                </a>
              </li>
              <li className="page-item">
                <a className="page-link" href="#">
                  1
                </a>
              </li>
              <li className="page-item">
                <a className="page-link" href="#">
                  2
                </a>
              </li>
              <li className="page-item">
                <a className="page-link" href="#">
                  3
                </a>
              </li>
              <li className="page-item">
                <a className="page-link" href="#">
                  »
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Add Product Modal */}
      {showAddModal && (
        <div className="modal fade show" style={{ display: "block", backgroundColor: "rgba(0,0,0,0.5)" }}>
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Add New Product</h5>
                <button type="button" className="btn-close" onClick={() => setShowAddModal(false)}></button>
              </div>
              <form onSubmit={handleAddProduct}>
                <div className="modal-body">
                  <div className="row mb-3">
                    <div className="col-md-6">
                      <div className="form-group">
                        <label htmlFor="name">Product Name</label>
                        <input
                          type="text"
                          className="form-control"
                          id="name"
                          name="name"
                          value={newProduct.name}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="form-group">
                        <label htmlFor="sku">SKU</label>
                        <input
                          type="text"
                          className="form-control"
                          id="sku"
                          name="sku"
                          value={newProduct.sku}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col-md-6">
                      <div className="form-group">
                        <label htmlFor="category">Category</label>
                        <select
                          className="form-control"
                          id="category"
                          name="category"
                          value={newProduct.category}
                          onChange={handleInputChange}
                        >
                          <option value="Software">Software</option>
                          <option value="Hardware">Hardware</option>
                          <option value="Services">Services</option>
                          <option value="Accessories">Accessories</option>
                        </select>
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="form-group">
                        <label htmlFor="status">Status</label>
                        <select
                          className="form-control"
                          id="status"
                          name="status"
                          value={newProduct.status}
                          onChange={handleInputChange}
                        >
                          <option value="Active">Active</option>
                          <option value="Inactive">Inactive</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col-md-4">
                      <div className="form-group">
                        <label htmlFor="price">Price ($)</label>
                        <input
                          type="number"
                          className="form-control"
                          id="price"
                          name="price"
                          value={newProduct.price}
                          onChange={handleInputChange}
                          min="0"
                          step="0.01"
                          required
                        />
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="form-group">
                        <label htmlFor="cost">Cost ($)</label>
                        <input
                          type="number"
                          className="form-control"
                          id="cost"
                          name="cost"
                          value={newProduct.cost}
                          onChange={handleInputChange}
                          min="0"
                          step="0.01"
                          required
                        />
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="form-group">
                        <label htmlFor="inStock">In Stock</label>
                        <input
                          type="number"
                          className="form-control"
                          id="inStock"
                          name="inStock"
                          value={newProduct.inStock}
                          onChange={handleInputChange}
                          min="0"
                          required
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-group mb-3">
                    <label htmlFor="description">Description</label>
                    <textarea
                      className="form-control"
                      id="description"
                      name="description"
                      rows={3}
                      value={newProduct.description}
                      onChange={handleInputChange}
                    ></textarea>
                  </div>
                </div>
                <div className="modal-footer">
                  <button type="button" className="btn btn-secondary" onClick={() => setShowAddModal(false)}>
                    Cancel
                  </button>
                  <button type="submit" className="btn btn-primary">
                    Add Product
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Edit Product Modal */}
      {showEditModal && selectedProduct && (
        <div className="modal fade show" style={{ display: "block", backgroundColor: "rgba(0,0,0,0.5)" }}>
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Edit Product: {selectedProduct.name}</h5>
                <button type="button" className="btn-close" onClick={() => setShowEditModal(false)}></button>
              </div>
              <form onSubmit={handleEditProduct}>
                <div className="modal-body">
                  <div className="row mb-3">
                    <div className="col-md-6">
                      <div className="form-group">
                        <label htmlFor="editName">Product Name</label>
                        <input
                          type="text"
                          className="form-control"
                          id="editName"
                          name="name"
                          value={selectedProduct.name}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="form-group">
                        <label htmlFor="editSku">SKU</label>
                        <input
                          type="text"
                          className="form-control"
                          id="editSku"
                          name="sku"
                          value={selectedProduct.sku}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col-md-6">
                      <div className="form-group">
                        <label htmlFor="editCategory">Category</label>
                        <select
                          className="form-control"
                          id="editCategory"
                          name="category"
                          value={selectedProduct.category}
                          onChange={handleInputChange}
                        >
                          <option value="Software">Software</option>
                          <option value="Hardware">Hardware</option>
                          <option value="Services">Services</option>
                          <option value="Accessories">Accessories</option>
                        </select>
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="form-group">
                        <label htmlFor="editStatus">Status</label>
                        <select
                          className="form-control"
                          id="editStatus"
                          name="status"
                          value={selectedProduct.status}
                          onChange={handleInputChange}
                        >
                          <option value="Active">Active</option>
                          <option value="Inactive">Inactive</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col-md-4">
                      <div className="form-group">
                        <label htmlFor="editPrice">Price ($)</label>
                        <input
                          type="number"
                          className="form-control"
                          id="editPrice"
                          name="price"
                          value={selectedProduct.price}
                          onChange={handleInputChange}
                          min="0"
                          step="0.01"
                          required
                        />
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="form-group">
                        <label htmlFor="editCost">Cost ($)</label>
                        <input
                          type="number"
                          className="form-control"
                          id="editCost"
                          name="cost"
                          value={selectedProduct.cost}
                          onChange={handleInputChange}
                          min="0"
                          step="0.01"
                          required
                        />
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="form-group">
                        <label htmlFor="editInStock">In Stock</label>
                        <input
                          type="number"
                          className="form-control"
                          id="editInStock"
                          name="inStock"
                          value={selectedProduct.inStock}
                          onChange={handleInputChange}
                          min="0"
                          required
                        />
                      </div>
                    </div>
                  </div>
                  <div className="form-group mb-3">
                    <label htmlFor="editDescription">Description</label>
                    <textarea
                      className="form-control"
                      id="editDescription"
                      name="description"
                      rows={3}
                      value={selectedProduct.description}
                      onChange={handleInputChange}
                    ></textarea>
                  </div>
                  <div className="row mb-3">
                    <div className="col-md-6">
                      <div className="form-group">
                        <label>Created Date</label>
                        <input type="text" className="form-control" value={selectedProduct.created} readOnly />
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="form-group">
                        <label>Last Updated</label>
                        <input type="text" className="form-control" value={selectedProduct.lastUpdated} readOnly />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="modal-footer">
                  <button type="button" className="btn btn-secondary" onClick={() => setShowEditModal(false)}>
                    Cancel
                  </button>
                  <button type="submit" className="btn btn-primary">
                    Save Changes
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Delete Product Modal */}
      {showDeleteModal && selectedProduct && (
        <div className="modal fade show" style={{ display: "block", backgroundColor: "rgba(0,0,0,0.5)" }}>
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Delete Product</h5>
                <button type="button" className="btn-close" onClick={() => setShowDeleteModal(false)}></button>
              </div>
              <div className="modal-body">
                <p>
                  Are you sure you want to delete the product <strong>{selectedProduct.name}</strong>?
                </p>
                <p className="text-danger">This action cannot be undone.</p>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowDeleteModal(false)}>
                  Cancel
                </button>
                <button type="button" className="btn btn-danger" onClick={handleDeleteProduct}>
                  Delete Product
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

