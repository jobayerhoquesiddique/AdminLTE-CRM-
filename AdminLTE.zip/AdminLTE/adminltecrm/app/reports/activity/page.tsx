"use client"

import { useEffect } from "react"
import Link from "next/link"

export default function ActivityReport() {
  useEffect(() => {
    // Load ApexCharts dynamically on the client side
    const loadApexCharts = async () => {
      try {
        const ApexCharts = (await import("apexcharts")).default

        // Activity by Type Chart
        const activityTypeChartOptions = {
          series: [44, 55, 13, 33],
          chart: {
            width: "100%",
            type: "pie",
          },
          labels: ["Calls", "Emails", "Meetings", "Tasks"],
          colors: ["#0d6efd", "#20c997", "#ffc107", "#dc3545"],
          responsive: [
            {
              breakpoint: 480,
              options: {
                chart: {
                  width: 200,
                },
                legend: {
                  position: "bottom",
                },
              },
            },
          ],
        }

        // Activity by User Chart
        const activityUserChartOptions = {
          series: [
            {
              name: "Activities",
              data: [44, 55, 41, 37, 22],
            },
          ],
          chart: {
            type: "bar",
            height: 300,
            toolbar: {
              show: false,
            },
          },
          plotOptions: {
            bar: {
              horizontal: true,
              dataLabels: {
                position: "top",
              },
            },
          },
          colors: ["#0d6efd"],
          dataLabels: {
            enabled: true,
            offsetX: -6,
            style: {
              fontSize: "12px",
              colors: ["#fff"],
            },
          },
          xaxis: {
            categories: ["John Doe", "Sarah Johnson", "Michael Brown", "Emily Davis", "Robert Wilson"],
          },
        }

        // Activity Timeline Chart
        const activityTimelineChartOptions = {
          series: [
            {
              name: "Calls",
              data: [31, 40, 28, 51, 42, 109, 100],
            },
            {
              name: "Emails",
              data: [11, 32, 45, 32, 34, 52, 41],
            },
            {
              name: "Meetings",
              data: [15, 11, 19, 22, 25, 13, 18],
            },
          ],
          chart: {
            height: 300,
            type: "area",
            toolbar: {
              show: false,
            },
          },
          colors: ["#0d6efd", "#20c997", "#ffc107"],
          dataLabels: {
            enabled: false,
          },
          stroke: {
            curve: "smooth",
          },
          xaxis: {
            type: "datetime",
            categories: [
              "2023-03-01",
              "2023-03-02",
              "2023-03-03",
              "2023-03-04",
              "2023-03-05",
              "2023-03-06",
              "2023-03-07",
            ],
          },
          tooltip: {
            x: {
              format: "dd/MM/yy",
            },
          },
        }

        // Initialize charts if elements exist
        const activityTypeChartElement = document.getElementById("activityTypeChart")
        const activityUserChartElement = document.getElementById("activityUserChart")
        const activityTimelineChartElement = document.getElementById("activityTimelineChart")

        if (activityTypeChartElement) {
          new ApexCharts(activityTypeChartElement, activityTypeChartOptions).render()
        }

        if (activityUserChartElement) {
          new ApexCharts(activityUserChartElement, activityUserChartOptions).render()
        }

        if (activityTimelineChartElement) {
          new ApexCharts(activityTimelineChartElement, activityTimelineChartOptions).render()
        }
      } catch (error) {
        console.error("Error loading ApexCharts:", error)
      }
    }

    loadApexCharts()
  }, [])

  return (
    <div className="row">
      <div className="col-md-12">
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Activity Report</h3>
            <div className="card-tools">
              <div className="btn-group">
                <button type="button" className="btn btn-sm btn-primary">
                  This Week
                </button>
                <button type="button" className="btn btn-sm btn-default">
                  This Month
                </button>
                <button type="button" className="btn btn-sm btn-default">
                  This Quarter
                </button>
                <button type="button" className="btn btn-sm btn-default">
                  Custom
                </button>
              </div>
            </div>
          </div>
          <div className="card-body">
            <div className="row">
              <div className="col-md-3 col-sm-6 col-12">
                <div className="info-box">
                  <span className="info-box-icon bg-info">
                    <i className="bi bi-telephone"></i>
                  </span>
                  <div className="info-box-content">
                    <span className="info-box-text">Calls</span>
                    <span className="info-box-number">145</span>
                  </div>
                </div>
              </div>
              <div className="col-md-3 col-sm-6 col-12">
                <div className="info-box">
                  <span className="info-box-icon bg-success">
                    <i className="bi bi-envelope"></i>
                  </span>
                  <div className="info-box-content">
                    <span className="info-box-text">Emails</span>
                    <span className="info-box-number">210</span>
                  </div>
                </div>
              </div>
              <div className="col-md-3 col-sm-6 col-12">
                <div className="info-box">
                  <span className="info-box-icon bg-warning">
                    <i className="bi bi-calendar-event"></i>
                  </span>
                  <div className="info-box-content">
                    <span className="info-box-text">Meetings</span>
                    <span className="info-box-number">52</span>
                  </div>
                </div>
              </div>
              <div className="col-md-3 col-sm-6 col-12">
                <div className="info-box">
                  <span className="info-box-icon bg-danger">
                    <i className="bi bi-check2-square"></i>
                  </span>
                  <div className="info-box-content">
                    <span className="info-box-text">Tasks</span>
                    <span className="info-box-number">125</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="row mt-4">
              <div className="col-md-6">
                <div className="card">
                  <div className="card-header">
                    <h3 className="card-title">Activity by Type</h3>
                  </div>
                  <div className="card-body">
                    <div
                      id="activityTypeChart"
                      style={{ minHeight: "300px", height: "300px", maxHeight: "300px", maxWidth: "100%" }}
                    ></div>
                  </div>
                </div>
              </div>
              <div className="col-md-6">
                <div className="card">
                  <div className="card-header">
                    <h3 className="card-title">Activity by User</h3>
                  </div>
                  <div className="card-body">
                    <div
                      id="activityUserChart"
                      style={{ minHeight: "300px", height: "300px", maxHeight: "300px", maxWidth: "100%" }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>

            <div className="row mt-4">
              <div className="col-md-12">
                <div className="card">
                  <div className="card-header">
                    <h3 className="card-title">Activity Timeline</h3>
                  </div>
                  <div className="card-body">
                    <div
                      id="activityTimelineChart"
                      style={{ minHeight: "300px", height: "300px", maxHeight: "300px", maxWidth: "100%" }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>

            <div className="row mt-4">
              <div className="col-md-12">
                <div className="card">
                  <div className="card-header">
                    <h3 className="card-title">Recent Activities</h3>
                  </div>
                  <div className="card-body">
                    <div className="table-responsive">
                      <table className="table table-striped">
                        <thead>
                          <tr>
                            <th>Date & Time</th>
                            <th>User</th>
                            <th>Type</th>
                            <th>Related To</th>
                            <th>Description</th>
                            <th>Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>Mar 15, 2023, 10:30 AM</td>
                            <td>John Doe</td>
                            <td>
                              <span className="badge bg-info">Call</span>
                            </td>
                            <td>
                              <Link href="/customers/1">Acme Inc.</Link>
                            </td>
                            <td>Discussed renewal options for enterprise software package</td>
                            <td>
                              <button className="btn btn-info btn-sm me-1">
                                <i className="bi bi-eye"></i>
                              </button>
                              <button className="btn btn-primary btn-sm">
                                <i className="bi bi-pencil"></i>
                              </button>
                            </td>
                          </tr>
                          <tr>
                            <td>Mar 14, 2023, 3:15 PM</td>
                            <td>Sarah Johnson</td>
                            <td>
                              <span className="badge bg-success">Email</span>
                            </td>
                            <td>
                              <Link href="/customers/2">TechGiant Corp</Link>
                            </td>
                            <td>Sent proposal for the new support contract</td>
                            <td>
                              <button className="btn btn-info btn-sm me-1">
                                <i className="bi bi-eye"></i>
                              </button>
                              <button className="btn btn-primary btn-sm">
                                <i className="bi bi-pencil"></i>
                              </button>
                            </td>
                          </tr>
                          <tr>
                            <td>Mar 14, 2023, 11:00 AM</td>
                            <td>Michael Brown</td>
                            <td>
                              <span className="badge bg-warning">Meeting</span>
                            </td>
                            <td>
                              <Link href="/customers/3">Startup Solutions</Link>
                            </td>
                            <td>Initial consultation about their needs</td>
                            <td>
                              <button className="btn btn-info btn-sm me-1">
                                <i className="bi bi-eye"></i>
                              </button>
                              <button className="btn btn-primary btn-sm">
                                <i className="bi bi-pencil"></i>
                              </button>
                            </td>
                          </tr>
                          <tr>
                            <td>Mar 13, 2023, 2:45 PM</td>
                            <td>Emily Davis</td>
                            <td>
                              <span className="badge bg-danger">Task</span>
                            </td>
                            <td>
                              <Link href="/customers/4">Global Enterprises</Link>
                            </td>
                            <td>Updated customer information and contact details</td>
                            <td>
                              <button className="btn btn-info btn-sm me-1">
                                <i className="bi bi-eye"></i>
                              </button>
                              <button className="btn btn-primary btn-sm">
                                <i className="bi bi-pencil"></i>
                              </button>
                            </td>
                          </tr>
                          <tr>
                            <td>Mar 12, 2023, 9:30 AM</td>
                            <td>Robert Wilson</td>
                            <td>
                              <span className="badge bg-info">Call</span>
                            </td>
                            <td>
                              <Link href="/customers/5">Local Business LLC</Link>
                            </td>
                            <td>Follow-up call about hardware upgrade</td>
                            <td>
                              <button className="btn btn-info btn-sm me-1">
                                <i className="bi bi-eye"></i>
                              </button>
                              <button className="btn btn-primary btn-sm">
                                <i className="bi bi-pencil"></i>
                              </button>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <div className="card-footer clearfix">
                    <ul className="pagination pagination-sm m-0 float-end">
                      <li className="page-item">
                        <a className="page-link" href="#">
                          «
                        </a>
                      </li>
                      <li className="page-item">
                        <a className="page-link" href="#">
                          1
                        </a>
                      </li>
                      <li className="page-item">
                        <a className="page-link" href="#">
                          2
                        </a>
                      </li>
                      <li className="page-item">
                        <a className="page-link" href="#">
                          3
                        </a>
                      </li>
                      <li className="page-item">
                        <a className="page-link" href="#">
                          »
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="card-footer">
            <button type="button" className="btn btn-primary">
              <i className="bi bi-download"></i> Export Report
            </button>
            <button type="button" className="btn btn-default ms-2">
              <i className="bi bi-printer"></i> Print
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

