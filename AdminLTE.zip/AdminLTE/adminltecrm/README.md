# Simple CRM Application

This is a simple CRM (Customer Relationship Management) application that runs without any dependencies or setup. Just open the `index.html` file in your browser to get started!

## Features

- Dashboard with key metrics and charts
- Customer management
- Lead management
- Deal pipeline with drag-and-drop interface
- Task management
- Sales reports with charts
- Activity tracking
- No installation required!

## How to Use

1. Download all files to your computer
2. Open the `index.html` file in any modern web browser (Chrome, Firefox, Edge, Safari)
3. That's it! No server setup, no dependencies, no installation required

## Data Storage

This application uses your browser's localStorage to save data. This means:
- Your data stays on your computer
- No internet connection required
- Data persists between sessions
- Data is limited to your browser (not shared between browsers or devices)

## Technologies Used

- HTML5
- CSS3
- JavaScript (Vanilla)
- Bootstrap 5 (loaded via CDN)
- Chart.js (loaded via CDN)

## Browser Compatibility

This application works best in modern browsers:
- Google Chrome
- Mozilla Firefox
- Microsoft Edge
- Safari

## License

This project is open source and available under the MIT License.

