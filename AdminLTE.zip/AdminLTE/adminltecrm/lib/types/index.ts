// Common types used throughout the application

export interface Customer {
  id: string
  name: string
  company: string
  email: string
  phone: string
  status: string
  created: string
  lastContact?: string
  address?: string
  city?: string
  state?: string
  zip?: string
  country?: string
  notes?: string
  assignedTo?: string
}

export interface Lead {
  id: string
  name: string
  company: string
  email: string
  phone: string
  source: string
  status: string
  score?: number
  created: string
  lastContact?: string
  notes?: string
  assignedTo?: string
}

export interface Deal {
  id: string
  name: string
  customer: string
  value: number
  stage: string
  probability?: number
  expectedCloseDate?: string
  created: string
  lastUpdated: string
  assignedTo?: string
  notes?: string
}

export interface Task {
  id: string
  title: string
  description?: string
  status: string
  priority: string
  dueDate: string
  assignedTo: string
  relatedTo?: {
    type: string
    id: string
  }
  created: string
  completed?: string
}

export interface Event {
  id: string
  title: string
  start: string
  end: string
  allDay: boolean
  type: string
  description: string
  relatedTo: {
    type: string
    id: string
  }
  assignedTo: string
}

export interface Product {
  id: string
  name: string
  sku: string
  category: string
  price: number
  cost: number
  description: string
  inStock: number
  status: string
  created: string
  lastUpdated: string
}

export interface Campaign {
  id: string
  name: string
  type: string
  status: string
  startDate: string
  endDate: string
  budget: number
  spent: number
  leads: number
  conversions: number
  roi: number
  description: string
  assignedTo: string
}

export interface Activity {
  id: string
  type: string
  description: string
  date: string
  time: string
  user: string
  relatedTo?: {
    type: string
    id: string
  }
}

export interface User {
  id: string
  name: string
  email: string
  role: string
  status: string
  lastLogin?: string
  created: string
}

