"use client"

import { useState, useCallback, useMemo } from "react"

/**
 * A hook that provides an optimized state management solution
 * with memoized state updaters to prevent unnecessary re-renders
 *
 * @param initialState The initial state value
 * @returns A tuple containing the state value and a memoized state updater
 */
export function useOptimizedState<T>(
  initialState: T | (() => T),
): [readonly [T], (newState: T | ((prevState: T) => T)) => void] {
  const [state, setState] = useState<T>(initialState)

  // Memoize the state updater function to prevent unnecessary re-renders
  const optimizedSetState = useCallback((newState: T | ((prevState: T) => T)) => {
    setState((prevState) => {
      // If newState is a function, call it with the previous state
      const nextState = typeof newState === "function" ? (newState as (prevState: T) => T)(prevState) : newState

      // Only update state if it has actually changed
      if (JSON.stringify(prevState) !== JSON.stringify(nextState)) {
        return nextState
      }

      return prevState
    })
  }, [])

  // Wrap state in a readonly array to prevent accidental mutations
  const readonlyState = useMemo(() => [state] as const, [state])

  return [readonlyState, optimizedSetState]
}

/**
 * A hook that provides an optimized array state with efficient operations
 *
 * @param initialArray The initial array
 * @returns An object with the array and optimized array operations
 */
export function useOptimizedArray<T>(initialArray: T[] = []) {
  const [[array], setArray] = useOptimizedState<T[]>(initialArray)

  // Add item to the array
  const addItem = useCallback(
    (item: T) => {
      setArray((prev) => [...prev, item])
    },
    [setArray],
  )

  // Remove item from the array
  const removeItem = useCallback(
    (predicate: (item: T, index: number) => boolean) => {
      setArray((prev) => prev.filter((item, index) => !predicate(item, index)))
    },
    [setArray],
  )

  // Update item in the array
  const updateItem = useCallback(
    (predicate: (item: T, index: number) => boolean, newItem: T | ((item: T) => T)) => {
      setArray((prev) =>
        prev.map((item, index) =>
          predicate(item, index) ? (typeof newItem === "function" ? (newItem as Function)(item) : newItem) : item,
        ),
      )
    },
    [setArray],
  )

  // Find item in the array
  const findItem = useCallback(
    (predicate: (item: T, index: number) => boolean) => {
      return array.find((item, index) => predicate(item, index))
    },
    [array],
  )

  // Sort the array
  const sortArray = useCallback(
    (compareFn: (a: T, b: T) => number) => {
      setArray((prev) => [...prev].sort(compareFn))
    },
    [setArray],
  )

  // Filter the array
  const filterArray = useCallback(
    (predicate: (item: T, index: number) => boolean) => {
      return array.filter((item, index) => predicate(item, index))
    },
    [array],
  )

  return {
    array,
    setArray,
    addItem,
    removeItem,
    updateItem,
    findItem,
    sortArray,
    filterArray,
  }
}

/**
 * A hook that provides an optimized object state with efficient operations
 *
 * @param initialObject The initial object
 * @returns An object with the state and optimized object operations
 */
export function useOptimizedObject<T extends Record<string, any>>(initialObject: T) {
  const [[object], setObject] = useOptimizedState<T>(initialObject)

  // Update a specific key in the object
  const updateKey = useCallback(
    <K extends keyof T>(key: K, value: T[K] | ((prevValue: T[K]) => T[K])) => {
      setObject((prev) => ({
        ...prev,
        [key]: typeof value === "function" ? (value as Function)(prev[key]) : value,
      }))
    },
    [setObject],
  )

  // Update multiple keys at once
  const updateKeys = useCallback(
    (updates: Partial<T>) => {
      setObject((prev) => ({
        ...prev,
        ...updates,
      }))
    },
    [setObject],
  )

  // Remove a key from the object
  const removeKey = useCallback(
    <K extends keyof T>(key: K) => {
      setObject((prev) => {
        const { [key]: _, ...rest } = prev
        return rest as T
      })
    },
    [setObject],
  )

  // Check if a key exists in the object
  const hasKey = useCallback(
    (key: keyof T) => {
      return key in object
    },
    [object],
  )

  return {
    object,
    setObject,
    updateKey,
    updateKeys,
    removeKey,
    hasKey,
  }
}

