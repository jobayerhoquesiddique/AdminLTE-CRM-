"use client"

import type React from "react"

import { useState, useCallback } from "react"

type ValidationRules<T> = {
  [K in keyof T]?: {
    required?: boolean
    minLength?: number
    maxLength?: number
    pattern?: RegExp
    min?: number
    max?: number
    custom?: (value: T[K], formData: T) => boolean
    message?: string
  }
}

type ValidationErrors<T> = {
  [K in keyof T]?: string
}

export function useFormValidation<T extends Record<string, any>>(
  initialValues: T,
  validationRules: ValidationRules<T>,
) {
  const [values, setValues] = useState<T>(initialValues)
  const [errors, setErrors] = useState<ValidationErrors<T>>({})
  const [touched, setTouched] = useState<Record<keyof T, boolean>>({} as Record<keyof T, boolean>)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
      const { name, value, type } = e.target
      const newValue = type === "number" ? Number.parseFloat(value) : value
      setValues((prev) => ({ ...prev, [name]: newValue }))
    },
    [],
  )

  const handleBlur = useCallback((e: React.FocusEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name } = e.target
    setTouched((prev) => ({ ...prev, [name]: true }))
  }, [])

  const handleCheckboxChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target
    setValues((prev) => ({ ...prev, [name]: checked }))
  }, [])

  const validateField = useCallback(
    (name: keyof T, value: any): string | undefined => {
      const rules = validationRules[name]
      if (!rules) return undefined

      if (rules.required && (value === undefined || value === null || value === "")) {
        return rules.message || `${String(name)} is required`
      }

      if (rules.minLength && typeof value === "string" && value.length < rules.minLength) {
        return rules.message || `${String(name)} must be at least ${rules.minLength} characters`
      }

      if (rules.maxLength && typeof value === "string" && value.length > rules.maxLength) {
        return rules.message || `${String(name)} must be at most ${rules.maxLength} characters`
      }

      if (rules.pattern && typeof value === "string" && !rules.pattern.test(value)) {
        return rules.message || `${String(name)} is invalid`
      }

      if (rules.min !== undefined && typeof value === "number" && value < rules.min) {
        return rules.message || `${String(name)} must be at least ${rules.min}`
      }

      if (rules.max !== undefined && typeof value === "number" && value > rules.max) {
        return rules.message || `${String(name)} must be at most ${rules.max}`
      }

      if (rules.custom && !rules.custom(value, values)) {
        return rules.message || `${String(name)} is invalid`
      }

      return undefined
    },
    [validationRules, values],
  )

  const validateForm = useCallback((): boolean => {
    const newErrors: ValidationErrors<T> = {}
    let isValid = true

    for (const key in validationRules) {
      const fieldName = key as keyof T
      const error = validateField(fieldName, values[fieldName])
      if (error) {
        newErrors[fieldName] = error
        isValid = false
      }
    }

    setErrors(newErrors)
    return isValid
  }, [validateField, validationRules, values])

  const handleSubmit = useCallback(
    (onSubmit: (values: T) => void) => (e: React.FormEvent) => {
      e.preventDefault()
      setIsSubmitting(true)

      // Mark all fields as touched
      const allTouched = Object.keys(values).reduce(
        (acc, key) => ({ ...acc, [key]: true }),
        {} as Record<keyof T, boolean>,
      )
      setTouched(allTouched)

      const isValid = validateForm()
      if (isValid) {
        onSubmit(values)
      }

      setIsSubmitting(false)
    },
    [validateForm, values],
  )

  const resetForm = useCallback(() => {
    setValues(initialValues)
    setErrors({})
    setTouched({} as Record<keyof T, boolean>)
    setIsSubmitting(false)
  }, [initialValues])

  const setFieldValue = useCallback((name: keyof T, value: any) => {
    setValues((prev) => ({ ...prev, [name]: value }))
  }, [])

  return {
    values,
    errors,
    touched,
    isSubmitting,
    handleChange,
    handleBlur,
    handleCheckboxChange,
    handleSubmit,
    resetForm,
    setFieldValue,
    validateForm,
    validateField,
  }
}

