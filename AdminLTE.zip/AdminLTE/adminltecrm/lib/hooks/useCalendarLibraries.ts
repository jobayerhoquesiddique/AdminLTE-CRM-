"use client"

import { useState, useEffect } from "react"

// Hook to load external calendar libraries
export function useCalendarLibraries() {
  const [coreLoaded, setCoreLoaded] = useState(false)
  const [dayGridLoaded, setDayGridLoaded] = useState(false)
  const [timeGridLoaded, setTimeGridLoaded] = useState(false)
  const [interactionLoaded, setInteractionLoaded] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const loadLibraries = async () => {
      try {
        // Load FullCalendar core
        await import("@fullcalendar/core")
        setCoreLoaded(true)

        // Load plugins
        try {
          await import("@fullcalendar/daygrid")
          setDayGridLoaded(true)

          await import("@fullcalendar/timegrid")
          setTimeGridLoaded(true)

          await import("@fullcalendar/interaction")
          setInteractionLoaded(true)
        } catch (pluginError) {
          console.error("Error loading calendar plugins:", pluginError)
          setError("Failed to load calendar plugins. Please check your internet connection and try again.")
        }
      } catch (coreError) {
        console.error("Error loading FullCalendar core:", coreError)
        setError("Failed to load calendar library. Please check your internet connection and try again.")
      }
    }

    loadLibraries()
  }, [])

  return {
    coreLoaded,
    dayGridLoaded,
    timeGridLoaded,
    interactionLoaded,
    allLibrariesLoaded: coreLoaded && dayGridLoaded && timeGridLoaded && interactionLoaded,
    error,
  }
}

