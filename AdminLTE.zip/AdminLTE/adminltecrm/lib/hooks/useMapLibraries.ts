"use client"

import { useState, useEffect } from "react"

// Hook to load external map libraries
export function useMapLibraries() {
  const [jQueryLoaded, setJQueryLoaded] = useState(false)
  const [jVectorMapLoaded, setJVectorMapLoaded] = useState(false)
  const [worldMapLoaded, setWorldMapLoaded] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const loadLibraries = async () => {
      try {
        // Load jQuery first
        const jQuery = await import("jquery")
        if (typeof window !== "undefined") {
          window.jQuery = jQuery.default
          window.$ = jQuery.default
          setJQueryLoaded(true)
        }

        // Then load jVectorMap
        try {
          await import("jvectormap-next")
          await import("jvectormap-next/jquery-jvectormap.css")
          setJVectorMapLoaded(true)

          // Finally load the world map
          await import("jvectormap-content/world-mill")
          setWorldMapLoaded(true)
        } catch (mapError) {
          console.error("Error loading map libraries:", mapError)
          setError("Failed to load map libraries. Please check your internet connection and try again.")
        }
      } catch (jqueryError) {
        console.error("Error loading jQuery:", jqueryError)
        setError("Failed to load jQuery. Please check your internet connection and try again.")
      }
    }

    loadLibraries()
  }, [])

  return {
    jQueryLoaded,
    jVectorMapLoaded,
    worldMapLoaded,
    allLibrariesLoaded: jQueryLoaded && jVectorMapLoaded && worldMapLoaded,
    error,
  }
}

